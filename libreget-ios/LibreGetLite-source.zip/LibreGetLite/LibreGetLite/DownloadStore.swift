import Foundation
import Combine
import AVFoundation
import UIKit
import ImageIO

enum DownloadStatus: String, Codable {
    case queued, downloading, processing, completed, failed
}

private struct DownloadFailure: LocalizedError {
    let message: String
    var errorDescription: String? { message }
}

struct DownloadPart: Codable, Equatable {
    var name: String
    var url: String
    var headers: [String: String]
    var taskIdentifier: Int?
    var receivedBytes: Int64 = 0
    var expectedBytes: Int64 = 0
    var stagedFilename: String?
    var transport: String? = nil
}

struct DownloadItem: Identifiable, Codable, Equatable {
    var id: String
    var sourceURL: String
    var title: String
    var status: DownloadStatus
    var receivedBytes: Int64
    var expectedBytes: Int64
    var localFilename: String?
    var errorMessage: String?
    var createdAt: Date
    var taskIdentifier: Int?
    // Optional additions preserve decoding of the original 0.1.0 history.
    var format: MediaFormat? = nil
    var attempt: String? = nil
    var parts: [DownloadPart]? = nil
    var assetRelativePath: String? = nil
    var offlineProgress: Double? = nil
    var diagnostics: [DownloadDiagnostic]? = nil

    var progress: Double {
        if let offlineProgress { return min(1, max(0, offlineProgress)) }
        guard expectedBytes > 0 else { return 0 }
        return min(1, max(0, Double(receivedBytes) / Double(expectedBytes)))
    }
}

// All state and delegate callbacks use the main queue. Persisted attempt/part
// identity rejects late callbacks after cancellation, retry, and app relaunch.
final class DownloadStore: NSObject, ObservableObject, URLSessionDownloadDelegate, AVAssetDownloadDelegate {
    static let shared = DownloadStore()
    @Published private(set) var items: [DownloadItem] = []
    private let storageKey = "libreget.ios.downloads.v1"
    private let fileSessionID: String
    private let assetSessionID: String
    private let defaults: UserDefaults
    private let rootDirectory: URL?
    private let streamPreferenceKey = "libreget.ios.preferAppOwnedStream.v1"
    private var fileSession: URLSession!
    private var assetSession: AVAssetDownloadURLSession!
    private var liveTasks: [String: URLSessionTask] = [:]
    private var mergeTasks: [String: Task<Void, Never>] = [:]
    private var exporters: [String: AVAssetExportSession] = [:]
    private var backgroundTasks: [String: UIBackgroundTaskIdentifier] = [:]
    private struct StreamEntry {
        var token: UUID
        var downloader: AppOwnedStreamDownloader
    }
    private var streams: [String: StreamEntry] = [:]
    private var streamBackgroundTasks: [String: UIBackgroundTaskIdentifier] = [:]
    private var reconciling = true
    #if DOWNLOAD_STORE_FIXTURES
    private var fixtureBackgroundError: Error?
    #endif

    var completedItems: [DownloadItem] {
        items.filter { $0.status == .completed }.sorted { $0.createdAt > $1.createdAt }
    }
    var activeItems: [DownloadItem] {
        items.filter { [.queued, .downloading, .processing].contains($0.status) }.sorted { $0.createdAt > $1.createdAt }
    }

    override convenience init() {
        self.init(defaults: .standard, rootDirectory: nil, sessionNamespace: nil)
    }

    private init(defaults: UserDefaults, rootDirectory: URL?, sessionNamespace: String?) {
        self.defaults = defaults
        self.rootDirectory = rootDirectory
        let suffix = sessionNamespace.map { "." + $0 } ?? ""
        fileSessionID = "com.openselena.libreget.ioslite.downloads" + suffix
        assetSessionID = "com.openselena.libreget.ioslite.assets" + suffix
        super.init()
        restoreItems()
        cleanupInterruptedStreams()
        let fileConfiguration = URLSessionConfiguration.background(withIdentifier: fileSessionID)
        fileConfiguration.isDiscretionary = false
        fileConfiguration.sessionSendsLaunchEvents = true
        fileConfiguration.httpMaximumConnectionsPerHost = 3
        fileSession = URLSession(configuration: fileConfiguration, delegate: self, delegateQueue: .main)
        let assetConfiguration = URLSessionConfiguration.background(withIdentifier: assetSessionID)
        assetConfiguration.isDiscretionary = false
        assetConfiguration.sessionSendsLaunchEvents = true
        assetSession = AVAssetDownloadURLSession(configuration: assetConfiguration, assetDownloadDelegate: self, delegateQueue: .main)
        reconcileTasks()
    }

    #if DOWNLOAD_STORE_FIXTURES
    convenience init(fixtureRoot: URL, defaults: UserDefaults, sessionNamespace: String, backgroundError: Error? = nil) {
        self.init(defaults: defaults, rootDirectory: fixtureRoot, sessionNamespace: sessionNamespace)
        fixtureBackgroundError = backgroundError
    }

    func fixtureInjectBackgroundFailure(id: String, attempt: String, partName: String = "main", error: Error) {
        handleBackgroundFailure(id: id, attempt: attempt, partName: partName, error: error, stage: "background-network")
    }
    #endif

    @discardableResult
    func enqueue(_ rawURL: String) -> String? {
        guard let url = validURL(rawURL.trimmingCharacters(in: .whitespacesAndNewlines)) else {
            return "请输入有效的 HTTP 或 HTTPS 下载链接。"
        }
        let format = MediaFormat(id: "direct", url: url.absoluteString, fileExtension: url.pathExtension,
                                 quality: "原文件", kind: .file)
        let media = ResolvedMedia(originalURL: url.absoluteString,
                                  title: url.lastPathComponent.isEmpty ? (url.host ?? "下载") : url.lastPathComponent,
                                  extractor: "文件直链", formats: [format])
        return enqueue(media: media, format: format)
    }

    @discardableResult
    func enqueue(media: ResolvedMedia, format: MediaFormat) -> String? {
        guard validURL(format.url) != nil,
              format.audioURL == nil || validURL(format.audioURL!) != nil else {
            return "解析器没有返回有效的 HTTP 或 HTTPS 媒体链接。"
        }
        if isHLS(format), format.audioURL != nil {
            return "这个格式将独立音轨与 HLS 混合，暂不能离线合并，请选择其他格式。"
        }
        let hint = format.protocolHint?.lowercased() ?? ""
        if hint.contains("http_dash_segments") || hint.contains("ism") || URL(string: format.url)?.pathExtension.lowercased() == "mpd" {
            return "这个格式需要下载分段 DASH 清单，暂不支持，请选择 MP4 或 HLS 格式。"
        }
        if items.contains(where: { $0.sourceURL == format.url && $0.format?.audioURL == format.audioURL && $0.status != .failed }) {
            return "这个媒体格式已经在下载列表里。"
        }
        let item = DownloadItem(id: UUID().uuidString, sourceURL: format.url, title: media.title,
                                status: .queued, receivedBytes: 0, expectedBytes: 0, localFilename: nil,
                                errorMessage: nil, createdAt: Date(), taskIdentifier: nil, format: format)
        items.insert(item, at: 0)
        persistItems()
        if !reconciling { start(item.id) }
        return nil
    }

    func retry(_ id: String) {
        guard let index = itemIndex(id), items[index].status == .failed else { return }
        invalidateWork(id)
        // Reuse complete tracks after an interrupted merge; expired CDN URLs
        // need not be fetched again. Network failures start a fresh attempt.
        let reusable = partsAreReady(items[index])
        if !reusable {
            cleanupParts(items[index])
            // Remember a transport that already bypassed the daemon. Retry
            // clears partial state but need not repeat the known failure.
            items[index].parts = items[index].parts?.map { part in
                var fresh = part
                fresh.taskIdentifier = nil
                fresh.stagedFilename = nil
                fresh.receivedBytes = 0
                fresh.expectedBytes = 0
                return fresh
            }
        }
        cleanupAsset(items[index])
        items[index].assetRelativePath = nil
        items[index].offlineProgress = nil
        items[index].attempt = UUID().uuidString
        items[index].taskIdentifier = nil
        items[index].status = .queued
        items[index].receivedBytes = reusable ? items[index].receivedBytes : 0
        items[index].expectedBytes = reusable ? items[index].expectedBytes : 0
        items[index].errorMessage = nil
        persistItems()
        if !reconciling { start(id) }
    }

    func cancel(_ id: String) {
        guard let index = itemIndex(id), [.queued, .downloading, .processing].contains(items[index].status) else { return }
        // Invalidate before cancelling: cancelled tasks can still callback.
        items[index].status = .failed
        items[index].attempt = UUID().uuidString
        items[index].taskIdentifier = nil
        items[index].errorMessage = "已取消"
        invalidateWork(id)
        cleanupParts(items[index])
        cleanupAsset(items[index])
        items[index].parts = nil
        items[index].assetRelativePath = nil
        persistItems()
    }

    func remove(_ id: String) {
        guard let index = itemIndex(id) else { return }
        let item = items.remove(at: index)
        invalidateWork(id)
        cleanupParts(item)
        if let url = fileURL(for: item) { try? FileManager.default.removeItem(at: url) }
        cleanupAsset(item)
        persistItems()
    }

    func fileURL(for item: DownloadItem) -> URL? {
        if let relative = item.assetRelativePath { return sandboxURL(relative) }
        guard let filename = item.localFilename else { return nil }
        return downloadsDirectory.appendingPathComponent(safeFilename(filename))
    }

    func fileSizeDescription(for item: DownloadItem) -> String {
        if item.assetRelativePath != nil { return "HLS 离线媒体包" }
        return ByteCountFormatter.string(fromByteCount: max(item.expectedBytes, item.receivedBytes), countStyle: .file)
    }

    // MARK: Background file downloads

    func urlSession(_ session: URLSession, downloadTask: URLSessionDownloadTask,
                    didWriteData bytesWritten: Int64, totalBytesWritten: Int64, totalBytesExpectedToWrite: Int64) {
        guard let (index, partIndex) = currentPart(downloadTask, session: session) else { return }
        items[index].parts?[partIndex].receivedBytes = totalBytesWritten
        items[index].parts?[partIndex].expectedBytes = max(0, totalBytesExpectedToWrite)
        updateTotals(index)
    }

    func urlSession(_ session: URLSession, downloadTask: URLSessionDownloadTask, didFinishDownloadingTo location: URL) {
        guard let (index, partIndex) = currentPart(downloadTask, session: session),
              let attempt = items[index].attempt, let parts = items[index].parts else { return }
        let id = items[index].id
        var failureStage = "background-response"
        do {
            try validateResponse(downloadTask.response, kind: items[index].format?.kind)
            failureStage = "background-source-read"
            try validateFilePrefix(location, kind: items[index].format?.kind)
            let ext = partIndex == 0 ? safeExtension(items[index].format?.fileExtension ?? URL(string: parts[partIndex].url)?.pathExtension ?? "") : "m4a"
            let filename = "\(id)-\(attempt)-\(parts[partIndex].name).\(ext.isEmpty ? "bin" : ext)"
            let destination = stagingDirectory.appendingPathComponent(filename)
            // CFNetwork can grant read access without allowing deletion from
            // its source directory. Moving that file then fails with a save
            // permission error. Copy its bytes to an app-owned file instead;
            // URLSession itself removes the source after this callback returns.
            failureStage = "background-import"
            let size = try DownloadFileStager.copyDownload(from: location, to: destination)
            liveTasks[taskKey(id, attempt, parts[partIndex].name)] = nil
            items[index].parts?[partIndex].stagedFilename = filename
            items[index].parts?[partIndex].taskIdentifier = nil
            items[index].parts?[partIndex].receivedBytes = size
            items[index].parts?[partIndex].expectedBytes = size
            updateTotals(index)
            persistItems()
            finishPartsIfReady(id)
        } catch {
            handleBackgroundFailure(id: id, attempt: attempt, partName: parts[partIndex].name,
                                    error: error, stage: failureStage)
        }
    }

    // MARK: System HLS offline packages

    func urlSession(_ session: URLSession, assetDownloadTask: AVAssetDownloadTask,
                    didLoad timeRange: CMTimeRange, totalTimeRangesLoaded loadedTimeRanges: [NSValue],
                    timeRangeExpectedToLoad: CMTimeRange) {
        guard let index = currentAsset(assetDownloadTask, session: session) else { return }
        let expected = timeRangeExpectedToLoad.duration.seconds
        guard expected.isFinite, expected > 0 else { return }
        let loaded = loadedTimeRanges.reduce(0.0) { $0 + max(0, $1.timeRangeValue.duration.seconds) }
        items[index].offlineProgress = min(0.99, max(0, loaded / expected))
    }

    func urlSession(_ session: URLSession, assetDownloadTask: AVAssetDownloadTask, didFinishDownloadingTo location: URL) {
        guard let index = currentAsset(assetDownloadTask, session: session) else {
            if relativeSandboxPath(location) != nil { try? FileManager.default.removeItem(at: location) }
            return
        }
        // Apple requires leaving HLS assets at this system-provided location.
        guard let relative = relativeSandboxPath(location) else {
            fail(items[index].id, attempt: items[index].attempt, message: "系统返回了无效的离线媒体保存位置。")
            return
        }
        items[index].assetRelativePath = relative
        persistItems()
    }

    func urlSession(_ session: URLSession, task: URLSessionTask, didCompleteWithError error: Error?) {
        if let assetTask = task as? AVAssetDownloadTask, let index = currentAsset(assetTask, session: session) {
            let id = items[index].id
            let attempt = items[index].attempt
            liveTasks[taskKey(id, attempt ?? "", "hls")] = nil
            if let error { fail(id, attempt: attempt, message: downloadError(error)) }
            else if let url = fileURL(for: items[index]), FileManager.default.fileExists(atPath: url.path) {
                items[index].status = .completed
                items[index].offlineProgress = 1
                items[index].taskIdentifier = nil
                items[index].errorMessage = nil
                persistItems()
            } else { fail(id, attempt: attempt, message: "HLS 下载结束，但没有生成离线媒体包，请重新解析后重试。") }
            return
        }
        guard let (index, partIndex) = currentPart(task, session: session),
              let attempt = items[index].attempt, let part = items[index].parts?[partIndex] else { return }
        handleBackgroundFailure(id: items[index].id, attempt: attempt, partName: part.name,
                                error: error ?? DownloadFailure(message: "下载结束但未收到媒体文件，请重新解析后重试。"),
                                stage: "background-network")
    }

    func urlSessionDidFinishEvents(forBackgroundURLSession session: URLSession) {
        guard let identifier = session.configuration.identifier else { return }
        DispatchQueue.main.async { AppDelegate.finishBackgroundSession(identifier: identifier) }
    }

    // MARK: Starting and restoring work

    private func start(_ id: String) {
        guard let index = itemIndex(id), [.queued, .downloading, .processing].contains(items[index].status) else { return }
        if items[index].attempt == nil { items[index].attempt = UUID().uuidString }
        guard let attempt = items[index].attempt else { return }
        if let format = items[index].format, isHLS(format) { startHLS(index, attempt: attempt, format: format); return }
        if items[index].parts == nil {
            let format = items[index].format
            var parts = [DownloadPart(name: "main", url: items[index].sourceURL, headers: format?.headers ?? [:])]
            if let audioURL = format?.audioURL {
                parts.append(DownloadPart(name: "audio", url: audioURL, headers: format?.audioHeaders ?? format?.headers ?? [:]))
            }
            items[index].parts = parts
        }
        if partsAreReady(items[index]) { finishPartsIfReady(id); return }
        items[index].status = .downloading
        items[index].errorMessage = nil
        guard let parts = items[index].parts else { return }
        for partIndex in parts.indices {
            guard items[index].status == .downloading, items[index].attempt == attempt else { return }
            let part = parts[partIndex]
            if let filename = part.stagedFilename, FileManager.default.fileExists(atPath: stagingDirectory.appendingPathComponent(filename).path) { continue }
            let key = taskKey(id, attempt, part.name)
            if part.transport == "app-stream" || (defaults.bool(forKey: streamPreferenceKey) && liveTasks[key] == nil) {
                // The preference is learned only after an actual background
                // file permission failure on this installation.
                items[index].parts?[partIndex].transport = "app-stream"
                startStream(id: id, attempt: attempt, partName: part.name)
                continue
            }
            if let task = liveTasks[key] {
                if task.state == .suspended { task.resume() }
                continue
            }
            guard let url = validURL(part.url) else { fail(id, attempt: attempt, message: "下载链接无效，请重新解析。"); return }
            var request = URLRequest(url: url)
            for (name, value) in safeHeaders(part.headers) { request.setValue(value, forHTTPHeaderField: name) }
            #if DOWNLOAD_STORE_FIXTURES
            if let error = fixtureBackgroundError {
                handleBackgroundFailure(id: id, attempt: attempt, partName: part.name,
                                        error: error, stage: "background-network")
                continue
            }
            #endif
            let task = fileSession.downloadTask(with: request)
            task.taskDescription = key
            items[index].parts?[partIndex].taskIdentifier = task.taskIdentifier
            items[index].parts?[partIndex].stagedFilename = nil
            liveTasks[key] = task
            persistItems()
            task.resume()
        }
        persistItems()
    }

    // MARK: File-permission fallback into process-owned streaming

    private func handleBackgroundFailure(id: String, attempt: String, partName: String, error: Error, stage: String) {
        guard let index = itemIndex(id), items[index].attempt == attempt,
              [.queued, .downloading].contains(items[index].status),
              let partIndex = items[index].parts?.firstIndex(where: { $0.name == partName }),
              items[index].parts?[partIndex].transport != "app-stream",
              items[index].parts?[partIndex].stagedFilename == nil else { return }
        recordDiagnostic(id, stage: stage, error: error)
        guard DownloadTransportPolicy.shouldFallback(from: error) else {
            fail(id, attempt: attempt, message: "后台下载未完成：\(downloadError(error))")
            return
        }
        let key = taskKey(id, attempt, partName)
        // Change the persisted transport before cancelling so every late
        // background callback is rejected even when its task number matches.
        items[index].parts?[partIndex].transport = "app-stream"
        items[index].parts?[partIndex].taskIdentifier = nil
        items[index].parts?[partIndex].receivedBytes = 0
        items[index].parts?[partIndex].expectedBytes = 0
        liveTasks.removeValue(forKey: key)?.cancel()
        defaults.set(true, forKey: streamPreferenceKey)
        appendDiagnostic(id, DownloadDiagnostic(stage: "fallback-selected", domain: "LibreGet.Transport", code: 1, date: Date()))
        updateTotals(index)
        persistItems()
        startStream(id: id, attempt: attempt, partName: partName)
    }

    private func startStream(id: String, attempt: String, partName: String) {
        guard let index = itemIndex(id), items[index].attempt == attempt,
              [.queued, .downloading].contains(items[index].status),
              let partIndex = items[index].parts?.firstIndex(where: { $0.name == partName }),
              let part = items[index].parts?[partIndex], part.transport == "app-stream" else { return }
        let key = taskKey(id, attempt, partName)
        guard streams[key] == nil else { return }
        guard let url = validURL(part.url) else { fail(id, attempt: attempt, message: "下载链接无效，请重新解析。"); return }
        var request = URLRequest(url: url)
        for (name, value) in safeHeaders(part.headers) { request.setValue(value, forHTTPHeaderField: name) }
        let token = UUID()
        let ext = partIndex == 0 ? safeExtension(items[index].format?.fileExtension ?? url.pathExtension) : "m4a"
        let filename = "\(id)-\(attempt)-\(partName)-stream-\(token.uuidString).\(ext.isEmpty ? "bin" : ext)"
        let destination = stagingDirectory.appendingPathComponent(filename)
        items[index].status = .downloading
        items[index].parts?[partIndex].receivedBytes = 0
        items[index].parts?[partIndex].expectedBytes = 0
        items[index].parts?[partIndex].taskIdentifier = nil
        items[index].errorMessage = nil
        let downloader = AppOwnedStreamDownloader(request: request, destination: destination, progress: { [weak self] received, expected in
            guard let self, let (index, partIndex) = self.currentStream(id: id, attempt: attempt, partName: partName, token: token) else { return }
            self.items[index].parts?[partIndex].receivedBytes = received
            self.items[index].parts?[partIndex].expectedBytes = expected
            self.updateTotals(index)
        }, completion: { [weak self] result in
            guard let self else {
                if case .success(let file) = result { try? FileManager.default.removeItem(at: file.url) }
                return
            }
            guard let (index, partIndex) = self.currentStream(id: id, attempt: attempt, partName: partName, token: token) else {
                if case .success(let file) = result { try? FileManager.default.removeItem(at: file.url) }
                return
            }
            self.streams[key] = nil
            self.endStreamBackgroundTask(key)
            switch result {
            case .success(let file):
                do {
                    try self.validateResponse(file.response, kind: self.items[index].format?.kind)
                    try self.validateFilePrefix(file.url, kind: self.items[index].format?.kind)
                    self.items[index].parts?[partIndex].stagedFilename = filename
                    self.items[index].parts?[partIndex].receivedBytes = file.bytes
                    self.items[index].parts?[partIndex].expectedBytes = file.bytes
                    self.appendDiagnostic(id, DownloadDiagnostic(stage: "app-stream-complete", domain: "LibreGet.Transport", code: 0, date: Date()))
                    self.updateTotals(index)
                    self.persistItems()
                    self.finishPartsIfReady(id)
                } catch {
                    try? FileManager.default.removeItem(at: file.url)
                    self.recordDiagnostic(id, stage: "app-stream-validation", error: error)
                    self.fail(id, attempt: attempt, message: "下载内容检查未通过：\(error.localizedDescription)")
                }
            case .failure(let error):
                let failure = error as? AppOwnedStreamError
                self.recordDiagnostic(id, stage: failure?.stage ?? "app-stream", error: failure?.underlying ?? error)
                self.fail(id, attempt: attempt, message: "应用内下载未完成：\(self.downloadError(error))")
            }
        })
        streams[key] = StreamEntry(token: token, downloader: downloader)
        appendDiagnostic(id, DownloadDiagnostic(stage: "app-stream-start", domain: "LibreGet.Transport", code: 0, date: Date()))
        streamBackgroundTasks[key] = UIApplication.shared.beginBackgroundTask(withName: "LibreGet media stream") { [weak self] in
            guard let self, self.currentStream(id: id, attempt: attempt, partName: partName, token: token) != nil else { return }
            self.appendDiagnostic(id, DownloadDiagnostic(stage: "app-stream-background-expired", domain: "LibreGet.Transport", code: 2, date: Date()))
            self.fail(id, attempt: attempt, message: "系统暂停了应用内下载。请保持 App 在前台并点重试。")
        }
        updateTotals(index)
        persistItems()
        downloader.start()
    }

    private func currentStream(id: String, attempt: String, partName: String, token: UUID) -> (Int, Int)? {
        let key = taskKey(id, attempt, partName)
        guard streams[key]?.token == token, let index = itemIndex(id), items[index].attempt == attempt,
              items[index].status == .downloading,
              let partIndex = items[index].parts?.firstIndex(where: { $0.name == partName }),
              items[index].parts?[partIndex].transport == "app-stream",
              items[index].parts?[partIndex].stagedFilename == nil else { return nil }
        return (index, partIndex)
    }

    private func endStreamBackgroundTask(_ key: String) {
        if let token = streamBackgroundTasks.removeValue(forKey: key), token != .invalid {
            UIApplication.shared.endBackgroundTask(token)
        }
    }

    private func appendDiagnostic(_ id: String, _ value: DownloadDiagnostic) {
        guard let index = itemIndex(id) else { return }
        var diagnostics = items[index].diagnostics ?? []
        diagnostics.append(value)
        items[index].diagnostics = Array(diagnostics.suffix(32))
    }

    private func recordDiagnostic(_ id: String, stage: String, error: Error) {
        for value in DownloadDiagnostic.records(stage: stage, error: error) { appendDiagnostic(id, value) }
    }

    private func startHLS(_ index: Int, attempt: String, format: MediaFormat) {
        let id = items[index].id
        let key = taskKey(id, attempt, "hls")
        if let task = liveTasks[key] {
            if task.state == .suspended { task.resume() }
            return
        }
        guard let url = validURL(format.url) else {
            fail(id, attempt: attempt, message: "HLS 下载链接无效，请重新解析。")
            return
        }
        let asset = AVURLAsset(url: url, options: ["AVURLAssetHTTPHeaderFieldsKey": safeHeaders(format.headers)])
        guard let task = assetSession.makeAssetDownloadTask(asset: asset, assetTitle: items[index].title, assetArtworkData: nil, options: nil) else {
            fail(id, attempt: attempt, message: "系统无法创建 HLS 离线下载任务，请选择 MP4 格式。")
            return
        }
        task.taskDescription = key
        items[index].status = .downloading
        items[index].taskIdentifier = task.taskIdentifier
        items[index].errorMessage = nil
        liveTasks[key] = task
        persistItems()
        task.resume()
    }

    private func reconcileTasks() {
        let group = DispatchGroup()
        for session in [fileSession!, assetSession! as URLSession] {
            group.enter()
            session.getAllTasks { tasks in
                DispatchQueue.main.async {
                    for task in tasks {
                        if task is AVAssetDownloadTask {
                            if self.currentAsset(task, session: session) == nil { task.cancel() }
                        } else if task is URLSessionDownloadTask {
                            self.adoptLegacyTask(task, session: session)
                            if self.currentPart(task, session: session) == nil { task.cancel() }
                        } else { task.cancel() }
                    }
                    group.leave()
                }
            }
        }
        group.notify(queue: .main) {
            self.reconciling = false
            // Recreate only missing parts; resume interrupted local muxing from
            // the two persisted tracks without starting duplicate downloads.
            let pending = self.activeItems.map(\.id)
            for id in pending {
                guard let index = self.itemIndex(id) else { continue }
                if let format = self.items[index].format, self.isHLS(format),
                   self.items[index].assetRelativePath != nil,
                   self.liveTasks[self.taskKey(id, self.items[index].attempt ?? "", "hls")] == nil {
                    self.fail(id, attempt: self.items[index].attempt, message: "离线任务已中断，请重新下载以确认媒体包完整。")
                    continue
                }
                self.start(id)
            }
            self.persistItems()
        }
    }

    private func adoptLegacyTask(_ task: URLSessionTask, session: URLSession) {
        guard session.configuration.identifier == fileSessionID,
              let id = task.taskDescription, !id.contains("|"), let index = itemIndex(id),
              items[index].attempt == nil, items[index].format == nil,
              [.queued, .downloading].contains(items[index].status),
              items[index].taskIdentifier == nil || items[index].taskIdentifier == task.taskIdentifier else { return }
        let attempt = "legacy"
        items[index].attempt = attempt
        items[index].parts = [DownloadPart(name: "main", url: items[index].sourceURL, headers: [:], taskIdentifier: task.taskIdentifier)]
        task.taskDescription = taskKey(id, attempt, "main")
        persistItems()
    }

    private func currentPart(_ task: URLSessionTask, session: URLSession) -> (Int, Int)? {
        guard session.configuration.identifier == fileSessionID, let key = task.taskDescription else { return nil }
        let tokens = key.split(separator: "|", omittingEmptySubsequences: false).map(String.init)
        guard tokens.count == 3, let index = itemIndex(tokens[0]),
              items[index].attempt == tokens[1], [.queued, .downloading].contains(items[index].status),
              let parts = items[index].parts, let partIndex = parts.firstIndex(where: { $0.name == tokens[2] }),
              parts[partIndex].taskIdentifier == task.taskIdentifier, parts[partIndex].stagedFilename == nil,
              parts[partIndex].transport != "app-stream" else { return nil }
        if let current = liveTasks[key], current !== task && current.taskIdentifier != task.taskIdentifier { return nil }
        liveTasks[key] = task
        return (index, partIndex)
    }

    private func currentAsset(_ task: URLSessionTask, session: URLSession) -> Int? {
        guard session.configuration.identifier == assetSessionID, let key = task.taskDescription else { return nil }
        let tokens = key.split(separator: "|", omittingEmptySubsequences: false).map(String.init)
        guard tokens.count == 3, tokens[2] == "hls", let index = itemIndex(tokens[0]),
              items[index].attempt == tokens[1], items[index].status == .downloading,
              items[index].taskIdentifier == task.taskIdentifier else { return nil }
        liveTasks[key] = task
        return index
    }

    // MARK: Final files and local audio/video muxing

    private func finishPartsIfReady(_ id: String) {
        guard let index = itemIndex(id), partsAreReady(items[index]),
              let parts = items[index].parts, let attempt = items[index].attempt, mergeTasks[id] == nil else { return }
        let item = items[index]
        items[index].status = .processing
        persistItems()
        backgroundTasks[id] = UIApplication.shared.beginBackgroundTask(withName: "LibreGet media merge") { [weak self] in
            guard let self else { return }
            self.fail(id, attempt: attempt, message: "系统暂停了媒体处理，打开 App 后点重试即可使用已下载的文件继续处理。")
        }
        mergeTasks[id] = Task { @MainActor [weak self] in
            guard let self else { return }
            do {
                let destination: URL
                if parts.count == 1 { destination = try await self.finishSingle(item) }
                else { destination = try await self.merge(item) }
                guard let current = self.itemIndex(id), self.items[current].attempt == attempt,
                      self.items[current].status == .processing else {
                    try? FileManager.default.removeItem(at: destination)
                    return
                }
                self.complete(id, attempt: attempt, destination: destination)
            } catch {
                self.recordDiagnostic(id, stage: "media-processing", error: error)
                self.fail(id, attempt: attempt, message: "媒体处理未完成：\(error.localizedDescription)")
            }
        }
    }

    @MainActor
    private func finishSingle(_ item: DownloadItem) async throws -> URL {
        guard let filename = item.parts?.first?.stagedFilename else {
            throw DownloadFailure(message: "本地媒体文件不完整，请重新下载。")
        }
        let source = stagingDirectory.appendingPathComponent(safeFilename(filename))
        if let kind = item.format?.kind, kind == .video || kind == .audio {
            let asset = AVURLAsset(url: source)
            let tracks = try await asset.loadTracks(withMediaType: kind == .video ? .video : .audio)
            let duration = try await asset.load(.duration)
            guard !tracks.isEmpty, duration.isNumeric, duration.seconds > 0 else {
                throw DownloadFailure(message: "下载的内容不是系统可识别的\(kind == .video ? "视频" : "音频")，请重新解析并选择其他格式。")
            }
        } else if item.format?.kind == .image {
            guard let image = CGImageSourceCreateWithURL(source as CFURL, nil), CGImageSourceGetCount(image) > 0 else {
                throw DownloadFailure(message: "下载的内容不是有效图片，请重新解析。")
            }
        }
        try Task.checkCancellation()
        let ext = safeExtension(item.format?.fileExtension ?? URL(string: item.sourceURL)?.pathExtension ?? "")
        let destination = try outputURL(title: item.title, id: item.id, attempt: item.attempt ?? "file", ext: ext)
        try FileManager.default.moveItem(at: source, to: destination)
        return destination
    }

    @MainActor
    private func merge(_ item: DownloadItem) async throws -> URL {
        guard let parts = item.parts, parts.count == 2,
              let videoFilename = parts[0].stagedFilename, let audioFilename = parts[1].stagedFilename else {
            throw DownloadFailure(message: "本地音视频轨道不完整，请重新下载。")
        }
        let video = AVURLAsset(url: stagingDirectory.appendingPathComponent(videoFilename))
        let audio = AVURLAsset(url: stagingDirectory.appendingPathComponent(audioFilename))
        guard let videoTrack = try await video.loadTracks(withMediaType: .video).first,
              let audioTrack = try await audio.loadTracks(withMediaType: .audio).first else {
            throw DownloadFailure(message: "系统不支持这个格式的音视频编码，请选择 H.264 / HEVC + AAC 格式。")
        }
        try Task.checkCancellation()
        let composition = AVMutableComposition()
        guard let composedVideo = composition.addMutableTrack(withMediaType: .video, preferredTrackID: kCMPersistentTrackID_Invalid),
              let composedAudio = composition.addMutableTrack(withMediaType: .audio, preferredTrackID: kCMPersistentTrackID_Invalid) else {
            throw DownloadFailure(message: "无法创建音视频合并轨道。")
        }
        let videoRange = try await videoTrack.load(.timeRange)
        let audioRange = try await audioTrack.load(.timeRange)
        guard videoRange.duration.isNumeric, audioRange.duration.isNumeric,
              videoRange.duration.seconds > 0, audioRange.duration.seconds > 0 else {
            throw DownloadFailure(message: "音视频时长无效，无法合并。")
        }
        try composedVideo.insertTimeRange(videoRange, of: videoTrack, at: .zero)
        composedVideo.preferredTransform = try await videoTrack.load(.preferredTransform)
        try composedAudio.insertTimeRange(audioRange, of: audioTrack, at: .zero)
        try Task.checkCancellation()
        var exportError: Error = DownloadFailure(message: "这个编码无法保存为 MP4 / MOV，请选择其他格式。")
        // Some track combinations advertise MP4 support but fail while writing
        // that container. Retry with MOV while keeping both tracks unchanged.
        for type in [AVFileType.mp4, .mov] {
            try Task.checkCancellation()
            guard let exporter = AVAssetExportSession(asset: composition, presetName: AVAssetExportPresetPassthrough),
                  exporter.supportedFileTypes.contains(type) else { continue }
            let destination = try outputURL(title: item.title, id: item.id, attempt: item.attempt ?? "merge", ext: type == .mp4 ? "mp4" : "mov")
            exporter.outputURL = destination
            exporter.outputFileType = type
            exporter.shouldOptimizeForNetworkUse = true
            exporters[item.id] = exporter
            do {
                try await withCheckedThrowingContinuation { (continuation: CheckedContinuation<Void, Error>) in
                    exporter.exportAsynchronously {
                        if exporter.status == .completed { continuation.resume() }
                        else { continuation.resume(throwing: exporter.error ?? DownloadFailure(message: "系统已取消媒体合并。")) }
                    }
                }
                try Task.checkCancellation()
                return destination
            } catch {
                try? FileManager.default.removeItem(at: destination)
                try Task.checkCancellation()
                exportError = error
            }
        }
        throw exportError
    }

    private func complete(_ id: String, attempt: String, destination: URL) {
        guard let index = itemIndex(id), items[index].attempt == attempt else { return }
        cleanupParts(items[index])
        items[index].status = .completed
        items[index].localFilename = destination.lastPathComponent
        items[index].parts = nil
        items[index].taskIdentifier = nil
        items[index].errorMessage = nil
        let size = (try? destination.resourceValues(forKeys: [.fileSizeKey]).fileSize).map(Int64.init) ?? items[index].receivedBytes
        items[index].receivedBytes = size
        items[index].expectedBytes = size
        finishMergeWork(id)
        persistItems()
    }

    private func fail(_ id: String, attempt: String?, message: String) {
        guard let index = itemIndex(id), items[index].attempt == attempt,
              [.queued, .downloading, .processing].contains(items[index].status) else { return }
        items[index].status = .failed
        items[index].taskIdentifier = nil
        items[index].errorMessage = message
        invalidateWork(id)
        persistItems()
    }

    private func invalidateWork(_ id: String) {
        for key in Array(liveTasks.keys) where key.hasPrefix(id + "|") { liveTasks.removeValue(forKey: key)?.cancel() }
        for key in Array(streams.keys) where key.hasPrefix(id + "|") {
            streams.removeValue(forKey: key)?.downloader.cancel()
            endStreamBackgroundTask(key)
        }
        mergeTasks.removeValue(forKey: id)?.cancel()
        exporters.removeValue(forKey: id)?.cancelExport()
        finishMergeWork(id)
    }

    private func finishMergeWork(_ id: String) {
        mergeTasks[id] = nil
        exporters[id] = nil
        if let token = backgroundTasks.removeValue(forKey: id), token != .invalid { UIApplication.shared.endBackgroundTask(token) }
    }

    // MARK: Persistence and helpers

    private var downloadsDirectory: URL {
        if let rootDirectory { return rootDirectory.appendingPathComponent("Documents/Downloads", isDirectory: true) }
        return FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0].appendingPathComponent("Downloads", isDirectory: true)
    }
    private var stagingDirectory: URL {
        if let rootDirectory { return rootDirectory.appendingPathComponent("ApplicationSupport/MediaParts", isDirectory: true) }
        return FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0].appendingPathComponent("MediaParts", isDirectory: true)
    }
    private func itemIndex(_ id: String) -> Int? { items.firstIndex { $0.id == id } }
    private func taskKey(_ id: String, _ attempt: String, _ part: String) -> String { "\(id)|\(attempt)|\(part)" }

    private func validURL(_ raw: String) -> URL? {
        guard let url = URL(string: raw), ["http", "https"].contains(url.scheme?.lowercased() ?? ""),
              let host = url.host, !host.isEmpty, url.user == nil, url.password == nil else { return nil }
        return url
    }

    private func isHLS(_ format: MediaFormat) -> Bool {
        let hint = format.protocolHint?.lowercased() ?? ""
        return hint.contains("m3u8") || hint == "hls" || URL(string: format.url)?.pathExtension.lowercased() == "m3u8"
    }

    private func validateResponse(_ response: URLResponse?, kind: MediaKind?) throws {
        if let response = response as? HTTPURLResponse {
            guard (200..<300).contains(response.statusCode) else {
                throw NSError(domain: "LibreGet.HTTP", code: response.statusCode,
                              userInfo: [NSLocalizedDescriptionKey: "服务器返回 HTTP \(response.statusCode)，媒体链接可能已过期，请重新解析。"])
            }
            if kind != .file {
                let type = response.mimeType?.lowercased() ?? ""
                guard !type.contains("text/html"), !type.contains("application/json"), !type.contains("mpegurl") else {
                    throw DownloadFailure(message: "服务器返回了网页、错误信息或播放清单，请重新解析并选择其他格式。")
                }
            }
        }
    }

    private func validateFilePrefix(_ location: URL, kind: MediaKind?) throws {
        let handle = try FileHandle(forReadingFrom: location)
        defer { try? handle.close() }
        let prefix = try handle.read(upToCount: 128) ?? Data()
        let text = String(data: prefix, encoding: .utf8)?.trimmingCharacters(in: .whitespacesAndNewlines).lowercased() ?? ""
        guard !text.hasPrefix("#extm3u") else {
            throw DownloadFailure(message: "该链接返回 HLS 清单，请重新解析后选择 HLS 离线格式。")
        }
        if kind != .file, text.hasPrefix("<!doctype html") || text.hasPrefix("<html") {
            throw DownloadFailure(message: "下载地址返回了网页，媒体链接可能已经过期，请重新解析。")
        }
        if let kind, kind != .file,
           prefix.isEmpty || text.hasPrefix("{") || text.hasPrefix("[") || text.hasPrefix("<?xml") || text.hasPrefix("<error") {
            throw DownloadFailure(message: "下载地址返回了空文件或错误信息，请重新解析媒体链接。")
        }
    }

    private func safeHeaders(_ headers: [String: String]) -> [String: String] {
        headers.filter { name, value in
            !name.isEmpty && name.rangeOfCharacter(from: .newlines) == nil && value.rangeOfCharacter(from: .newlines) == nil &&
                !["host", "content-length", "connection", "range"].contains(name.lowercased())
        }
    }

    private func updateTotals(_ index: Int) {
        let parts = items[index].parts ?? []
        items[index].receivedBytes = parts.reduce(0) { $0 + $1.receivedBytes }
        items[index].expectedBytes = parts.allSatisfy { $0.expectedBytes > 0 } ? parts.reduce(0) { $0 + $1.expectedBytes } : 0
    }

    private func partsAreReady(_ item: DownloadItem) -> Bool {
        guard let parts = item.parts, !parts.isEmpty else { return false }
        return parts.allSatisfy { part in
            guard let filename = part.stagedFilename else { return false }
            return FileManager.default.fileExists(atPath: stagingDirectory.appendingPathComponent(safeFilename(filename)).path)
        }
    }

    private func cleanupParts(_ item: DownloadItem) {
        for part in item.parts ?? [] {
            if let filename = part.stagedFilename { try? FileManager.default.removeItem(at: stagingDirectory.appendingPathComponent(safeFilename(filename))) }
        }
    }

    private func cleanupInterruptedStreams() {
        // In-process streams cannot survive process termination. Remove only
        // their uncommitted app-owned files; referenced complete tracks remain
        // available to resume a local merge without repeating the network work.
        let referenced = Set(items.flatMap { ($0.parts ?? []).compactMap(\.stagedFilename) })
        guard let files = try? FileManager.default.contentsOfDirectory(at: stagingDirectory, includingPropertiesForKeys: nil) else { return }
        for file in files {
            let name = file.lastPathComponent
            if (name.hasPrefix(".stream-") && name.hasSuffix(".partial")) ||
                (name.contains("-stream-") && !referenced.contains(name)) {
                try? FileManager.default.removeItem(at: file)
            }
        }
    }
    private func cleanupAsset(_ item: DownloadItem) {
        if let relative = item.assetRelativePath, let url = sandboxURL(relative) { try? FileManager.default.removeItem(at: url) }
    }

    private func relativeSandboxPath(_ url: URL) -> String? {
        let root = URL(fileURLWithPath: NSHomeDirectory(), isDirectory: true).resolvingSymlinksInPath().standardizedFileURL.path + "/"
        let path = url.resolvingSymlinksInPath().standardizedFileURL.path
        guard path.hasPrefix(root) else { return nil }
        return String(path.dropFirst(root.count))
    }
    private func sandboxURL(_ relative: String) -> URL? {
        guard !relative.hasPrefix("/"), !relative.split(separator: "/").contains("..") else { return nil }
        let url = URL(fileURLWithPath: NSHomeDirectory(), isDirectory: true).appendingPathComponent(relative)
        return relativeSandboxPath(url) == nil ? nil : url
    }

    private func outputURL(title: String, id: String, attempt: String, ext: String) throws -> URL {
        try FileManager.default.createDirectory(at: downloadsDirectory, withIntermediateDirectories: true)
        let safeTitle = safeFilename(title)
        let suffix = safeExtension(ext)
        let base = suffix.isEmpty ? safeTitle : (safeTitle.lowercased().hasSuffix("." + suffix) ? String(safeTitle.dropLast(suffix.count + 1)) : safeTitle)
        // Distinct output paths also isolate old, cancelled export completions:
        // their cleanup must never remove the next attempt's output file.
        let name = String(base.prefix(90)) + "-" + String(id.prefix(8)) + "-" + String(attempt.prefix(8)) + (suffix.isEmpty ? "" : "." + suffix)
        let destination = downloadsDirectory.appendingPathComponent(name)
        try? FileManager.default.removeItem(at: destination)
        return destination
    }

    private func safeFilename(_ value: String) -> String {
        let name = URL(fileURLWithPath: value).lastPathComponent.replacingOccurrences(of: ":", with: "-")
            .replacingOccurrences(of: "\\", with: "-").trimmingCharacters(in: .whitespacesAndNewlines)
        return name.isEmpty || name == "." || name == ".." ? "download" : name
    }
    private func safeExtension(_ value: String) -> String {
        String(value.lowercased().filter { $0.isASCII && ($0.isLetter || $0.isNumber) }.prefix(10))
    }
    private func downloadError(_ error: Error) -> String {
        (error as NSError).code == NSURLErrorCancelled ? "已取消" : error.localizedDescription
    }
    private func restoreItems() {
        guard let data = defaults.data(forKey: storageKey),
              let restored = try? JSONDecoder().decode([DownloadItem].self, from: data) else { return }
        items = restored
    }
    private func persistItems() {
        guard let data = try? JSONEncoder().encode(items) else { return }
        defaults.set(data, forKey: storageKey)
    }
}
