import Foundation

struct DownloadDiagnostic: Codable, Equatable {
    var stage: String
    var domain: String
    var code: Int
    var date: Date

    static func records(stage: String, error: Error) -> [DownloadDiagnostic] {
        var result: [DownloadDiagnostic] = []
        var current: NSError? = error as NSError
        var visited = Set<ObjectIdentifier>()
        while let value = current, result.count < 8, visited.insert(ObjectIdentifier(value)).inserted {
            result.append(DownloadDiagnostic(stage: stage, domain: value.domain, code: value.code, date: Date()))
            current = value.userInfo[NSUnderlyingErrorKey] as? NSError
        }
        return result
    }
}

enum DownloadTransportPolicy {
    // CFNetwork can fail before didFinishDownloadingTo, so copying its final
    // temporary URL alone cannot recover this class of device-specific error.
    static func shouldFallback(from error: Error) -> Bool {
        DownloadDiagnostic.records(stage: "policy", error: error).contains { value in
            (value.domain == NSCocoaErrorDomain && [257, 513].contains(value.code)) ||
            (value.domain == NSURLErrorDomain && (-3005 ... -3000).contains(value.code)) ||
            (value.domain == NSPOSIXErrorDomain && [1, 13].contains(value.code))
        }
    }
}

struct AppOwnedStreamError: LocalizedError {
    var stage: String
    var underlying: Error
    var errorDescription: String? { underlying.localizedDescription }
}

/// Receives network bytes directly into a file created by this process. This
/// uses dataTask rather than downloadTask, so CFNetwork creates no download
/// temporary file. Callback chunks are written synchronously on a serial queue;
/// the implementation never accumulates the complete payload in memory.
final class AppOwnedStreamDownloader: NSObject, URLSessionDataDelegate {
    struct CompletedFile {
        var url: URL
        var bytes: Int64
        var response: HTTPURLResponse
    }

    private let request: URLRequest
    private let destination: URL
    private let callbackQueue: DispatchQueue
    private let onProgress: (Int64, Int64) -> Void
    private let onCompletion: (Result<CompletedFile, Error>) -> Void
    private let delegateQueue: OperationQueue
    private var session: URLSession?
    private var task: URLSessionDataTask?
    private var partial: URL?
    private var writer: FileHandle?
    private var response: HTTPURLResponse?
    private var received: Int64 = 0
    private var expected: Int64 = 0
    private var completed = false
    private var started = false
    private var cancelled = false

    init(request: URLRequest, destination: URL, callbackQueue: DispatchQueue = .main,
         progress: @escaping (Int64, Int64) -> Void,
         completion: @escaping (Result<CompletedFile, Error>) -> Void) {
        self.request = request
        self.destination = destination
        self.callbackQueue = callbackQueue
        onProgress = progress
        onCompletion = completion
        delegateQueue = OperationQueue()
        delegateQueue.name = "LibreGet app-owned media stream"
        delegateQueue.maxConcurrentOperationCount = 1
        super.init()
    }

    func start() {
        delegateQueue.addOperation { [self] in
            guard !started, !completed else { return }
            started = true
            guard !cancelled else { finish(.failure(URLError(.cancelled)), stage: "app-stream-cancel"); return }
            let configuration = URLSessionConfiguration.ephemeral
            configuration.urlCache = nil
            configuration.requestCachePolicy = .reloadIgnoringLocalCacheData
            configuration.timeoutIntervalForRequest = 90
            configuration.timeoutIntervalForResource = 24 * 60 * 60
            configuration.httpMaximumConnectionsPerHost = 2
            session = URLSession(configuration: configuration, delegate: self, delegateQueue: delegateQueue)
            var streamRequest = request
            // Known byte counts must refer to actual file bytes, rather than
            // compressed transfer sizes after transparent decompression.
            streamRequest.setValue("identity", forHTTPHeaderField: "Accept-Encoding")
            task = session?.dataTask(with: streamRequest)
            task?.resume()
        }
    }

    func cancel() {
        delegateQueue.addOperation { [self] in
            guard !completed else { return }
            cancelled = true
            task?.cancel()
            finish(.failure(URLError(.cancelled)), stage: "app-stream-cancel")
        }
    }

    func urlSession(_ session: URLSession, dataTask: URLSessionDataTask,
                    didReceive response: URLResponse, completionHandler: @escaping (URLSession.ResponseDisposition) -> Void) {
        guard !completed, dataTask === task else { completionHandler(.cancel); return }
        guard let http = response as? HTTPURLResponse, (200..<300).contains(http.statusCode) else {
            completionHandler(.cancel)
            let code = (response as? HTTPURLResponse)?.statusCode ?? 0
            finish(.failure(NSError(domain: "LibreGet.HTTP", code: code,
                                    userInfo: [NSLocalizedDescriptionKey: "服务器返回 HTTP \(code)，请重新解析媒体链接。"])), stage: "app-stream-response")
            return
        }
        self.response = http
        let encoding = http.value(forHTTPHeaderField: "Content-Encoding")?.lowercased()
        expected = encoding == nil || encoding == "identity" ? max(0, response.expectedContentLength) : 0
        do {
            try prepareOutput()
            completionHandler(.allow)
        } catch {
            completionHandler(.cancel)
            finish(.failure(error), stage: "app-stream-open")
        }
    }

    func urlSession(_ session: URLSession, dataTask: URLSessionDataTask, didReceive data: Data) {
        guard !completed, dataTask === task, let writer else { return }
        do {
            // write() consumes each callback before accepting another. No
            // array of chunks or payload-sized Data is retained between calls.
            try writer.write(contentsOf: data)
            received += Int64(data.count)
            let current = received
            let total = expected
            callbackQueue.async { [onProgress] in onProgress(current, total) }
        } catch {
            dataTask.cancel()
            finish(.failure(error), stage: "app-stream-write")
        }
    }

    func urlSession(_ session: URLSession, task: URLSessionTask, didCompleteWithError error: Error?) {
        guard !completed, task === self.task else { return }
        if let error { finish(.failure(error), stage: "app-stream-network"); return }
        guard let response, let partial, let writer else {
            finish(.failure(URLError(.badServerResponse)), stage: "app-stream-response")
            return
        }
        do {
            guard received > 0, expected == 0 || received == expected else {
                throw NSError(domain: "LibreGet.Stream", code: 1,
                              userInfo: [NSLocalizedDescriptionKey: "收到的文件不完整，请重新解析后重试。"])
            }
            try writer.synchronize()
            try writer.close()
            self.writer = nil
            try FileManager.default.moveItem(at: partial, to: destination)
            self.partial = nil
            finish(.success(CompletedFile(url: destination, bytes: received, response: response)), stage: "app-stream-complete")
        } catch { finish(.failure(error), stage: "app-stream-finalize") }
    }

    private func prepareOutput() throws {
        guard destination.isFileURL else { throw CocoaError(.fileWriteInvalidFileName) }
        let manager = FileManager.default
        let directory = destination.deletingLastPathComponent()
        try manager.createDirectory(at: directory, withIntermediateDirectories: true)
        guard !manager.fileExists(atPath: destination.path) else { throw CocoaError(.fileWriteFileExists) }
        let output = directory.appendingPathComponent(".stream-\(UUID().uuidString).partial")
        var attributes: [FileAttributeKey: Any] = [.posixPermissions: NSNumber(value: 0o600)]
        #if os(iOS)
        attributes[.protectionKey] = FileProtectionType.completeUntilFirstUserAuthentication
        #endif
        guard manager.createFile(atPath: output.path, contents: nil, attributes: attributes) else { throw CocoaError(.fileWriteUnknown) }
        partial = output
        writer = try FileHandle(forWritingTo: output)
    }

    private func finish(_ result: Result<CompletedFile, Error>, stage: String) {
        guard !completed else { return }
        completed = true
        try? writer?.close()
        writer = nil
        if let partial { try? FileManager.default.removeItem(at: partial) }
        partial = nil
        session?.invalidateAndCancel()
        session = nil
        task = nil
        let final = result.mapError { AppOwnedStreamError(stage: stage, underlying: $0) as Error }
        callbackQueue.async { [onCompletion] in onCompletion(final) }
    }
}
