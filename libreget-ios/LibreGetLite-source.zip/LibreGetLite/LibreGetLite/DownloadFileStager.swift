import Foundation

/// Imports a URLSession-owned temporary file without moving it or inheriting
/// daemon-owned permissions. Must finish before didFinishDownloadingTo returns.
enum DownloadFileStager {
    private static let chunkSize = 1024 * 1024

    @discardableResult
    static func copyDownload(from source: URL, to destination: URL) throws -> Int64 {
        guard source.isFileURL, destination.isFileURL,
              source.standardizedFileURL != destination.standardizedFileURL else {
            throw CocoaError(.fileWriteInvalidFileName)
        }
        let manager = FileManager.default
        let directory = destination.deletingLastPathComponent()
        try manager.createDirectory(at: directory, withIntermediateDirectories: true)
        guard !manager.fileExists(atPath: destination.path) else {
            throw CocoaError(.fileWriteFileExists, userInfo: [NSFilePathErrorKey: destination.path])
        }
        let sourceValues = try source.resourceValues(forKeys: [.isRegularFileKey, .fileSizeKey])
        guard sourceValues.isRegularFile == true else {
            throw CocoaError(.fileReadUnsupportedScheme, userInfo: [NSFilePathErrorKey: source.path])
        }
        // This unique file is created by the app. Only it is removed on failure;
        // the CFNetwork source and any existing destination are never modified.
        let partial = directory.appendingPathComponent(".download-\(UUID().uuidString).partial")
        var attributes: [FileAttributeKey: Any] = [.posixPermissions: NSNumber(value: 0o600)]
        #if os(iOS)
        attributes[.protectionKey] = FileProtectionType.completeUntilFirstUserAuthentication
        #endif
        guard manager.createFile(atPath: partial.path, contents: nil, attributes: attributes) else {
            throw CocoaError(.fileWriteUnknown, userInfo: [NSFilePathErrorKey: partial.path])
        }
        defer { try? manager.removeItem(at: partial) }
        let reader = try FileHandle(forReadingFrom: source)
        defer { try? reader.close() }
        let writer = try FileHandle(forWritingTo: partial)
        defer { try? writer.close() }
        var copied: Int64 = 0
        while let data = try reader.read(upToCount: chunkSize), !data.isEmpty {
            try writer.write(contentsOf: data)
            copied += Int64(data.count)
        }
        if let expected = sourceValues.fileSize, copied != Int64(expected) {
            throw CocoaError(.fileReadCorruptFile, userInfo: [NSFilePathErrorKey: source.path])
        }
        try writer.synchronize()
        try writer.close()
        try reader.close()
        // Rename only our own temporary file within the destination directory.
        // FileManager refuses to overwrite a conflicting completed file.
        try manager.moveItem(at: partial, to: destination)
        return copied
    }
}
