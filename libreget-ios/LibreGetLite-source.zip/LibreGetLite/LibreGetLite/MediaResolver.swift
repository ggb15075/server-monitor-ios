import Foundation
import Combine

@MainActor
final class MediaResolver: ObservableObject {
    @Published private(set) var result: ResolvedMedia?
    @Published private(set) var isResolving = false
    @Published private(set) var status = ""
    @Published private(set) var errorMessage: String?
    private var generation = UUID()

    func resolve(_ text: String) async {
        let current = UUID()
        generation = current
        result = nil
        errorMessage = nil
        isResolving = true
        status = "正在读取分享链接…"
        defer { if generation == current { isResolving = false } }
        do {
            let url = try Self.extractURL(text)
            let resolved: ResolvedMedia
            let fileExtension = url.pathExtension.lowercased()
            let videos = ["mp4", "mov", "m4v", "webm", "m3u8"]
            let audios = ["mp3", "m4a", "aac", "wav", "flac", "ogg"]
            let images = ["jpg", "jpeg", "png", "webp", "gif", "heic"]
            let files = ["zip", "7z", "rar", "pdf", "epub", "dmg", "iso", "ipa", "exe", "deb", "txt"]
            if (videos + audios + images + files).contains(fileExtension) {
                let kind: MediaKind = videos.contains(fileExtension) ? .video : audios.contains(fileExtension) ? .audio : images.contains(fileExtension) ? .image : .file
                resolved = ResolvedMedia(originalURL: url.absoluteString, title: url.lastPathComponent,
                                         extractor: "文件直链", formats: [MediaFormat(id: "direct", url: url.absoluteString,
                                         fileExtension: fileExtension, quality: "原文件", kind: kind,
                                         protocolHint: fileExtension == "m3u8" ? "m3u8_native" : nil)])
            } else {
                let native = NativeMediaParser()
                if native.supports(url) {
                    status = "正在使用本机原生解析器…"
                    do {
                        let value = try await native.resolve(url)
                        guard !value.formats.isEmpty else { throw MediaResolveError.noMedia }
                        resolved = value
                    } catch {
                        try Task.checkCancellation()
                        status = "原生解析未成功，正在使用本机 yt-dlp…"
                        do { resolved = try await PythonMediaEngine.shared.resolve(url) }
                        catch {
                            throw MediaResolveError.failed("本机解析未成功：\(error.localizedDescription)")
                        }
                    }
                } else {
                    status = "正在使用本机 yt-dlp 解析…"
                    resolved = try await PythonMediaEngine.shared.resolve(url)
                }
            }
            try Task.checkCancellation()
            guard generation == current else { return }
            guard !resolved.formats.isEmpty else { throw MediaResolveError.noMedia }
            result = resolved
            ParseHistoryStore.shared.record(resolved)
            status = "已找到 \(resolved.formats.count) 个媒体或格式"
        } catch is CancellationError {
            if generation == current { status = "已取消解析" }
        } catch {
            if generation == current { errorMessage = error.localizedDescription; status = "解析未完成" }
        }
    }

    func cancel() {
        generation = UUID()
        isResolving = false
        status = "已取消解析"
    }

    static func extractURL(_ text: String) throws -> URL {
        try ShareLinkParser.extractURL(text)
    }
}
