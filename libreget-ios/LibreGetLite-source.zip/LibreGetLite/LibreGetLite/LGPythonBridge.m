#import "LGPythonBridge.h"
#import <Python/Python.h>
#import <WebKit/WebKit.h>

static NSString *const LGEngineErrorDomain = @"LibreGetPythonEngine";

// A strong owner keeps each WebKit job alive until completion or timeout. All
// WebKit objects are touched only on the main thread. Python never blocks it.
@interface LGJavaScriptJob : NSObject
@property(nonatomic, strong) WKWebView *webView;
@property(nonatomic, strong) dispatch_semaphore_t semaphore;
@property(nonatomic, copy, nullable) NSString *output;
@property(nonatomic, copy, nullable) NSString *failure;
@property(nonatomic) BOOL finished;
- (void)start:(NSString *)source;
- (void)finish:(nullable NSString *)output error:(nullable NSString *)error;
@end

@implementation LGJavaScriptJob
- (void)finish:(NSString *)output error:(NSString *)error {
    NSAssert([NSThread isMainThread], @"WebKit completion must run on the main thread");
    if (self.finished) return;
    self.finished = YES;
    self.output = output;
    self.failure = error;
    [self.webView stopLoading];
    self.webView = nil;
    dispatch_semaphore_signal(self.semaphore);
}

- (void)start:(NSString *)source {
    WKWebViewConfiguration *configuration = [[WKWebViewConfiguration alloc] init];
    configuration.websiteDataStore = WKWebsiteDataStore.nonPersistentDataStore;
    self.webView = [[WKWebView alloc] initWithFrame:CGRectZero configuration:configuration];
    NSString *wrapper = [@"const __lgOutput = []; const __lgErrors = [];\n"
        "const console = {log: (...a) => __lgOutput.push(a.map(String).join(' ')),"
        "info: (...a) => __lgOutput.push(a.map(String).join(' ')),"
        "error: (...a) => __lgErrors.push(a.map(String).join(' ')),"
        "warn: () => {}, debug: () => {}, trace: () => {}, assert: () => {}};\n"
        "await (async () => {\n" stringByAppendingString:source];
    wrapper = [wrapper stringByAppendingString:@"\n})();\n"
        "if (__lgErrors.length) throw new Error(__lgErrors.join('\\n'));\n"
        "return __lgOutput.join('\\n');"];
    // callAsyncJavaScript supplies a WebKit JS environment with no subprocess,
    // JIT entitlement, ctypes trampoline or nested application run loop.
    [self.webView callAsyncJavaScript:wrapper arguments:@{} inFrame:nil
                      inContentWorld:WKContentWorld.defaultClientWorld
                   completionHandler:^(id result, NSError *error) {
        NSString *value = [result isKindOfClass:NSString.class] ? result : nil;
        [self finish:value error:error.localizedDescription ?: (value ? nil : @"JavaScript 没有返回结果。")];
    }];
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, 30 * NSEC_PER_SEC), dispatch_get_main_queue(), ^{
        [self finish:nil error:@"网站 JavaScript 解析超时，请保持 App 在前台后重试。"];
    });
}
@end

static PyObject *LGEvaluateJavaScript(PyObject *self, PyObject *args) {
    const char *script = NULL;
    if (!PyArg_ParseTuple(args, "s", &script)) return NULL;
    if ([NSThread isMainThread]) {
        PyErr_SetString(PyExc_RuntimeError, "JavaScript extraction must run on the Python worker queue");
        return NULL;
    }
    NSString *source = [NSString stringWithUTF8String:script];
    LGJavaScriptJob *job = [[LGJavaScriptJob alloc] init];
    job.semaphore = dispatch_semaphore_create(0);
    dispatch_async(dispatch_get_main_queue(), ^{ [job start:source]; });
    // Releasing the GIL allows other Python callbacks; the main queue never
    // waits for this worker, so dispatching WebKit work cannot deadlock it.
    Py_BEGIN_ALLOW_THREADS
    dispatch_semaphore_wait(job.semaphore, DISPATCH_TIME_FOREVER);
    Py_END_ALLOW_THREADS
    if (job.failure) {
        PyErr_SetString(PyExc_RuntimeError, job.failure.UTF8String);
        return NULL;
    }
    return PyUnicode_FromString(job.output.UTF8String ?: "");
}

static PyMethodDef LGNativeMethods[] = {
    {"evaluate_javascript", LGEvaluateJavaScript, METH_VARARGS, "Run a bounded WebKit JavaScript job."},
    {NULL, NULL, 0, NULL}
};
static struct PyModuleDef LGNativeModule = {
    PyModuleDef_HEAD_INIT, "_libreget_native", NULL, -1, LGNativeMethods
};
static PyObject *PyInit__libreget_native(void) { return PyModule_Create(&LGNativeModule); }

static NSError *LGError(NSString *message) {
    return [NSError errorWithDomain:LGEngineErrorDomain code:1
                          userInfo:@{NSLocalizedDescriptionKey:message ?: @"本机解析引擎未能完成请求。"}];
}

static NSString *LGPythonException(void) {
    PyObject *type = NULL, *value = NULL, *traceback = NULL;
    PyErr_Fetch(&type, &value, &traceback);
    PyErr_NormalizeException(&type, &value, &traceback);
    PyObject *description = value ? PyObject_Str(value) : NULL;
    const char *text = description ? PyUnicode_AsUTF8(description) : NULL;
    NSString *message = text ? [NSString stringWithUTF8String:text] : @"本机 Python 解析失败。";
    Py_XDECREF(description); Py_XDECREF(type); Py_XDECREF(value); Py_XDECREF(traceback);
    PyErr_Clear();
    return message;
}

static BOOL LGInitializePython(NSError **error) {
    if (Py_IsInitialized()) return YES;
    NSString *resources = NSBundle.mainBundle.resourcePath;
    NSString *home = [resources stringByAppendingPathComponent:@"python"];
    NSString *stdlib = [home stringByAppendingPathComponent:@"lib/python3.13"];
    NSString *packages = [resources stringByAppendingPathComponent:@"PythonPackages"];
    NSString *app = [resources stringByAppendingPathComponent:@"PythonApp"];
    if (![NSFileManager.defaultManager fileExistsAtPath:[stdlib stringByAppendingPathComponent:@"encodings/__init__.py"]] ||
        ![NSFileManager.defaultManager fileExistsAtPath:[packages stringByAppendingPathComponent:@"yt_dlp/__init__.py"]]) {
        if (error) *error = LGError(@"安装包缺少 Python 标准库或 yt-dlp，请重新安装完整版本。");
        return NO;
    }
    if (PyImport_AppendInittab("_libreget_native", PyInit__libreget_native) != 0) {
        if (error) *error = LGError(@"无法注册本机 JavaScript 桥接模块。");
        return NO;
    }
    PyPreConfig preconfig;
    PyPreConfig_InitIsolatedConfig(&preconfig);
    preconfig.utf8_mode = 1;
    PyStatus status = Py_PreInitialize(&preconfig);
    PyConfig config;
    PyConfig_InitIsolatedConfig(&config);
    config.buffered_stdio = 0;
    config.write_bytecode = 0;
    config.install_signal_handlers = 0; // The interpreter is initialized on a worker.
    config.module_search_paths_set = 1;
    if (!PyStatus_Exception(status)) status = PyConfig_SetBytesString(&config, &config.home, home.UTF8String);
    // AppleFrameworkLoader resolves .fwork paths relative to sys.executable.
    if (!PyStatus_Exception(status)) status = PyConfig_SetBytesString(&config, &config.executable, NSBundle.mainBundle.executablePath.UTF8String);
    for (NSString *path in @[stdlib, [stdlib stringByAppendingPathComponent:@"lib-dynload"], app, packages]) {
        if (PyStatus_Exception(status)) break;
        wchar_t *wide = Py_DecodeLocale(path.UTF8String, NULL);
        if (!wide) { status = PyStatus_NoMemory(); break; }
        status = PyWideStringList_Append(&config.module_search_paths, wide);
        PyMem_RawFree(wide);
    }
    if (!PyStatus_Exception(status)) status = Py_InitializeFromConfig(&config);
    NSString *failure = PyStatus_Exception(status) ?
        [NSString stringWithUTF8String:status.err_msg ?: "Python 初始化失败。"] : nil;
    PyConfig_Clear(&config);
    if (failure) {
        if (error) *error = LGError(failure);
        return NO;
    }
    PyEval_SaveThread();
    return YES;
}

@implementation LGPythonBridge
+ (NSData *)resolveURLString:(NSString *)urlString error:(NSError **)error {
    if ([NSThread isMainThread]) {
        if (error) *error = LGError(@"解析任务必须在后台工作队列运行。");
        return nil;
    }
    @synchronized(self) {
        if (!LGInitializePython(error)) return nil;
    }
    PyGILState_STATE state = PyGILState_Ensure();
    PyObject *module = PyImport_ImportModule("libreget_engine");
    PyObject *function = module ? PyObject_GetAttrString(module, "resolve_json") : NULL;
    PyObject *url = function ? PyUnicode_FromString(urlString.UTF8String) : NULL;
    PyObject *result = url ? PyObject_CallOneArg(function, url) : NULL;
    NSData *data = nil;
    if (result) {
        Py_ssize_t length = 0;
        const char *json = PyUnicode_AsUTF8AndSize(result, &length);
        if (json) data = [NSData dataWithBytes:json length:(NSUInteger)length];
    }
    if (!data && error) *error = LGError(LGPythonException());
    Py_XDECREF(result); Py_XDECREF(url); Py_XDECREF(function); Py_XDECREF(module);
    PyGILState_Release(state);
    return data;
}
@end
