import SwiftUI
import UIKit
import AVKit

enum AppPalette {
    static let canvas = Color(red: 0.08, green: 0.08, blue: 0.09)
    static let surface = Color(red: 0.14, green: 0.14, blue: 0.15)
    static let accent = Color(red: 1.0, green: 0.62, blue: 0.04)
    static let muted = Color(red: 0.62, green: 0.62, blue: 0.64)
}

struct ContentView: View {
    var body: some View {
        TabView {
            ParseMediaView()
                .tabItem { Label("解析", systemImage: "sparkle.magnifyingglass") }
            DownloadsView()
                .tabItem { Label("下载", systemImage: "arrow.down.circle") }
            SavedFilesView()
                .tabItem { Label("文件", systemImage: "folder") }
        }
        .tint(AppPalette.accent)
        .background(AppPalette.canvas)
    }
}

private struct DownloadsView: View {
    @ObservedObject private var store = DownloadStore.shared
    @State private var showingAdd = false

    var body: some View {
        NavigationStack {
            Group {
                if store.items.isEmpty {
                    emptyState
                } else {
                    List {
                        Section {
                            Label {
                                Text("在“解析”中粘贴分享链接，选择媒体或清晰度后加入队列。音视频分轨会在本机合并。")
                                    .font(.footnote)
                                    .foregroundStyle(AppPalette.muted)
                                    .fixedSize(horizontal: false, vertical: true)
                            } icon: {
                                Image(systemName: "info.circle")
                                    .foregroundStyle(AppPalette.accent)
                            }
                            .listRowBackground(AppPalette.surface)
                            Text("当前版本 \(Bundle.main.object(forInfoDictionaryKey: "CFBundleShortVersionString") as? String ?? "—")（\(Bundle.main.object(forInfoDictionaryKey: "CFBundleVersion") as? String ?? "—")）")
                                .font(.caption2)
                                .foregroundStyle(AppPalette.muted)
                                .listRowBackground(AppPalette.surface)
                        }

                        if !store.activeItems.isEmpty {
                            Section("进行中 · \(store.activeItems.count)") {
                                ForEach(store.activeItems) { item in
                                    DownloadRow(item: item, store: store)
                                }
                            }
                        }

                        let finished = store.items.filter { $0.status == .completed || $0.status == .failed }
                        if !finished.isEmpty {
                            Section("最近任务 · \(finished.count)") {
                                ForEach(finished.sorted { $0.createdAt > $1.createdAt }) { item in
                                    DownloadRow(item: item, store: store)
                                }
                                .onDelete { offsets in
                                    let list = finished.sorted { $0.createdAt > $1.createdAt }
                                    offsets.map { list[$0].id }.forEach(store.remove)
                                }
                            }
                        }
                    }
                    .listStyle(.insetGrouped)
                    .scrollContentBackground(.hidden)
                }
            }
            .background(AppPalette.canvas)
            .navigationTitle("LibreGet")
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button { showingAdd = true } label: {
                        Image(systemName: "plus")
                            .font(.system(size: 17, weight: .semibold))
                    }
                    .accessibilityLabel("解析并添加媒体")
                }
            }
            .sheet(isPresented: $showingAdd) {
                ParseMediaView(isSheet: true)
                    .presentationDetents([.large])
                    .presentationDragIndicator(.visible)
            }
        }
    }

    private var emptyState: some View {
        VStack(spacing: 16) {
            Image(systemName: "arrow.down.to.line")
                .font(.system(size: 36, weight: .regular))
                .foregroundStyle(AppPalette.accent)
                .frame(width: 76, height: 76)
                .background(AppPalette.surface, in: RoundedRectangle(cornerRadius: 22))

            VStack(spacing: 6) {
                Text("下载队列为空")
                    .font(.title3.weight(.semibold))
                Text("先解析视频网页或分享链接，再选择格式开始下载。")
                    .font(.subheadline)
                    .foregroundStyle(AppPalette.muted)
            }

            Button { showingAdd = true } label: {
                Label("解析链接", systemImage: "plus")
                    .font(.subheadline.weight(.semibold))
                    .padding(.horizontal, 18)
                    .padding(.vertical, 11)
                    .background(AppPalette.accent, in: RoundedRectangle(cornerRadius: 8))
                    .foregroundStyle(.black)
            }
            .buttonStyle(.plain)
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .padding(24)
    }
}

private struct DownloadRow: View {
    let item: DownloadItem
    @ObservedObject var store: DownloadStore

    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack(alignment: .top, spacing: 12) {
                Image(systemName: symbol)
                    .font(.system(size: 17, weight: .medium))
                    .foregroundStyle(iconColor)
                    .frame(width: 28, height: 28)
                    .background(iconColor.opacity(0.13), in: RoundedRectangle(cornerRadius: 7))

                VStack(alignment: .leading, spacing: 4) {
                    Text(item.title)
                        .font(.subheadline.weight(.medium))
                        .lineLimit(2)
                        .textSelection(.enabled)
                    Text(statusText)
                        .font(.caption)
                        .foregroundStyle(statusColor)
                }

                Spacer(minLength: 8)

                Menu {
                    switch item.status {
                    case .downloading, .queued, .processing:
                        Button { store.cancel(item.id) } label: {
                            Label("取消下载", systemImage: "xmark.circle")
                        }
                    case .failed:
                        Button { store.retry(item.id) } label: {
                            Label("重试", systemImage: "arrow.clockwise")
                        }
                        Button {
                            let version = Bundle.main.object(forInfoDictionaryKey: "CFBundleShortVersionString") as? String ?? "—"
                            let build = Bundle.main.object(forInfoDictionaryKey: "CFBundleVersion") as? String ?? "—"
                            let details = (item.diagnostics ?? []).map { "\($0.stage): \($0.domain) (\($0.code))" }
                            UIPasteboard.general.string = (["LibreGet \(version)（\(build)）", item.errorMessage ?? "下载失败"] + details).joined(separator: "\n")
                        } label: {
                            Label("复制错误详情", systemImage: "doc.on.doc")
                        }
                    case .completed:
                        if let url = store.fileURL(for: item) {
                            ShareLink(item: url) {
                                Label("分享或存储文件", systemImage: "square.and.arrow.up")
                            }
                        }
                    }
                    Button(role: .destructive) { store.remove(item.id) } label: {
                        Label("移除", systemImage: "trash")
                    }
                } label: {
                    Image(systemName: "ellipsis")
                        .font(.system(size: 16, weight: .semibold))
                        .foregroundStyle(AppPalette.muted)
                        .frame(width: 32, height: 32)
                        .contentShape(Rectangle())
                }
                .accessibilityLabel("更多下载操作")
            }

            if item.status == .downloading || item.status == .processing {
                ProgressView(value: item.progress)
                    .tint(AppPalette.accent)
                HStack {
                    Text(item.status == .processing ? "正在整理媒体" : item.expectedBytes > 0 ? "\(Int(item.progress * 100))%" : "正在接收")
                    Spacer()
                    Text(store.fileSizeDescription(for: item))
                }
                .font(.caption2.monospacedDigit())
                .foregroundStyle(AppPalette.muted)
            } else if let error = item.errorMessage, item.status == .failed {
                Text(error)
                    .font(.caption)
                    .foregroundStyle(.red.opacity(0.9))
                    .lineLimit(2)
            } else if item.status == .completed {
                Text(store.fileSizeDescription(for: item))
                    .font(.caption)
                    .foregroundStyle(AppPalette.muted)
            }
        }
        .padding(.vertical, 5)
        .listRowBackground(AppPalette.surface)
    }

    private var symbol: String {
        switch item.status {
        case .queued: "clock"
        case .downloading: "arrow.down.circle.fill"
        case .processing: "gearshape.2.fill"
        case .completed: "checkmark.circle.fill"
        case .failed: "exclamationmark.circle.fill"
        }
    }

    private var iconColor: Color {
        switch item.status {
        case .queued: AppPalette.muted
        case .downloading: AppPalette.accent
        case .processing: AppPalette.accent
        case .completed: .green
        case .failed: .red
        }
    }

    private var statusColor: Color {
        item.status == .failed ? .red : AppPalette.muted
    }

    private var statusText: String {
        switch item.status {
        case .queued: "等待下载"
        case .downloading: item.parts?.contains(where: { $0.transport == "app-stream" && $0.stagedFilename == nil }) == true ? "正在下载，请保持 App 在前台" : "正在下载"
        case .processing: "正在合并或整理媒体"
        case .completed: "已完成"
        case .failed: "下载失败"
        }
    }
}

private struct SavedFilesView: View {
    @ObservedObject private var store = DownloadStore.shared
    @State private var playback: PlaybackFile?

    var body: some View {
        NavigationStack {
            Group {
                if store.completedItems.isEmpty {
                    VStack(spacing: 12) {
                        Image(systemName: "folder")
                            .font(.system(size: 34))
                            .foregroundStyle(AppPalette.muted)
                        Text("还没有已完成的文件")
                            .font(.headline)
                        Text("完成的下载会保存在本机，并可通过分享菜单存入“文件”。")
                            .font(.subheadline)
                            .foregroundStyle(AppPalette.muted)
                            .multilineTextAlignment(.center)
                    }
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
                    .padding(28)
                } else {
                    List {
                        Section {
                            ForEach(store.completedItems) { item in
                                HStack(spacing: 12) {
                                    Image(systemName: "doc.fill")
                                        .foregroundStyle(AppPalette.accent)
                                        .frame(width: 28)
                                    VStack(alignment: .leading, spacing: 4) {
                                        Text(item.title).font(.subheadline.weight(.medium)).lineLimit(2)
                                        Text(store.fileSizeDescription(for: item))
                                            .font(.caption)
                                            .foregroundStyle(AppPalette.muted)
                                    }
                                    Spacer(minLength: 8)
                                    if let url = store.fileURL(for: item) {
                                        if ["mp4", "mov", "m4v", "m4a", "mp3", "aac", "wav", "movpkg"].contains(url.pathExtension.lowercased()) {
                                            Button { playback = PlaybackFile(url: url, title: item.title) } label: {
                                                Image(systemName: "play.circle").frame(width: 36, height: 36)
                                            }
                                            .buttonStyle(.borderless)
                                            .accessibilityLabel("播放 \(item.title)")
                                        }
                                        ShareLink(item: url) {
                                            Image(systemName: "square.and.arrow.up")
                                                .frame(width: 36, height: 36)
                                        }
                                        .accessibilityLabel("分享或存储 \(item.title)")
                                    }
                                }
                                .padding(.vertical, 4)
                                .listRowBackground(AppPalette.surface)
                                .swipeActions {
                                    Button(role: .destructive) { store.remove(item.id) } label: {
                                        Label("删除", systemImage: "trash")
                                    }
                                }
                            }
                        }
                    }
                    .listStyle(.insetGrouped)
                    .scrollContentBackground(.hidden)
                }
            }
            .background(AppPalette.canvas)
            .navigationTitle("已保存")
            .sheet(item: $playback) { file in
                MediaPlaybackSheet(file: file)
            }
        }
    }
}

private struct PlaybackFile: Identifiable {
    let id = UUID()
    let url: URL
    let title: String
}

private struct MediaPlaybackSheet: View {
    let file: PlaybackFile
    @Environment(\.dismiss) private var dismiss
    @State private var player: AVPlayer

    init(file: PlaybackFile) {
        self.file = file
        _player = State(initialValue: AVPlayer(url: file.url))
    }

    var body: some View {
        NavigationStack {
            VideoPlayer(player: player)
                .navigationTitle(file.title)
                .navigationBarTitleDisplayMode(.inline)
                .toolbar {
                    ToolbarItem(placement: .navigationBarTrailing) {
                        Button("完成") { dismiss() }
                    }
                }
                .onAppear { player.play() }
                .onDisappear { player.pause() }
        }
    }
}
