#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN
@interface LGPythonBridge : NSObject
+ (nullable NSData *)resolveURLString:(NSString *)urlString
                               error:(NSError * _Nullable * _Nullable)error
    NS_SWIFT_NAME(resolve(url:));
@end
NS_ASSUME_NONNULL_END
