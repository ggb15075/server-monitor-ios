import Foundation

enum MediaKind: String, Codable {
    case video, audio, image, file
}

struct MediaFormat: Identifiable, Codable, Equatable {
    var id: String
    var url: String
    var fileExtension: String
    var quality: String
    var kind: MediaKind
    var width: Int? = nil
    var height: Int? = nil
    var approximateBytes: Int64? = nil
    var headers: [String: String] = [:]
    var audioURL: String? = nil
    var audioHeaders: [String: String]? = nil
    var protocolHint: String? = nil

    var detail: String {
        var parts = [fileExtension.uppercased()]
        if let width, let height { parts.append("\(width) × \(height)") }
        if audioURL != nil { parts.append("含音轨 · 本机合并") }
        if protocolHint?.contains("m3u8") == true || URL(string: url)?.pathExtension == "m3u8" {
            parts.append("HLS 离线媒体")
        }
        if let approximateBytes, approximateBytes > 0 {
            parts.append("约 " + ByteCountFormatter.string(fromByteCount: approximateBytes, countStyle: .file))
        }
        return parts.joined(separator: " · ")
    }
}

struct ResolvedMedia: Codable {
    var originalURL: String
    var title: String
    var author: String? = nil
    var thumbnail: String? = nil
    var duration: Double? = nil
    var extractor: String
    var formats: [MediaFormat]
}

enum MediaResolveError: LocalizedError {
    case invalidURL
    case noMedia
    case failed(String)

    var errorDescription: String? {
        switch self {
        case .invalidURL: return "请粘贴视频网页、分享链接或文件链接，也可以粘贴整段分享文字。"
        case .noMedia: return "没有解析到可下载媒体。该内容可能需要登录、已失效，或当前解析器暂不支持。"
        case .failed(let message): return message
        }
    }
}
