import SwiftUI
import AVKit
import AVFoundation

struct MediaPreviewRequest: Identifiable {
    let id = UUID()
    let media: ResolvedMedia
    let format: MediaFormat
    let startFloating: Bool

    init(media: ResolvedMedia, format: MediaFormat, startFloating: Bool = false) {
        self.media = media
        self.format = format
        self.startFloating = startFloating
    }

    static func canPreview(_ format: MediaFormat) -> Bool {
        guard [.video, .audio].contains(format.kind), PreviewNetworkPolicy.url(format.url) != nil else { return false }
        let hint = format.protocolHint?.lowercased() ?? ""
        return !hint.contains("dash_segments") && !hint.contains("ism") && URL(string: format.url)?.pathExtension.lowercased() != "mpd"
    }
}

struct MediaPreviewSheet: View {
    let request: MediaPreviewRequest
    @Environment(\.dismiss) private var dismiss
    @ObservedObject private var session = MediaPreviewSession.shared

    var body: some View {
        NavigationStack {
            VStack(spacing: 18) {
                PreviewPlayerView(controller: session.controller)
                    .aspectRatio(16 / 9, contentMode: .fit)
                    .background(.black)
                VStack(alignment: .leading, spacing: 12) {
                    Text(request.media.title).font(.headline).lineLimit(3)
                    if session.isPreparing {
                        HStack { ProgressView(); Text(session.status).font(.subheadline) }
                    } else {
                        Text(session.status).font(.subheadline).foregroundStyle(.secondary)
                    }
                    if let notice = session.notice {
                        Label(notice, systemImage: "info.circle")
                            .font(.footnote).foregroundStyle(.orange)
                    }
                    if let failure = session.errorMessage {
                        Label(failure, systemImage: "exclamationmark.triangle")
                            .font(.footnote).foregroundStyle(.orange).textSelection(.enabled)
                        Button("重新播放") { Task { await open(force: true) } }
                    }
                    if request.format.kind == .video {
                        Button {
                            if session.showFloatingWindow(for: request.id) { dismiss() }
                        } label: {
                            Label("App 内悬浮播放", systemImage: "pip.enter")
                        }
                        .disabled(session.isPreparing || session.errorMessage != nil)
                        Text(AVPictureInPictureController.isPictureInPictureSupported()
                             ? "播放后轻点画面，在系统控制栏点画中画按钮即可悬浮播放；播放时返回主屏幕也可自动进入画中画。"
                             : "当前设备不支持系统画中画，可在播放器内观看。")
                            .font(.footnote).foregroundStyle(.secondary)
                    }
                }
                .padding(.horizontal)
                Spacer(minLength: 0)
            }
            .navigationTitle(request.format.kind == .audio ? "音频播放" : "小窗播放")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .confirmationAction) {
                    Button("关闭") { dismiss() }
                }
            }
        }
        .task(id: request.id) { await open() }
        .onDisappear { session.inlineDidDisappear(request.id) }
    }

    @MainActor
    private func open(force: Bool = false) async {
        await session.open(request, force: force)
        guard !Task.isCancelled, request.startFloating, !session.isPreparing, session.errorMessage == nil else { return }
        if session.showFloatingWindow(for: request.id) { dismiss() }
    }
}

private struct PreviewPlayerView: UIViewControllerRepresentable {
    let controller: AVPlayerViewController
    func makeUIViewController(context: Context) -> AVPlayerViewController { controller }
    func updateUIViewController(_ uiViewController: AVPlayerViewController, context: Context) {}
    // AVKit owns the PiP transition. Do not detach its player on dismantle;
    // the process-wide session retains the controller until PiP has stopped.
    static func dismantleUIViewController(_ uiViewController: AVPlayerViewController, coordinator: ()) {}
}

private struct PreviewFailure: LocalizedError {
    let message: String
    var errorDescription: String? { message }
}

@MainActor
private final class MediaPreviewSession: NSObject, ObservableObject, AVPlayerViewControllerDelegate {
    static let shared = MediaPreviewSession()
    let controller = AVPlayerViewController()
    @Published private(set) var isPreparing = false
    @Published private(set) var status = "准备播放…"
    @Published private(set) var notice: String?
    @Published private(set) var errorMessage: String?
    private var requestID: UUID?
    private var generation = UUID()
    private var player: AVPlayer?
    private var floatingWindow: UIWindow?
    private var floatingController: AVPlayerViewController?
    private var sourceAssets: [AVURLAsset] = []
    private var observations: [NSKeyValueObservation] = []
    private var notifications: [NSObjectProtocol] = []
    private var inlineVisible = false
    private var pictureInPicture = false
    private var pictureInPictureStarting = false
    private var restoringInterface = false

    override init() {
        super.init()
        controller.delegate = self
        controller.showsPlaybackControls = true
        controller.allowsPictureInPicturePlayback = true
        controller.canStartPictureInPictureAutomaticallyFromInline = true
        controller.updatesNowPlayingInfoCenter = true
    }

    func open(_ request: MediaPreviewRequest, force: Bool = false) async {
        inlineVisible = true
        if requestID == request.id && !force { return }
        teardown()
        let current = UUID()
        generation = current
        requestID = request.id
        isPreparing = true
        errorMessage = nil
        notice = nil
        status = "正在连接媒体…"
        defer { if generation == current { isPreparing = false } }
        do {
            guard MediaPreviewRequest.canPreview(request.format) else {
                throw PreviewFailure(message: "此记录不是可播放的音视频，请选择下载或换一个视频格式。")
            }
            try AVAudioSession.sharedInstance().setCategory(.playback, mode: .moviePlayback, options: [])
            try AVAudioSession.sharedInstance().setActive(true)
            try Task.checkCancellation()
            guard generation == current else { return }
            let item: AVPlayerItem
            do {
                item = try await makeItem(request.format)
            } catch {
                try Task.checkCancellation()
                guard let alternate = request.media.formats.first(where: {
                    $0.id != request.format.id && $0.kind == request.format.kind && $0.audioURL == nil && MediaPreviewRequest.canPreview($0)
                }) else { throw error }
                sourceAssets.removeAll()
                item = try await makeItem(alternate)
                notice = "所选格式暂不能流式播放，已切换到 \(alternate.quality)。下载时仍可选择原格式。"
            }
            try Task.checkCancellation()
            guard generation == current else { return }
            item.preferredForwardBufferDuration = 8
            let player = AVPlayer(playerItem: item)
            player.automaticallyWaitsToMinimizeStalling = true
            self.player = player
            controller.player = player
            observe(item: item, player: player, generation: current)
            status = "正在缓冲…"
            player.play()
            // Keep the loading sheet visible until AVPlayer accepts the item.
            // Otherwise an asynchronously rejected item would disappear into
            // the floating window before its actionable error could be shown.
            let deadline = Date().addingTimeInterval(20)
            while item.status == .unknown {
                try Task.checkCancellation()
                guard generation == current else { return }
                guard Date() < deadline else {
                    throw PreviewFailure(message: "媒体准备超时，请检查网络或重新解析链接。")
                }
                try await Task.sleep(nanoseconds: 100_000_000)
            }
            if item.status == .failed { throw item.error ?? PreviewFailure(message: "系统播放器未能打开该媒体。") }
        } catch is CancellationError {
            if generation == current { teardown(); status = "已取消播放" }
        } catch {
            if generation == current {
                errorMessage = "无法播放：\(error.localizedDescription) 如链接已失效，请重新解析；也可以选择下载后播放。"
                status = "播放未开始"
            }
        }
    }

    private func makeItem(_ format: MediaFormat) async throws -> AVPlayerItem {
        guard let videoURL = PreviewNetworkPolicy.url(format.url) else {
            throw PreviewFailure(message: "媒体地址无效。")
        }
        let hls = format.protocolHint?.lowercased().contains("m3u8") == true || videoURL.pathExtension.lowercased() == "m3u8"
        let videoAsset = try await PreviewNetworkPolicy.asset(videoURL, headers: format.headers)
        sourceAssets.append(videoAsset)
        guard let audioString = format.audioURL else {
            let playable = try await videoAsset.load(.isPlayable)
            guard playable else { throw PreviewFailure(message: "系统播放器不支持这个媒体编码或封装。") }
            return AVPlayerItem(asset: videoAsset)
        }
        guard !hls, let audioURL = PreviewNetworkPolicy.url(audioString) else {
            throw PreviewFailure(message: "此分轨格式暂不能流式组合，请选择带声音的 MP4 或 HLS。")
        }
        status = "正在准备视频与音轨…"
        let audioAsset = try await PreviewNetworkPolicy.asset(audioURL, headers: format.audioHeaders ?? format.headers)
        sourceAssets.append(audioAsset)
        async let videoTracks = videoAsset.loadTracks(withMediaType: .video)
        async let audioTracks = audioAsset.loadTracks(withMediaType: .audio)
        async let videoDuration = videoAsset.load(.duration)
        async let audioDuration = audioAsset.load(.duration)
        guard let sourceVideo = try await videoTracks.first, let sourceAudio = try await audioTracks.first else {
            throw PreviewFailure(message: "没有取得可组合的视频轨与音轨。")
        }
        let durations = try await (videoDuration, audioDuration)
        let duration = CMTimeMinimum(durations.0, durations.1)
        guard duration.isNumeric && duration.seconds > 0 else {
            throw PreviewFailure(message: "分轨媒体没有可用的时长，请选择其他格式。")
        }
        let composition = AVMutableComposition()
        guard let video = composition.addMutableTrack(withMediaType: .video, preferredTrackID: kCMPersistentTrackID_Invalid),
              let audio = composition.addMutableTrack(withMediaType: .audio, preferredTrackID: kCMPersistentTrackID_Invalid) else {
            throw PreviewFailure(message: "系统无法建立音视频播放轨道。")
        }
        // Composition keeps the remote AVURLAssets. Metadata and byte ranges
        // are fetched on demand; neither track is downloaded in full first.
        try video.insertTimeRange(CMTimeRange(start: .zero, duration: duration), of: sourceVideo, at: .zero)
        try audio.insertTimeRange(CMTimeRange(start: .zero, duration: duration), of: sourceAudio, at: .zero)
        video.preferredTransform = try await sourceVideo.load(.preferredTransform)
        return AVPlayerItem(asset: composition)
    }

    private func observe(item: AVPlayerItem, player: AVPlayer, generation current: UUID) {
        observations.append(item.observe(\.status, options: [.initial, .new]) { [weak self] item, _ in
            Task { @MainActor in
                guard let self, self.generation == current else { return }
                switch item.status {
                case .readyToPlay: self.status = "已就绪 · \(self.pictureInPicture ? "画中画播放" : "可流式播放")"
                case .failed:
                    self.errorMessage = self.playbackError(item.error)
                    self.status = "播放失败"
                default: break
                }
            }
        })
        observations.append(player.observe(\.timeControlStatus, options: [.new]) { [weak self] player, _ in
            Task { @MainActor in
                guard let self, self.generation == current, self.errorMessage == nil else { return }
                switch player.timeControlStatus {
                case .playing: self.status = self.pictureInPicture ? "画中画播放中" : "播放中"
                case .waitingToPlayAtSpecifiedRate: self.status = "正在缓冲…"
                case .paused: self.status = "已暂停"
                @unknown default: break
                }
            }
        })
        notifications.append(NotificationCenter.default.addObserver(forName: .AVPlayerItemFailedToPlayToEndTime, object: item, queue: .main) { [weak self] notification in
            let error = notification.userInfo?[AVPlayerItemFailedToPlayToEndTimeErrorKey] as? Error
            Task { @MainActor in
                guard let self, self.generation == current else { return }
                self.errorMessage = self.playbackError(error)
                self.status = "播放中断"
            }
        })
        notifications.append(NotificationCenter.default.addObserver(forName: .AVPlayerItemDidPlayToEndTime, object: item, queue: .main) { [weak self] _ in
            Task { @MainActor in if self?.generation == current { self?.status = "播放完成" } }
        })
    }

    private func playbackError(_ error: Error?) -> String {
        let detail = error?.localizedDescription ?? "系统未能解码该媒体。"
        return "\(detail) 可重新解析以刷新链接，或下载合并后播放；分轨在线播放受服务器的范围读取与系统编码支持影响。"
    }

    func inlineDidDisappear(_ id: UUID) {
        guard requestID == id else { return }
        inlineVisible = false
        if !pictureInPicture && !pictureInPictureStarting && !restoringInterface && floatingWindow == nil { teardown() }
    }

    @discardableResult
    func showFloatingWindow(for id: UUID) -> Bool {
        guard requestID == id, player?.currentItem?.status == .readyToPlay else { return false }
        guard let player, let scene = UIApplication.shared.connectedScenes
            .compactMap({ $0 as? UIWindowScene }).first(where: { $0.activationState == .foregroundActive }) else { return false }
        let floating = AVPlayerViewController()
        floating.player = player
        floating.delegate = self
        floating.allowsPictureInPicturePlayback = true
        floating.canStartPictureInPictureAutomaticallyFromInline = true
        floatingController = floating
        let host = PreviewFloatingHost(playerController: floating,
            close: { [weak self] in self?.closeFloatingWindow() },
            expand: { [weak self] in self?.expandFloatingWindow() })
        let window = PreviewOverlayWindow(windowScene: scene)
        window.windowLevel = .normal + 1
        window.backgroundColor = .clear
        window.rootViewController = host
        window.isHidden = false
        floatingWindow = window
        status = "App 内悬浮播放中"
        return true
    }

    private func closeFloatingWindow() {
        floatingWindow?.isHidden = true
        floatingWindow = nil
        if !pictureInPicture && !pictureInPictureStarting { teardown() }
    }

    private func expandFloatingWindow() {
        floatingWindow?.isHidden = true
        floatingWindow = nil
        floatingController?.player = nil
        floatingController = nil
        restorePlayerInterface(controller) { _ in }
    }

    private func teardown() {
        generation = UUID()
        player?.pause()
        controller.player = nil
        player = nil
        observations.removeAll()
        for token in notifications { NotificationCenter.default.removeObserver(token) }
        notifications.removeAll()
        sourceAssets.forEach { $0.cancelLoading() }
        sourceAssets.removeAll()
        floatingWindow?.isHidden = true
        floatingWindow = nil
        floatingController = nil
        requestID = nil
        pictureInPicture = false
        pictureInPictureStarting = false
        try? AVAudioSession.sharedInstance().setActive(false, options: .notifyOthersOnDeactivation)
    }

    func playerViewControllerWillStartPictureInPicture(_ playerViewController: AVPlayerViewController) {
        pictureInPictureStarting = true
    }

    func playerViewControllerDidStartPictureInPicture(_ playerViewController: AVPlayerViewController) {
        pictureInPictureStarting = false
        pictureInPicture = true
        status = "画中画播放中"
    }

    func playerViewController(_ playerViewController: AVPlayerViewController, failedToStartPictureInPictureWithError error: Error) {
        pictureInPictureStarting = false
        notice = "画中画未能启动：\(error.localizedDescription) 可以继续在此播放。"
        if !inlineVisible && floatingWindow == nil { teardown() }
    }

    func playerViewControllerShouldAutomaticallyDismissAtPictureInPictureStart(_ playerViewController: AVPlayerViewController) -> Bool { false }

    func playerViewController(_ playerViewController: AVPlayerViewController, restoreUserInterfaceForPictureInPictureStopWithCompletionHandler completionHandler: @escaping (Bool) -> Void) {
        restorePlayerInterface(playerViewController, completionHandler: completionHandler)
    }

    private func restorePlayerInterface(_ playerViewController: AVPlayerViewController, completionHandler: @escaping (Bool) -> Void) {
        if playerViewController.viewIfLoaded?.window != nil { completionHandler(true); return }
        restoringInterface = true
        DispatchQueue.main.async { [weak self] in
            guard let self else { completionHandler(false); return }
            let root = UIApplication.shared.connectedScenes.compactMap { $0 as? UIWindowScene }
                .filter { $0.activationState == .foregroundActive }
                .flatMap(\.windows).first(where: \.isKeyWindow)?.rootViewController
            var presenter = root
            while let next = presenter?.presentedViewController { presenter = next }
            guard let presenter, playerViewController.parent == nil, playerViewController.presentingViewController == nil else {
                self.restoringInterface = false
                completionHandler(playerViewController.viewIfLoaded?.window != nil)
                return
            }
            presenter.present(playerViewController, animated: true) {
                self.restoringInterface = false
                completionHandler(true)
            }
        }
    }

    func playerViewControllerDidStopPictureInPicture(_ playerViewController: AVPlayerViewController) {
        pictureInPicture = false
        pictureInPictureStarting = false
        if !inlineVisible && !restoringInterface && floatingWindow == nil && controller.viewIfLoaded?.window == nil { teardown() }
        else { status = player?.rate == 0 ? "已暂停" : "播放中" }
    }

    func playerViewController(_ playerViewController: AVPlayerViewController,
                              willEndFullScreenPresentationWithAnimationCoordinator coordinator: UIViewControllerTransitionCoordinator) {
        coordinator.animate(alongsideTransition: nil) { [weak self] _ in
            Task { @MainActor in
                guard let self, !self.inlineVisible, self.floatingWindow == nil,
                      !self.pictureInPicture, !self.pictureInPictureStarting, !self.restoringInterface,
                      playerViewController.viewIfLoaded?.window == nil else { return }
                self.teardown()
            }
        }
    }
}

/// The app overlay is separate from system PiP: it remains draggable inside
/// LibreGet even on formats/devices for which the system declines PiP.
@MainActor
private final class PreviewOverlayWindow: UIWindow {
    override func hitTest(_ point: CGPoint, with event: UIEvent?) -> UIView? {
        let hit = super.hitTest(point, with: event)
        return hit === rootViewController?.view ? nil : hit
    }
}

@MainActor
private final class PreviewFloatingHost: UIViewController {
    private let playerController: AVPlayerViewController
    private let panel = UIView()
    private let header = UIView()
    private let closeAction: () -> Void
    private let expandAction: () -> Void
    private var position: CGPoint?

    init(playerController: AVPlayerViewController, close: @escaping () -> Void, expand: @escaping () -> Void) {
        self.playerController = playerController
        self.closeAction = close
        self.expandAction = expand
        super.init(nibName: nil, bundle: nil)
    }
    required init?(coder: NSCoder) { fatalError("init(coder:) has not been implemented") }

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .clear
        panel.backgroundColor = .black
        panel.layer.cornerRadius = 12
        panel.clipsToBounds = true
        view.addSubview(panel)
        header.backgroundColor = UIColor(white: 0.13, alpha: 1)
        panel.addSubview(header)
        let close = UIButton(type: .system)
        close.setImage(UIImage(systemName: "xmark"), for: .normal)
        close.tintColor = .white
        close.accessibilityLabel = "关闭悬浮播放"
        close.addAction(UIAction { [weak self] _ in self?.closeAction() }, for: .touchUpInside)
        let expand = UIButton(type: .system)
        expand.setImage(UIImage(systemName: "arrow.up.left.and.arrow.down.right"), for: .normal)
        expand.tintColor = .white
        expand.accessibilityLabel = "展开播放器"
        expand.addAction(UIAction { [weak self] _ in self?.expandAction() }, for: .touchUpInside)
        header.addSubview(close)
        header.addSubview(expand)
        close.frame = CGRect(x: 0, y: 0, width: 44, height: 40)
        expand.tag = 102
        expand.frame = CGRect(x: 256, y: 0, width: 44, height: 40)
        let title = UILabel(frame: CGRect(x: 48, y: 0, width: 204, height: 40))
        title.text = "拖动可移动小窗"
        title.font = .systemFont(ofSize: 12)
        title.textColor = .lightGray
        title.tag = 103
        header.addSubview(title)
        header.addGestureRecognizer(UIPanGestureRecognizer(target: self, action: #selector(drag(_:))))
        addChild(playerController)
        panel.addSubview(playerController.view)
        playerController.didMove(toParent: self)
    }

    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        let safe = view.bounds.inset(by: view.safeAreaInsets).insetBy(dx: 8, dy: 8)
        let width = min(320, safe.width)
        let height = width * 9 / 16 + 40
        let origin = position ?? CGPoint(x: safe.maxX - width, y: safe.minY + 20)
        panel.frame = CGRect(x: min(max(origin.x, safe.minX), safe.maxX - width),
                             y: min(max(origin.y, safe.minY), safe.maxY - height), width: width, height: height)
        header.frame = CGRect(x: 0, y: 0, width: width, height: 40)
        header.viewWithTag(102)?.frame = CGRect(x: width - 44, y: 0, width: 44, height: 40)
        header.viewWithTag(103)?.frame = CGRect(x: 48, y: 0, width: width - 96, height: 40)
        playerController.view.frame = CGRect(x: 0, y: 40, width: width, height: height - 40)
    }

    @objc private func drag(_ gesture: UIPanGestureRecognizer) {
        let offset = gesture.translation(in: view)
        position = CGPoint(x: panel.frame.minX + offset.x, y: panel.frame.minY + offset.y)
        gesture.setTranslation(.zero, in: view)
        view.setNeedsLayout()
        view.layoutIfNeeded()
    }
}

private enum PreviewNetworkPolicy {
    static func url(_ value: String) -> URL? {
        guard let url = URL(string: value), ["http", "https"].contains(url.scheme?.lowercased() ?? ""),
              let host = url.host, !host.isEmpty, url.user == nil, url.password == nil,
              !value.unicodeScalars.contains(where: { $0.value < 32 }) else { return nil }
        return url
    }

    static func headers(_ input: [String: String], from source: URL, to destination: URL) -> [String: String] {
        let sameOrigin = source.scheme?.lowercased() == destination.scheme?.lowercased()
            && source.host?.lowercased() == destination.host?.lowercased() && source.port == destination.port
        return input.filter { key, value in
            let name = key.lowercased()
            guard key.range(of: "^[!#$%&'*+.^_`|~0-9A-Za-z-]+$", options: .regularExpression) != nil,
                  !value.contains("\r"), !value.contains("\n"),
                  !["host", "range", "content-length", "connection", "transfer-encoding", "accept-encoding", "proxy-authorization"].contains(name) else { return false }
            return sameOrigin || ["user-agent", "referer", "origin", "accept", "accept-language"].contains(name)
        }
    }

    static func asset(_ url: URL, headers input: [String: String]) async throws -> AVURLAsset {
        let prepared = try await PreviewURLProbe().prepare(url, headers: input)
        let headers = prepared.headers
        if headers.keys.contains(where: { $0.lowercased() == "authorization" }) {
            throw PreviewFailure(message: "这个格式需要额外的播放验证，请选择其他格式，或先下载后播放。")
        }
        var options: [String: Any] = [AVURLAssetHTTPCookiesKey: prepared.cookies]
        if let agent = headers.first(where: { $0.key.lowercased() == "user-agent" })?.value {
            options[AVURLAssetHTTPUserAgentKey] = agent
        }
        // AVFoundation has public options for UA and scoped cookies, but no
        // public Referer option. This compatibility key is isolated here. Pass
        // only public request context; never Cookie/Authorization/custom tokens
        // that AVFoundation might otherwise forward to HLS subresource hosts.
        // Apple identifies it as unsupported: developer.apple.com/forums/thread/671139
        let context = headers.filter { ["referer", "origin", "accept", "accept-language"].contains($0.key.lowercased()) }
        if !context.isEmpty { options["AVURLAssetHTTPHeaderFieldsKey"] = context }
        return AVURLAsset(url: prepared.url, options: options)
    }
}

private final class PreviewURLProbe: NSObject, URLSessionTaskDelegate {
    struct Prepared {
        let url: URL
        let headers: [String: String]
        let cookies: [HTTPCookie]
    }
    private var initialURL: URL?
    private var initialHeaders: [String: String] = [:]
    private var redirects = 0

    func prepare(_ url: URL, headers: [String: String]) async throws -> Prepared {
        initialURL = url
        initialHeaders = PreviewNetworkPolicy.headers(headers, from: url, to: url)
        let configuration = URLSessionConfiguration.ephemeral
        configuration.timeoutIntervalForRequest = 15
        configuration.timeoutIntervalForResource = 20
        configuration.urlCache = nil
        let session = URLSession(configuration: configuration)
        defer { session.finishTasksAndInvalidate() }
        var request = URLRequest(url: url)
        request.httpMethod = "HEAD"
        for (key, value) in initialHeaders { request.setValue(value, forHTTPHeaderField: key) }
        // HEAD resolves short-lived CDN redirects without preloading a video.
        // Some CDNs reject HEAD while accepting playback GET; only the final
        // URL and cookies are used and AVPlayer reports the playback status.
        let (_, response) = try await session.data(for: request, delegate: self)
        try Task.checkCancellation()
        guard let final = response.url, PreviewNetworkPolicy.url(final.absoluteString) != nil else {
            throw PreviewFailure(message: "服务器没有返回有效的媒体地址。")
        }
        let finalHeaders = PreviewNetworkPolicy.headers(initialHeaders, from: url, to: final)
        var cookies = configuration.httpCookieStorage?.cookies(for: final) ?? []
        if let value = finalHeaders.first(where: { $0.key.lowercased() == "cookie" })?.value {
            let properties: [HTTPCookiePropertyKey: Any] = [
                .domain: final.host ?? "", .path: "/", .secure: final.scheme?.lowercased() == "https" ? "TRUE" : "FALSE"
            ]
            for pair in value.split(separator: ";") {
                let parts = pair.split(separator: "=", maxSplits: 1, omittingEmptySubsequences: false)
                guard parts.count == 2 else { continue }
                var cookieProperties = properties
                cookieProperties[.name] = parts[0].trimmingCharacters(in: .whitespaces)
                cookieProperties[.value] = String(parts[1])
                if let cookie = HTTPCookie(properties: cookieProperties), !cookies.contains(where: { $0.name == cookie.name && $0.domain == cookie.domain }) {
                    cookies.append(cookie)
                }
            }
        }
        return Prepared(url: final, headers: finalHeaders, cookies: cookies)
    }

    func urlSession(_ session: URLSession, task: URLSessionTask, willPerformHTTPRedirection response: HTTPURLResponse,
                    newRequest request: URLRequest, completionHandler: @escaping (URLRequest?) -> Void) {
        redirects += 1
        guard redirects <= 5, let source = initialURL, let destination = request.url,
              PreviewNetworkPolicy.url(destination.absoluteString) != nil,
              !(response.url?.scheme?.lowercased() == "https" && destination.scheme?.lowercased() == "http") else {
            completionHandler(nil)
            task.cancel()
            return
        }
        var redirected = request
        redirected.httpMethod = "HEAD"
        redirected.allHTTPHeaderFields = PreviewNetworkPolicy.headers(initialHeaders, from: source, to: destination)
        completionHandler(redirected)
    }
}

