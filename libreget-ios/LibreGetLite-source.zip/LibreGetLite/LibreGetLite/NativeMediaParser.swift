import Foundation
import CryptoKit
#if canImport(FoundationNetworking)
import FoundationNetworking
#endif

// Native ports of the HTTP/JSON extractors in libreget-core/src/platforms.
// This parser uses its own anonymous cookie session. It never reads a browser's
// credentials and does not implement account, payment or DRM access workarounds.
struct NativeMediaParser {
    private static let desktopUA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Safari/537.36"
    private static let mobileUA = "Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Mobile/15E148 Safari/604.1"
    private static let session: URLSession = {
        let configuration = URLSessionConfiguration.ephemeral
        configuration.timeoutIntervalForRequest = 25
        configuration.timeoutIntervalForResource = 45
        configuration.httpShouldSetCookies = true
        return URLSession(configuration: configuration)
    }()

    func supports(_ url: URL) -> Bool {
        guard ["http", "https"].contains(url.scheme?.lowercased() ?? "") else { return false }
        return Self.platform(for: url) != nil
    }

    func resolve(_ url: URL) async throws -> ResolvedMedia {
        guard supports(url), let platform = Self.platform(for: url) else {
            throw NativeParserError.message("这个网站需要使用完整解析引擎。")
        }
        try Task.checkCancellation()
        switch platform {
        case "douyin": return try await resolveDouyin(url)
        case "bilibili": return try await resolveBilibili(url)
        case "tiktok": return try await resolveTikTok(url)
        case "twitter": return try await resolveX(url)
        default: throw NativeParserError.message("这个网站需要使用完整解析引擎。")
        }
    }

    private static func platform(for url: URL) -> String? {
        guard let host = url.host?.lowercased() else { return nil }
        if ["douyin.com", "iesdouyin.com", "amemv.com"].contains(where: { domainMatches(host, $0) }) { return "douyin" }
        if domainMatches(host, "bilibili.com") || host == "b23.tv" { return "bilibili" }
        if domainMatches(host, "tiktok.com") { return "tiktok" }
        if domainMatches(host, "x.com") || domainMatches(host, "twitter.com") { return "twitter" }
        return nil
    }

    private static func domainMatches(_ host: String, _ domain: String) -> Bool {
        host == domain || host.hasSuffix("." + domain)
    }

    private func fetch(_ url: URL, headers: [String: String] = [:], body: Data? = nil) async throws -> (Data, HTTPURLResponse) {
        guard ["http", "https"].contains(url.scheme?.lowercased() ?? ""), url.host != nil else {
            throw NativeParserError.message("解析器返回了无效的网址。")
        }
        var request = URLRequest(url: url)
        request.httpMethod = body == nil ? "GET" : "POST"
        request.httpBody = body
        request.setValue(Self.desktopUA, forHTTPHeaderField: "User-Agent")
        request.setValue("zh-CN,zh;q=0.9,en;q=0.7", forHTTPHeaderField: "Accept-Language")
        for (key, value) in headers { request.setValue(value, forHTTPHeaderField: key) }
        let (data, response) = try await Self.session.data(for: request)
        try Task.checkCancellation()
        guard let response = response as? HTTPURLResponse else {
            throw NativeParserError.message("网站没有返回有效的 HTTP 响应。")
        }
        guard (200..<300).contains(response.statusCode) else {
            throw NativeParserError.message("网页解析请求失败（HTTP \(response.statusCode)）；内容可能需要登录、已失效或访问受限。")
        }
        guard data.count <= 12 * 1024 * 1024 else {
            throw NativeParserError.message("网页响应过大，已停止解析。")
        }
        return (data, response)
    }

    private func json(_ url: URL, headers: [String: String] = [:]) async throws -> NativeObject {
        var requestHeaders = headers
        requestHeaders["Accept"] = "application/json, text/plain, */*"
        let (data, _) = try await fetch(url, headers: requestHeaders)
        return try Self.object(from: data)
    }

    // MARK: Douyin

    private func resolveDouyin(_ original: URL) async throws -> ResolvedMedia {
        var canonical = original
        if Self.douyinID(canonical) == nil {
            let (_, response) = try await fetch(canonical)
            guard let finalURL = response.url, Self.platform(for: finalURL) == "douyin" else {
                throw NativeParserError.message("抖音分享链接没有跳转到有效的作品页面。")
            }
            canonical = finalURL
        }
        guard let postID = Self.douyinID(canonical) else {
            throw NativeParserError.message("请粘贴抖音单个视频或图集的分享链接。")
        }
        let registration = URL(string: "https://ttwid.bytedance.com/ttwid/union/register/")!
        let payload = Data(#"{"region":"cn","aid":1768,"needFid":false,"service":"www.ixigua.com","migrate_info":{"ticket":"","source":"node"},"cbUrlProtocol":"https","union":true}"#.utf8)
        let (_, registered) = try await fetch(registration, headers: ["User-Agent": Self.mobileUA, "Content-Type": "application/json"], body: payload)
        guard let cookieHeader = registered.value(forHTTPHeaderField: "Set-Cookie"),
              let ttwid = Self.firstMatch(#"(?:^|[,;]\s*)ttwid=([^;,\s]+)"#, in: cookieHeader) else {
            throw NativeParserError.message("抖音没有返回匿名会话 Cookie，请稍后重试。")
        }
        let share = URL(string: "https://www.iesdouyin.com/share/video/\(postID)/")!
        let (data, _) = try await fetch(share, headers: ["User-Agent": Self.mobileUA, "Cookie": "ttwid=\(ttwid)"])
        return Self.addingSessionCookies(try Self.parseDouyinHTML(Self.html(data), original: original, postID: postID), sourceURL: share)
    }

    private static func douyinID(_ url: URL) -> String? {
        if let value = URLComponents(url: url, resolvingAgainstBaseURL: false)?.queryItems?.first(where: { $0.name == "modal_id" })?.value,
           isNumericID(value) { return value }
        let parts = url.pathComponents.filter { $0 != "/" }
        for index in parts.indices where ["video", "note", "slides"].contains(parts[index]) {
            if index + 1 < parts.count, isNumericID(parts[index + 1]) { return parts[index + 1] }
        }
        return nil
    }

    private static func parseDouyinHTML(_ html: String, original: URL, postID: String) throws -> ResolvedMedia {
        guard let data = jsonAssignment(#"(?:window\s*\.\s*)?_ROUTER_DATA\s*=\s*"#, html: html),
              let loaders = object(data["loaderData"]),
              let item = loaders.values.flatMap({ value -> [NativeObject] in
                  let info = object(object(value)?["videoInfoRes"])
                  return objects(info?["item_list"])
              }).first(where: { numericString($0["aweme_id"]) == postID }) else {
            throw NativeParserError.message("抖音分享页没有公开作品数据；作品可能已删除、需要登录或访问受限。")
        }
        let title = cleanTitle(string(item["desc"]), fallback: "抖音作品 \(postID)")
        let author = string(object(item["author"])?["nickname"])
        let video = object(item["video"]) ?? [:]
        let headers = ["User-Agent": mobileUA, "Referer": "https://www.iesdouyin.com/"]
        var formats: [MediaFormat] = []
        let images = objects(item["images"]).isEmpty ? objects(object(item["image_post_info"])?["images"]) : objects(item["images"])
        for (index, image) in images.enumerated() {
            let raw = firstURL(image["url_list"]) ?? firstURL(object(image["display_image"])?["url_list"])
            guard let raw else { continue }
            var format = MediaFormat(id: "douyin-image-\(index)", url: raw, fileExtension: imageExtension(raw), quality: "图片 \(index + 1)", kind: .image)
            format.width = integer(image["width"])
            format.height = integer(image["height"])
            format.headers = headers
            formats.append(format)
        }
        if formats.isEmpty {
            for (index, rate) in objects(video["bit_rate"]).enumerated() {
                guard let address = object(rate["play_addr"]), let raw = firstURL(address["url_list"]) else { continue }
                let width = integer(address["width"])
                let height = integer(address["height"])
                var format = MediaFormat(id: "douyin-rate-\(index)", url: raw, fileExtension: "mp4", quality: videoLabel(width: width, height: height, bitrate: integer(rate["bit_rate"])), kind: .video)
                format.width = width
                format.height = height
                format.headers = headers
                formats.append(format)
            }
            if let address = object(video["play_addr"]), let raw = firstURL(address["url_list"]), !formats.contains(where: { $0.url == raw }) {
                var format = MediaFormat(id: "douyin-original", url: raw, fileExtension: "mp4", quality: "原始返回版本", kind: .video)
                // The share page's dimensions are metadata, not proof that a
                // ratio URL can provide another resolution. Keep the real URL.
                format.width = integer(video["width"])
                format.height = integer(video["height"])
                format.headers = headers
                formats.append(format)
            }
        }
        guard !formats.isEmpty else { throw NativeParserError.message("这个抖音作品没有返回可下载的公开媒体。") }
        return ResolvedMedia(originalURL: original.absoluteString, title: title, author: author,
                             thumbnail: firstURL(object(video["cover"])?["url_list"]) ?? formats.first(where: { $0.kind == .image })?.url, duration: number(video["duration"]).map { $0 / 1000 },
                             extractor: "抖音 · 本机解析", formats: deduplicated(formats))
    }

    // MARK: Bilibili (WBI API, actual formats only)

    private func resolveBilibili(_ original: URL) async throws -> ResolvedMedia {
        var canonical = original
        if canonical.host?.lowercased() == "b23.tv" {
            let (_, response) = try await fetch(canonical)
            guard let finalURL = response.url, let host = finalURL.host, Self.domainMatches(host.lowercased(), "bilibili.com") else {
                throw NativeParserError.message("哔哩哔哩短链接没有跳转到有效的视频页面。")
            }
            canonical = finalURL
        }
        guard let identity = Self.bilibiliIdentity(canonical) else {
            throw NativeParserError.message("本机解析支持哔哩哔哩 BV/av 视频链接；番剧、直播和课程请使用完整引擎。")
        }
        let headers = ["Referer": "https://www.bilibili.com/", "User-Agent": Self.desktopUA]
        let nav = try await json(URL(string: "https://api.bilibili.com/x/web-interface/nav")!, headers: headers)
        let navigation = try Self.apiData(nav, allowAnonymousNavigation: true)
        guard let keys = Self.object(navigation["wbi_img"]),
              let imageURL = Self.string(keys["img_url"]), let image = URL(string: imageURL),
              let subURL = Self.string(keys["sub_url"]), let sub = URL(string: subURL) else {
            throw NativeParserError.message("哔哩哔哩没有返回 WBI 签名参数。")
        }
        let imageKey = image.deletingPathExtension().lastPathComponent
        let subKey = sub.deletingPathExtension().lastPathComponent
        let viewQuery = try Self.wbiQuery([identity.key: identity.value], imageKey: imageKey, subKey: subKey)
        let viewResponse = try await json(URL(string: "https://api.bilibili.com/x/web-interface/wbi/view?\(viewQuery)")!, headers: headers)
        let view = try Self.apiData(viewResponse)
        let page = URLComponents(url: canonical, resolvingAgainstBaseURL: false)?.queryItems?.first(where: { $0.name == "p" })?.value.flatMap(Int.init) ?? 1
        let pages = Self.objects(view["pages"])
        let chosenPage = pages.first(where: { Self.integer($0["page"]) == page })
        guard pages.isEmpty || chosenPage != nil else { throw NativeParserError.message("这个视频没有所选的分 P。") }
        guard let cid = Self.numericString(chosenPage?["cid"] ?? view["cid"]) else {
            throw NativeParserError.message("哔哩哔哩视频没有返回有效的 CID。")
        }
        var playParameters = ["cid": cid, "qn": "80", "fnver": "0", "fnval": "4048", "fourk": "1"]
        if let bvid = Self.string(view["bvid"]) { playParameters["bvid"] = bvid }
        else { playParameters[identity.key] = identity.value }
        let query = try Self.wbiQuery(playParameters, imageKey: imageKey, subKey: subKey)
        let response = try await json(URL(string: "https://api.bilibili.com/x/player/wbi/playurl?\(query)")!, headers: headers)
        let play = try Self.apiData(response)
        return try Self.parseBilibili(view: view, play: play, original: original, page: page)
    }

    private static func bilibiliIdentity(_ url: URL) -> (key: String, value: String)? {
        if let bvid = firstMatch(#"(?i)(?:^|/)(BV[A-Za-z0-9]{10})(?:/|$)"#, in: url.path) {
            return ("bvid", "BV" + bvid.dropFirst(2))
        }
        if let aid = firstMatch(#"(?i)(?:^|/)av([0-9]+)(?:/|$)"#, in: url.path) { return ("aid", aid) }
        return nil
    }

    private static func wbiQuery(_ parameters: [String: String], imageKey: String, subKey: String, timestamp: Int = Int(Date().timeIntervalSince1970)) throws -> String {
        let table = [46,47,18,2,53,8,23,32,15,50,10,31,58,3,45,35,27,43,5,49,33,9,42,19,29,28,14,39,12,38,41,13,37,48,7,16,24,55,40,61,26,17,0,1,60,51,30,4,22,25,54,21,56,59,6,63,57,62,11,36,20,34,44,52]
        let combined = Array((imageKey + subKey).utf8)
        guard combined.count >= 64 else { throw NativeParserError.message("哔哩哔哩 WBI 密钥格式不正确。") }
        let mixin = String(decoding: table.prefix(32).map { combined[$0] }, as: UTF8.self)
        var values = parameters
        values["wts"] = String(timestamp)
        let query = values.keys.sorted().map { key in
            let clean = (values[key] ?? "").filter { !"!'()*".contains($0) }
            return "\(percentEncode(key))=\(percentEncode(clean))"
        }.joined(separator: "&")
        let hash = Insecure.MD5.hash(data: Data((query + mixin).utf8)).map { String(format: "%02x", $0) }.joined()
        return query + "&w_rid=" + hash
    }

    private static func parseBilibili(view: NativeObject, play: NativeObject, original: URL, page: Int) throws -> ResolvedMedia {
        let headers = ["User-Agent": desktopUA, "Referer": "https://www.bilibili.com/"]
        let pageInfo = objects(view["pages"]).first { integer($0["page"]) == page }
        let baseTitle = cleanTitle(string(view["title"]), fallback: "哔哩哔哩视频")
        let part = string(pageInfo?["part"])
        let title = objects(view["pages"]).count > 1 ? baseTitle + " P\(page)" + (part.map { " · " + $0 } ?? "") : baseTitle
        var formats: [MediaFormat] = []
        if let dash = object(play["dash"]) {
            let audioTracks = objects(dash["audio"])
            let audio = audioTracks.filter { entry in
                let codec = string(entry["codecs"]) ?? "mp4a"
                return codec.hasPrefix("mp4a") && firstURL(entry["baseUrl"] ?? entry["base_url"]) != nil
            }.sorted { (integer($0["bandwidth"]) ?? 0) > (integer($1["bandwidth"]) ?? 0) }.first
            let audioURL = audio.flatMap { firstURL($0["baseUrl"] ?? $0["base_url"]) }
            let hasAudio = !audioTracks.isEmpty || !objects(object(dash["dolby"])?["audio"]).isEmpty || object(object(dash["flac"])?["audio"]) != nil
            guard !hasAudio || audioURL != nil else {
                throw NativeParserError.message("这个视频没有返回可在本机合并的 AAC 音轨，请使用完整解析引擎。")
            }
            let videos = objects(dash["video"]).sorted {
                let left = integer($0["height"]) ?? 0
                let right = integer($1["height"]) ?? 0
                if left != right { return left > right }
                return (integer($0["codecid"]) ?? 7) < (integer($1["codecid"]) ?? 7)
            }
            for (index, video) in videos.enumerated() {
                let codec = integer(video["codecid"]) ?? 7
                // iOS 16's native mux path targets AVC/HEVC plus AAC. Leave
                // AV1, FLAC and Dolby-only combinations to the full engine.
                guard [7, 12].contains(codec), let raw = firstURL(video["baseUrl"] ?? video["base_url"]) else { continue }
                let width = integer(video["width"])
                let height = integer(video["height"])
                let codecName = codec == 12 ? "HEVC" : "H.264"
                let quality = videoLabel(width: width, height: height) + " · " + codecName + (audioURL == nil ? " · 无音轨" : "")
                var format = MediaFormat(id: "bili-video-\(index)", url: raw, fileExtension: "mp4", quality: quality, kind: .video)
                format.width = width
                format.height = height
                if let videoBytes = int64(video["size"]), let audioBytes = audio.flatMap({ int64($0["size"]) }),
                   videoBytes <= Int64.max - audioBytes {
                    format.approximateBytes = videoBytes + audioBytes
                }
                format.headers = headers
                format.audioURL = audioURL
                format.audioHeaders = audioURL == nil ? nil : headers
                format.protocolHint = "dash"
                formats.append(format)
            }
            if let audio, let raw = audioURL {
                var format = MediaFormat(id: "bili-audio", url: raw, fileExtension: "m4a", quality: "音频 · AAC", kind: .audio)
                format.headers = headers
                format.approximateBytes = int64(audio["size"])
                formats.append(format)
            }
        } else {
            let segments = objects(play["durl"])
            guard segments.count <= 1 else {
                throw NativeParserError.message("这个视频返回多个分段，请使用完整引擎合并下载。")
            }
            if let segment = segments.first, let raw = firstURL(segment["url"]) {
                let actualFormat = string(play["format"]) ?? "mp4"
                guard !actualFormat.lowercased().hasPrefix("flv"), URL(string: raw)?.pathExtension.lowercased() != "flv" else {
                    throw NativeParserError.message("这个视频只返回 FLV 格式，请使用完整解析引擎。")
                }
                let returnedQuality = integer(play["quality"])
                let label = returnedQuality.flatMap { qnLabel($0) } ?? "服务器返回版本"
                var format = MediaFormat(id: "bili-muxed", url: raw, fileExtension: "mp4", quality: label, kind: .video)
                format.headers = headers
                format.approximateBytes = int64(segment["size"])
                formats.append(format)
            }
        }
        guard formats.contains(where: { $0.kind == .video }) else {
            throw NativeParserError.message("哔哩哔哩没有返回可用的视频流；可能需要登录、会员权限或其他编码支持。")
        }
        return ResolvedMedia(originalURL: original.absoluteString, title: title,
                             author: string(object(view["owner"])?["name"]), thumbnail: firstURL(view["pic"]),
                             duration: number(play["timelength"]).map { $0 / 1000 } ?? number(view["duration"]),
                             extractor: "哔哩哔哩 · 本机解析", formats: deduplicated(formats))
    }

    private static func apiData(_ response: NativeObject, allowAnonymousNavigation: Bool = false) throws -> NativeObject {
        let code = integer(response["code"]) ?? -1
        guard code == 0 || (allowAnonymousNavigation && code == -101) else {
            switch code {
            case -101, -102: throw NativeParserError.message("哔哩哔哩要求登录后才能访问这个内容。")
            case -10403, 10015002, 6002105: throw NativeParserError.message("这个哔哩哔哩内容需要账号或会员权限，本机匿名解析无法访问。")
            case -352, -412: throw NativeParserError.message("哔哩哔哩暂时限制了请求，请稍后重试。")
            default: throw NativeParserError.message("哔哩哔哩解析失败（代码 \(code)）；内容可能已失效或访问受限。")
            }
        }
        guard let data = object(response["data"]) ?? object(response["result"]) else {
            throw NativeParserError.message("哔哩哔哩没有返回有效的视频数据。")
        }
        return data
    }

    private static func qnLabel(_ value: Int) -> String? {
        [127: "8K", 126: "杜比视界", 125: "HDR", 120: "4K", 116: "1080p60", 112: "1080p 高码率", 80: "1080p", 64: "720p", 32: "480p", 16: "360p"][value]
    }

    // MARK: TikTok

    private func resolveTikTok(_ original: URL) async throws -> ResolvedMedia {
        var canonical = original
        if Self.tiktokID(canonical) == nil {
            let (_, response) = try await fetch(canonical)
            guard let finalURL = response.url, Self.platform(for: finalURL) == "tiktok" else {
                throw NativeParserError.message("TikTok 短链接没有跳转到有效的作品。")
            }
            canonical = finalURL
        }
        guard let postID = Self.tiktokID(canonical) else {
            throw NativeParserError.message("请粘贴 TikTok 单个视频或图集的分享链接。")
        }
        let headers = ["User-Agent": Self.desktopUA, "Referer": "https://www.tiktok.com/"]
        let (data, _) = try await fetch(URL(string: "https://www.tiktok.com/@i/video/\(postID)")!, headers: headers)
        return Self.addingSessionCookies(try Self.parseTikTokHTML(Self.html(data), original: original, postID: postID), sourceURL: canonical)
    }

    private static func tiktokID(_ url: URL) -> String? {
        let parts = url.pathComponents.filter { $0 != "/" }
        for index in parts.indices where ["video", "photo"].contains(parts[index]) {
            if index + 1 < parts.count, isNumericID(parts[index + 1]) { return parts[index + 1] }
        }
        return nil
    }

    private static func parseTikTokHTML(_ html: String, original: URL, postID: String) throws -> ResolvedMedia {
        var item: NativeObject?
        if let hydrated = scriptJSON(id: "__UNIVERSAL_DATA_FOR_REHYDRATION__", html: html) {
            let scope = object(hydrated["__DEFAULT_SCOPE__"]) ?? hydrated
            let detail = object(scope["webapp.video-detail"])
            if let status = integer(detail?["statusCode"]), status != 0 {
                throw NativeParserError.message("TikTok 作品不可用（代码 \(status)），可能已删除、需要登录或受地区限制。")
            }
            item = object(object(detail?["itemInfo"])?["itemStruct"])
        }
        if item == nil, let sigi = scriptJSON(id: "SIGI_STATE", html: html) ?? jsonAssignment(#"(?:window\s*\[\s*['\"]SIGI_STATE['\"]\s*\]|SIGI_STATE)\s*=\s*"#, html: html) {
            item = object(object(sigi["ItemModule"])?[postID])
        }
        if item == nil, let next = scriptJSON(id: "__NEXT_DATA__", html: html) {
            let properties = object(object(next["props"])?["pageProps"])
            item = object(object(properties?["itemInfo"])?["itemStruct"]) ?? object(properties?["itemStruct"])
        }
        guard let item else {
            throw NativeParserError.message("TikTok 没有返回公开媒体数据，可能出现验证码或访问限制。")
        }
        if let returnedID = numericString(item["id"]), returnedID != postID {
            throw NativeParserError.message("TikTok 返回的作品与请求链接不一致。")
        }
        let headers = ["User-Agent": desktopUA, "Referer": "https://www.tiktok.com/"]
        let title = cleanTitle(string(item["desc"]), fallback: "TikTok \(postID)")
        let video = object(item["video"]) ?? [:]
        var formats: [MediaFormat] = []
        for (index, image) in objects(object(item["imagePost"])?["images"]).enumerated() {
            guard let raw = firstURL(object(image["imageURL"])?["urlList"]) ?? firstURL(object(image["displayImage"])?["urlList"]) else { continue }
            var format = MediaFormat(id: "tiktok-image-\(index)", url: raw, fileExtension: imageExtension(raw), quality: "图片 \(index + 1)", kind: .image)
            format.headers = headers
            format.width = integer(image["imageWidth"])
            format.height = integer(image["imageHeight"])
            formats.append(format)
        }
        if formats.isEmpty {
            for (index, rate) in objects(video["bitrateInfo"]).enumerated() {
                guard let address = object(rate["PlayAddr"]), let raw = firstURL(address["UrlList"]) else { continue }
                let width = integer(address["Width"])
                let height = integer(address["Height"])
                var format = MediaFormat(id: "tiktok-rate-\(index)", url: raw, fileExtension: "mp4", quality: videoLabel(width: width, height: height, bitrate: integer(rate["Bitrate"])), kind: .video)
                format.width = width
                format.height = height
                format.approximateBytes = int64(address["DataSize"])
                format.headers = headers
                formats.append(format)
            }
            for key in ["playAddr", "play_addr", "downloadAddr", "download_addr"] {
                guard let raw = firstURL(video[key]), !formats.contains(where: { $0.url == raw }) else { continue }
                var format = MediaFormat(id: "tiktok-\(key)", url: raw, fileExtension: "mp4", quality: key.lowercased().contains("download") ? "下载版本" : "原始播放版本", kind: .video)
                format.width = integer(video["width"])
                format.height = integer(video["height"])
                format.headers = headers
                formats.append(format)
            }
        }
        guard !formats.isEmpty else { throw NativeParserError.message("这个 TikTok 作品没有返回可下载的媒体。") }
        return ResolvedMedia(originalURL: original.absoluteString, title: title,
                             author: string(object(item["author"])?["uniqueId"]), thumbnail: firstURL(video["cover"] ?? video["originCover"]),
                             duration: number(video["duration"]), extractor: "TikTok · 本机解析", formats: deduplicated(formats))
    }

    // MARK: X / Twitter public syndication

    private func resolveX(_ original: URL) async throws -> ResolvedMedia {
        guard let postID = Self.xID(original) else {
            throw NativeParserError.message("请粘贴 X / Twitter 单条公开帖子的链接。")
        }
        let token = Self.syndicationToken(postID)
        let endpoint = URL(string: "https://cdn.syndication.twimg.com/tweet-result?id=\(postID)&token=\(token)")!
        let response = try await json(endpoint, headers: ["Referer": "https://platform.twitter.com/"])
        return try Self.parseX(response, original: original, postID: postID)
    }

    private static func xID(_ url: URL) -> String? {
        let parts = url.pathComponents.filter { $0 != "/" }
        for index in parts.indices where ["status", "statuses"].contains(parts[index]) {
            if index + 1 < parts.count, isNumericID(parts[index + 1]) { return parts[index + 1] }
        }
        return nil
    }

    private static func syndicationToken(_ id: String) -> String {
        guard let value = Double(id), value.isFinite, value > 0 else { return "0" }
        let raw = value / 1e15 * Double.pi
        guard raw < Double(UInt64.max) else { return "0" }
        let integer = UInt64(raw)
        var output = String(integer, radix: 36)
        var fraction = raw - Double(integer)
        let alphabet = Array("0123456789abcdefghijklmnopqrstuvwxyz")
        for _ in 0..<12 where fraction > 0 {
            fraction *= 36
            let digit = min(35, max(0, Int(fraction)))
            output.append(alphabet[digit])
            fraction -= Double(digit)
        }
        while output.first == "0" { output.removeFirst() }
        while output.last == "0" { output.removeLast() }
        return output.isEmpty ? "0" : output
    }

    private static func parseX(_ response: NativeObject, original: URL, postID: String) throws -> ResolvedMedia {
        if ["TweetTombstone", "TweetUnavailable"].contains(string(response["__typename"]) ?? "") {
            throw NativeParserError.message("这个 X 帖子不公开、已删除或需要登录。")
        }
        if let returnedID = numericString(response["id_str"] ?? response["id"]), returnedID != postID {
            throw NativeParserError.message("X 返回的帖子与请求链接不一致。")
        }
        let headers = ["User-Agent": desktopUA, "Referer": "https://x.com/"]
        var media = objects(response["mediaDetails"])
        if media.isEmpty { media = objects(response["photos"]) }
        if media.isEmpty, let video = object(response["video"]) { media = [["type": "video", "video": video]] }
        var formats: [MediaFormat] = []
        for (mediaIndex, item) in media.enumerated() {
            let info = object(item["video_info"]) ?? object(item["video"])
            let variants = objects(info?["variants"]).sorted { (integer($0["bitrate"]) ?? 0) > (integer($1["bitrate"]) ?? 0) }
            let mp4 = variants.filter { (string($0["content_type"]) ?? string($0["type"]) ?? "") == "video/mp4" }
            let playable = mp4.isEmpty ? variants.filter { value in
                let type = string(value["content_type"]) ?? string(value["type"]) ?? ""
                return type.contains("mpegurl") || (string(value["url"]) ?? string(value["src"]) ?? "").contains(".m3u8")
            } : mp4
            for (variantIndex, variant) in playable.enumerated() {
                guard let raw = firstURL(variant["url"] ?? variant["src"]) else { continue }
                let size = firstMatch(#"/([0-9]+x[0-9]+)/"#, in: raw)?.split(separator: "x").compactMap { Int($0) }
                let width = size?.first
                let height = size?.count == 2 ? size?.last : nil
                let hls = raw.contains(".m3u8") || (string(variant["content_type"]) ?? string(variant["type"]) ?? "").contains("mpegurl")
                var format = MediaFormat(id: "x-\(mediaIndex)-\(variantIndex)", url: raw, fileExtension: "mp4", quality: "媒体 \(mediaIndex + 1) · " + videoLabel(width: width, height: height, bitrate: integer(variant["bitrate"])), kind: .video)
                format.width = width
                format.height = height
                format.headers = headers
                format.protocolHint = hls ? "hls" : nil
                formats.append(format)
            }
            if playable.isEmpty, info == nil,
               let raw = firstURL(item["media_url_https"] ?? item["media_url"] ?? item["url"]) {
                let photo = originalXPhoto(raw)
                var format = MediaFormat(id: "x-image-\(mediaIndex)", url: photo, fileExtension: imageExtension(photo), quality: "图片 \(mediaIndex + 1) · 原图", kind: .image)
                format.headers = headers
                let dimensions = object(item["original_info"])
                format.width = integer(dimensions?["width"])
                format.height = integer(dimensions?["height"])
                formats.append(format)
            }
        }
        guard !formats.isEmpty else {
            throw NativeParserError.message("X 公开接口没有返回媒体；帖子可能需要登录或暂时受限。")
        }
        return ResolvedMedia(originalURL: original.absoluteString, title: cleanTitle(string(response["text"]) ?? string(response["full_text"]), fallback: "X 帖子 \(postID)"),
                             author: string(object(response["user"])?["screen_name"]), thumbnail: firstURL(media.first?["media_url_https"] ?? media.first?["url"]),
                             duration: nil, extractor: "X / Twitter · 本机解析", formats: deduplicated(formats))
    }

    private static func originalXPhoto(_ raw: String) -> String {
        guard var components = URLComponents(string: raw) else { return raw }
        if let suffix = components.path.range(of: #":(?:small|medium|large|orig|thumb)$"#, options: .regularExpression) { components.path.removeSubrange(suffix) }
        var items = components.queryItems ?? []
        items.removeAll { $0.name == "name" }
        items.append(URLQueryItem(name: "name", value: "orig"))
        components.queryItems = items
        return components.url?.absoluteString ?? raw
    }

    // MARK: Pure parsing helpers

    private static func addingSessionCookies(_ media: ResolvedMedia, sourceURL: URL) -> ResolvedMedia {
        var result = media
        let sourceHost = sourceURL.host?.lowercased() ?? ""
        result.formats = media.formats.map { original in
            var format = original
            guard let url = URL(string: format.url), let host = url.host?.lowercased() else { return format }
            var cookies = session.configuration.httpCookieStorage?.cookies(for: url) ?? []
            // TikTok's anonymous media token is set by its web page but is also
            // required by its separate media CDN. Keep this transfer limited to
            // TikTok's media domains rather than arbitrary JSON-provided URLs.
            let tiktokMediaDomains = ["tiktok.com", "tiktokcdn.com", "tiktokcdn-us.com", "tiktokv.com", "muscdn.com", "byteoversea.com", "ibytedtos.com"]
            if domainMatches(sourceHost, "tiktok.com"), tiktokMediaDomains.contains(where: { domainMatches(host, $0) }) {
                for cookie in session.configuration.httpCookieStorage?.cookies(for: sourceURL) ?? [] where !cookies.contains(where: { $0.name == cookie.name }) {
                    cookies.append(cookie)
                }
            }
            if !cookies.isEmpty {
                format.headers["Cookie"] = HTTPCookie.requestHeaderFields(with: cookies)["Cookie"]
            }
            return format
        }
        return result
    }

    private static func object(_ value: Any?) -> NativeObject? { value as? NativeObject }
    private static func objects(_ value: Any?) -> [NativeObject] { value as? [NativeObject] ?? [] }
    private static func string(_ value: Any?) -> String? {
        guard let text = value as? String, !text.isEmpty else { return nil }
        return text
    }
    private static func number(_ value: Any?) -> Double? {
        if let value = value as? NSNumber { return value.doubleValue }
        if let value = value as? String { return Double(value) }
        return nil
    }
    private static func integer(_ value: Any?) -> Int? {
        guard let value = number(value), value.isFinite, value >= Double(Int.min), value < Double(Int.max) else { return nil }
        return Int(value)
    }
    private static func int64(_ value: Any?) -> Int64? {
        guard let value = number(value), value.isFinite, value >= 0, value < Double(Int64.max) else { return nil }
        return Int64(value)
    }
    private static func numericString(_ value: Any?) -> String? {
        let text: String?
        if let value = value as? String { text = value }
        else if let value = value as? NSNumber { text = value.stringValue }
        else { text = nil }
        return text.flatMap { isNumericID($0) ? $0 : nil }
    }
    private static func isNumericID(_ value: String) -> Bool {
        !value.isEmpty && value.utf8.allSatisfy { $0 >= 48 && $0 <= 57 }
    }
    private static func object(from data: Data) throws -> NativeObject {
        guard let value = try JSONSerialization.jsonObject(with: data) as? NativeObject else {
            throw NativeParserError.message("网站返回的数据格式不正确。")
        }
        return value
    }
    private static func html(_ data: Data) -> String {
        String(data: data, encoding: .utf8) ?? String(data: data, encoding: .isoLatin1) ?? ""
    }
    private static func firstURL(_ value: Any?) -> String? {
        if let raw = value as? String {
            let clean = raw.replacingOccurrences(of: "&amp;", with: "&").replacingOccurrences(of: "&#38;", with: "&").replacingOccurrences(of: "\\u0026", with: "&").replacingOccurrences(of: "\\/", with: "/")
            let normalized = clean.hasPrefix("//") ? "https:" + clean : clean
            guard let url = URL(string: normalized), ["https", "http"].contains(url.scheme?.lowercased() ?? ""),
                  let host = url.host, !host.isEmpty, url.user == nil, url.password == nil else { return nil }
            return url.absoluteString
        }
        if let list = value as? [Any] { return list.compactMap { firstURL($0) }.first }
        if let value = object(value) {
            for key in ["urlList", "url_list", "UrlList", "url", "src"] {
                if let raw = firstURL(value[key]) { return raw }
            }
        }
        return nil
    }
    private static func cleanTitle(_ value: String?, fallback: String) -> String {
        let line = value?.split(whereSeparator: { $0.isNewline }).map { $0.trimmingCharacters(in: .whitespacesAndNewlines) }.first(where: { !$0.isEmpty })
        return line.map { String($0.prefix(150)) } ?? fallback
    }
    private static func videoLabel(width: Int?, height: Int?, bitrate: Int? = nil) -> String {
        if let width, let height, width > 0, height > 0 { return "\(min(width, height))p" }
        if let height, height > 0 { return "\(height)p" }
        if let bitrate, bitrate > 0 { return "视频 · \(bitrate / 1000) kbps" }
        return "视频"
    }
    private static func imageExtension(_ raw: String) -> String {
        guard let url = URL(string: raw) else { return "jpg" }
        let queryFormat = URLComponents(url: url, resolvingAgainstBaseURL: false)?.queryItems?.first { $0.name == "format" }?.value
        let suffix = (queryFormat ?? url.pathExtension).lowercased()
        return ["jpg", "jpeg", "png", "webp", "gif", "heic", "avif"].contains(suffix) ? suffix : "jpg"
    }
    private static func deduplicated(_ formats: [MediaFormat]) -> [MediaFormat] {
        var seen = Set<String>()
        return formats.filter { seen.insert($0.url + "|" + ($0.audioURL ?? "")).inserted }
    }
    private static func percentEncode(_ text: String) -> String {
        text.addingPercentEncoding(withAllowedCharacters: CharacterSet(charactersIn: "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-._~")) ?? ""
    }
    private static func firstMatch(_ pattern: String, in text: String) -> String? {
        guard let expression = try? NSRegularExpression(pattern: pattern),
              let result = expression.firstMatch(in: text, range: NSRange(text.startIndex..., in: text)),
              result.numberOfRanges > 1, let range = Range(result.range(at: 1), in: text) else { return nil }
        return String(text[range])
    }
    private static func scriptJSON(id: String, html: String) -> NativeObject? {
        let escaped = NSRegularExpression.escapedPattern(for: id)
        let pattern = "(?is)<script\\b(?=[^>]*\\bid\\s*=\\s*['\"]" + escaped + "['\"])[^>]*>(.*?)</script>"
        guard let raw = firstMatch(pattern, in: html), let data = raw.data(using: .utf8) else { return nil }
        return try? object(from: data)
    }
    private static func jsonAssignment(_ pattern: String, html: String) -> NativeObject? {
        guard let regex = try? NSRegularExpression(pattern: pattern),
              let match = regex.firstMatch(in: html, range: NSRange(html.startIndex..., in: html)),
              let matchRange = Range(match.range, in: html) else { return nil }
        let tail = String(html[matchRange.upperBound...])
        guard let start = tail.firstIndex(of: "{") else { return nil }
        var depth = 0
        var inString = false
        var escaped = false
        for index in tail[start...].indices {
            let character = tail[index]
            if inString {
                if escaped { escaped = false }
                else if character == "\\" { escaped = true }
                else if character == "\"" { inString = false }
            } else {
                if character == "\"" { inString = true }
                else if character == "{" { depth += 1 }
                else if character == "}" {
                    depth -= 1
                    if depth == 0 {
                        let raw = String(tail[start...index])
                        return try? object(from: Data(raw.utf8))
                    }
                }
            }
        }
        return nil
    }

    #if NATIVE_PARSER_FIXTURES
    // Only compiled into the standalone fixture harness, never into the app.
    static func fixture(platform: String, payload: Data, auxiliary: Data? = nil, originalURL: String) throws -> ResolvedMedia {
        let url = URL(string: originalURL)!
        switch platform {
        case "douyin": return try parseDouyinHTML(html(payload), original: url, postID: douyinID(url) ?? "")
        case "tiktok": return try parseTikTokHTML(html(payload), original: url, postID: tiktokID(url) ?? "")
        case "twitter": return try parseX(object(from: payload), original: url, postID: xID(url) ?? "")
        case "bilibili": return try parseBilibili(view: apiData(object(from: payload)), play: apiData(object(from: auxiliary!)), original: url, page: 1)
        default: throw NativeParserError.message("Unknown fixture")
        }
    }
    static func fixtureWBI(_ parameters: [String: String], imageKey: String, subKey: String, timestamp: Int) throws -> String {
        try wbiQuery(parameters, imageKey: imageKey, subKey: subKey, timestamp: timestamp)
    }
    #endif
}

private typealias NativeObject = [String: Any]

private enum NativeParserError: LocalizedError {
    case message(String)
    var errorDescription: String? {
        switch self { case .message(let message): return message }
    }
}
