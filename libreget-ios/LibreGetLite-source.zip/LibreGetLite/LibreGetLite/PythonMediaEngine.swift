import Foundation

/// The interpreter is process-wide and all extraction runs on one worker queue.
/// WebKit callbacks run on the main thread while this queue releases the GIL.
final class PythonMediaEngine {
    static let shared = PythonMediaEngine()
    private let queue = DispatchQueue(label: "com.openselena.libreget.python", qos: .userInitiated)

    func resolve(_ url: URL) async throws -> ResolvedMedia {
        try Task.checkCancellation()
        let media: ResolvedMedia = try await withCheckedThrowingContinuation { continuation in
            queue.async {
                do {
                    let data = try LGPythonBridge.resolve(url: url.absoluteString)
                    let resolved = try JSONDecoder().decode(ResolvedMedia.self, from: data)
                    continuation.resume(returning: resolved)
                } catch {
                    continuation.resume(throwing: MediaResolveError.failed(error.localizedDescription))
                }
            }
        }
        try Task.checkCancellation()
        return media
    }
}
