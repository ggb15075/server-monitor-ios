import Foundation
import Combine

struct ParseRecord: Identifiable, Codable {
    var id: String { originalURL }
    let originalURL: String
    let title: String
    let author: String?
    let extractor: String
    let formatCount: Int
    let parsedAt: Date
}

@MainActor
final class ParseHistoryStore: ObservableObject {
    static let shared = ParseHistoryStore()
    @Published private(set) var records: [ParseRecord] = []
    private let storageKey = "libreget.ios.parse-history.v1"
    // Persist only the webpage and display metadata. Signed CDN links and
    // request headers stay in memory, then are refreshed after ten minutes.
    private var cached: [String: (media: ResolvedMedia, date: Date)] = [:]

    private init() {
        if let data = UserDefaults.standard.data(forKey: storageKey),
           let saved = try? JSONDecoder().decode([ParseRecord].self, from: data) {
            records = Array(saved.prefix(50))
        }
    }

    func record(_ media: ResolvedMedia) {
        let now = Date()
        records.removeAll { $0.originalURL == media.originalURL }
        records.insert(ParseRecord(originalURL: media.originalURL, title: media.title,
                                   author: media.author, extractor: media.extractor,
                                   formatCount: media.formats.count, parsedAt: now), at: 0)
        records = Array(records.prefix(50))
        cached[media.originalURL] = (media, now)
        let retained = Set(records.map(\.originalURL))
        cached = cached.filter { retained.contains($0.key) }
        persist()
    }

    func recentMedia(for record: ParseRecord) -> ResolvedMedia? {
        guard let value = cached[record.originalURL], Date().timeIntervalSince(value.date) < 600 else { return nil }
        return value.media
    }

    func remove(at offsets: IndexSet) {
        for index in offsets.sorted(by: >) where records.indices.contains(index) {
            cached[records[index].originalURL] = nil
            records.remove(at: index)
        }
        persist()
    }

    private func persist() {
        if let data = try? JSONEncoder().encode(records) { UserDefaults.standard.set(data, forKey: storageKey) }
    }
}
