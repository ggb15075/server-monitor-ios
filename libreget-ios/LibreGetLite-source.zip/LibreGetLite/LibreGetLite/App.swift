import SwiftUI
import UIKit

@main
struct LibreGetLiteApp: App {
    @UIApplicationDelegateAdaptor(AppDelegate.self) private var appDelegate

    var body: some Scene {
        WindowGroup {
            ContentView()
                .preferredColorScheme(.dark)
        }
    }
}

final class AppDelegate: NSObject, UIApplicationDelegate {
    private static var backgroundSessionCompletionHandlers: [String: () -> Void] = [:]

    static func finishBackgroundSession(identifier: String) {
        backgroundSessionCompletionHandlers.removeValue(forKey: identifier)?()
    }

    func application(
        _ application: UIApplication,
        handleEventsForBackgroundURLSession identifier: String,
        completionHandler: @escaping () -> Void
    ) {
        Self.backgroundSessionCompletionHandlers[identifier] = completionHandler
        _ = DownloadStore.shared
    }
}
