import SwiftUI
import UIKit

struct ParseMediaView: View {
    var isSheet = false
    @Environment(\.dismiss) private var dismiss
    @StateObject private var resolver = MediaResolver()
    @ObservedObject private var store = DownloadStore.shared
    @State private var input = ""
    @State private var parseTask: Task<Void, Never>?
    @State private var notice = ""
    @State private var showNotice = false
    @FocusState private var inputFocused: Bool

    var body: some View {
        NavigationStack {
            List {
                Section {
                    TextField("粘贴视频网页 / 分享链接或整段分享文字", text: $input, axis: .vertical)
                        .lineLimit(3...6)
                        .font(.subheadline)
                        .textInputAutocapitalization(.never)
                        .autocorrectionDisabled()
                        .keyboardType(.URL)
                        .focused($inputFocused)
                        .accessibilityLabel("待解析的分享链接")
                    HStack {
                        Button {
                            input = UIPasteboard.general.string ?? ""
                        } label: { Label("粘贴", systemImage: "doc.on.clipboard") }
                        .buttonStyle(.borderless)
                        Spacer()
                        if resolver.isResolving {
                            Button("取消") { parseTask?.cancel(); resolver.cancel() }
                                .buttonStyle(.borderless)
                        } else {
                            Button {
                                inputFocused = false
                                parseTask?.cancel()
                                parseTask = Task { await resolver.resolve(input) }
                            } label: { Label("解析链接", systemImage: "sparkle.magnifyingglass") }
                                .fontWeight(.semibold)
                                .buttonStyle(.borderless)
                                .disabled(input.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
                        }
                    }
                } header: { Text("解析媒体") }
                footer: {
                    Text("在本机解析媒体、选择清晰度后下载。支持分享短链；网站登录、地区限制和失效内容可能影响解析结果。")
                }
                .listRowBackground(AppPalette.surface)

                if resolver.isResolving {
                    Section {
                        HStack(spacing: 12) {
                            ProgressView().tint(AppPalette.accent)
                            Text(resolver.status).font(.subheadline)
                        }
                        .padding(.vertical, 6)
                    }.listRowBackground(AppPalette.surface)
                }
                if let error = resolver.errorMessage {
                    Section("解析结果") {
                        Label(error, systemImage: "exclamationmark.circle")
                            .font(.footnote)
                            .foregroundStyle(.orange)
                            .textSelection(.enabled)
                    }.listRowBackground(AppPalette.surface)
                }
                if let media = resolver.result {
                    Section {
                        VStack(alignment: .leading, spacing: 8) {
                            Text(media.title).font(.headline).textSelection(.enabled)
                            if let author = media.author, !author.isEmpty {
                                Text(author).font(.subheadline).foregroundStyle(AppPalette.muted)
                            }
                            HStack {
                                Label(media.extractor, systemImage: "iphone")
                                if let duration = media.duration, duration > 0 {
                                    Text("\(Int(duration) / 60):\(String(format: "%02d", Int(duration) % 60))")
                                        .monospacedDigit()
                                }
                            }
                            .font(.caption)
                            .foregroundStyle(AppPalette.muted)
                        }
                        .padding(.vertical, 4)
                    } header: { Text("已解析") }
                    .listRowBackground(AppPalette.surface)

                    Section {
                        ForEach(media.formats) { format in
                            Button { enqueue(media, format) } label: {
                                HStack(spacing: 12) {
                                    Image(systemName: symbol(format.kind))
                                        .font(.title3)
                                        .foregroundStyle(AppPalette.accent)
                                        .frame(width: 30)
                                    VStack(alignment: .leading, spacing: 5) {
                                        Text(format.quality).font(.subheadline.weight(.medium)).foregroundStyle(.primary)
                                        Text(format.detail).font(.caption).foregroundStyle(AppPalette.muted)
                                    }
                                    Spacer(minLength: 4)
                                    Image(systemName: "arrow.down.circle").foregroundStyle(AppPalette.accent)
                                }
                                .padding(.vertical, 4)
                            }
                            .buttonStyle(.borderless)
                        }
                        if media.formats.count > 1 && media.formats.allSatisfy({ $0.kind == .image }) {
                            Button {
                                let errors = media.formats.compactMap { store.enqueue(media: media, format: $0) }
                                notice = errors.isEmpty ? "已将全部图片加入下载队列。" : errors.joined(separator: "\n")
                                showNotice = true
                            } label: { Label("下载全部图片", systemImage: "square.stack.3d.down.right") }
                        }
                    } header: { Text("选择媒体 / 清晰度 · \(media.formats.count)") }
                    footer: { Text("分离的音视频轨道会下载后在本机合并。HLS 使用系统离线媒体包保存。") }
                    .listRowBackground(AppPalette.surface)
                } else if !resolver.isResolving && resolver.errorMessage == nil {
                    Section {
                        VStack(alignment: .leading, spacing: 12) {
                            Label("网页链接 → 媒体解析 → 选择格式 → 下载", systemImage: "play.rectangle")
                                .font(.subheadline.weight(.medium))
                            Text("原生解析器优先处理抖音、B站、TikTok 和 X；其他链接交给内置 yt-dlp 解析。解析过程无需自建服务器。")
                                .font(.footnote).foregroundStyle(AppPalette.muted)
                        }.padding(.vertical, 5)
                    }.listRowBackground(AppPalette.surface)
                }
            }
            .listStyle(.insetGrouped)
            .scrollContentBackground(.hidden)
            .background(AppPalette.canvas)
            .navigationTitle("LibreGet · 解析")
            .toolbar {
                if isSheet {
                    ToolbarItem(placement: .navigationBarLeading) { Button("关闭") { dismiss() } }
                }
            }
            .alert("下载队列", isPresented: $showNotice) { Button("好", role: .cancel) {} }
                message: { Text(notice) }
            .onDisappear { parseTask?.cancel(); resolver.cancel() }
        }
    }

    private func enqueue(_ media: ResolvedMedia, _ format: MediaFormat) {
        notice = store.enqueue(media: media, format: format) ?? "已加入下载队列，可在“下载”中查看进度。"
        showNotice = true
    }

    private func symbol(_ kind: MediaKind) -> String {
        switch kind {
        case .video: return "film"
        case .audio: return "waveform"
        case .image: return "photo"
        case .file: return "doc"
        }
    }
}
