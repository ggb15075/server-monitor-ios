import SwiftUI
import UIKit

struct ParseMediaView: View {
    var isSheet = false
    @Environment(\.dismiss) private var dismiss
    @StateObject private var resolver = MediaResolver()
    @ObservedObject private var store = DownloadStore.shared
    @ObservedObject private var history = ParseHistoryStore.shared
    @State private var input = ""
    @State private var parseTask: Task<Void, Never>?
    @State private var notice = ""
    @State private var showNotice = false
    @State private var selection: MediaPreviewRequest?
    @State private var showActions = false
    @State private var preview: MediaPreviewRequest?
    @FocusState private var inputFocused: Bool

    var body: some View {
        NavigationStack {
            List {
                Section {
                    TextField("粘贴视频网页 / 分享链接或整段分享文字", text: $input, axis: .vertical)
                        .lineLimit(3...6)
                        .font(.subheadline)
                        .textInputAutocapitalization(.never)
                        .autocorrectionDisabled()
                        .keyboardType(.URL)
                        .focused($inputFocused)
                        .accessibilityLabel("待解析的分享链接")
                    HStack {
                        Button {
                            input = UIPasteboard.general.string ?? ""
                        } label: { Label("粘贴", systemImage: "doc.on.clipboard") }
                        .buttonStyle(.borderless)
                        Spacer()
                        if resolver.isResolving {
                            Button("取消") { parseTask?.cancel(); resolver.cancel() }
                                .buttonStyle(.borderless)
                        } else {
                            Button {
                                parse(input)
                            } label: { Label("解析链接", systemImage: "sparkle.magnifyingglass") }
                                .fontWeight(.semibold)
                                .buttonStyle(.borderless)
                                .disabled(input.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
                        }
                    }
                } header: { Text("解析媒体") }
                footer: {
                    Text("在本机解析媒体、选择清晰度后下载。支持分享短链；网站登录、地区限制和失效内容可能影响解析结果。")
                }
                .listRowBackground(AppPalette.surface)

                if resolver.isResolving {
                    Section {
                        HStack(spacing: 12) {
                            ProgressView().tint(AppPalette.accent)
                            Text(resolver.status).font(.subheadline)
                        }
                        .padding(.vertical, 6)
                    }.listRowBackground(AppPalette.surface)
                }
                if let error = resolver.errorMessage {
                    Section("解析结果") {
                        Label(error, systemImage: "exclamationmark.circle")
                            .font(.footnote)
                            .foregroundStyle(.orange)
                            .textSelection(.enabled)
                    }.listRowBackground(AppPalette.surface)
                }
                if let media = resolver.result {
                    Section {
                        Button { choose(media) } label: {
                          VStack(alignment: .leading, spacing: 8) {
                            Text(media.title).font(.headline).textSelection(.enabled)
                            if let author = media.author, !author.isEmpty {
                                Text(author).font(.subheadline).foregroundStyle(AppPalette.muted)
                            }
                            HStack {
                                Label(media.extractor, systemImage: "iphone")
                                if let duration = media.duration, duration > 0 {
                                    Text("\(Int(duration) / 60):\(String(format: "%02d", Int(duration) % 60))")
                                        .monospacedDigit()
                                }
                            }
                            .font(.caption)
                            .foregroundStyle(AppPalette.muted)
                            Label("点此选择下载或小窗播放", systemImage: "hand.tap")
                                .font(.caption).foregroundStyle(AppPalette.accent)
                          }
                          .frame(maxWidth: .infinity, alignment: .leading)
                          .contentShape(Rectangle())
                        }
                        .buttonStyle(.plain)
                        .padding(.vertical, 4)
                    } header: { Text("已解析") }
                    .listRowBackground(AppPalette.surface)

                    Section {
                        ForEach(media.formats) { format in
                            Button { choose(media, format: format) } label: {
                                HStack(spacing: 12) {
                                    Image(systemName: symbol(format.kind))
                                        .font(.title3)
                                        .foregroundStyle(AppPalette.accent)
                                        .frame(width: 30)
                                    VStack(alignment: .leading, spacing: 5) {
                                        Text(format.quality).font(.subheadline.weight(.medium)).foregroundStyle(.primary)
                                        Text(format.detail).font(.caption).foregroundStyle(AppPalette.muted)
                                    }
                                    Spacer(minLength: 4)
                                    Image(systemName: "ellipsis.circle").foregroundStyle(AppPalette.accent)
                                }
                                .padding(.vertical, 4)
                            }
                            .buttonStyle(.borderless)
                        }
                        if media.formats.count > 1 && media.formats.allSatisfy({ $0.kind == .image }) {
                            Button {
                                let errors = media.formats.compactMap { store.enqueue(media: media, format: $0) }
                                notice = errors.isEmpty ? "已将全部图片加入下载队列。" : errors.joined(separator: "\n")
                                showNotice = true
                            } label: { Label("下载全部图片", systemImage: "square.stack.3d.down.right") }
                        }
                    } header: { Text("选择媒体 / 清晰度 · \(media.formats.count)") }
                    footer: { Text("点媒体记录可选择下载或小窗播放。分轨下载后在本机合并；HLS 使用系统离线包保存。") }
                    .listRowBackground(AppPalette.surface)
                } else if !resolver.isResolving && resolver.errorMessage == nil {
                    Section {
                        VStack(alignment: .leading, spacing: 12) {
                            Label("网页链接 → 媒体解析 → 选择格式 → 下载", systemImage: "play.rectangle")
                                .font(.subheadline.weight(.medium))
                            Text("原生解析器优先处理抖音、B站、TikTok 和 X；其他链接交给内置 yt-dlp 解析。解析过程无需自建服务器。")
                                .font(.footnote).foregroundStyle(AppPalette.muted)
                        }.padding(.vertical, 5)
                    }.listRowBackground(AppPalette.surface)
                }
                if !history.records.isEmpty {
                    Section {
                        ForEach(history.records) { record in
                            Button {
                                input = record.originalURL
                                if let media = history.recentMedia(for: record) {
                                    choose(media)
                                } else {
                                    parse(record.originalURL, presentActions: true)
                                }
                            } label: {
                                HStack(spacing: 12) {
                                    Image(systemName: "clock.arrow.circlepath")
                                        .foregroundStyle(AppPalette.accent)
                                    VStack(alignment: .leading, spacing: 5) {
                                        Text(record.title).font(.subheadline.weight(.medium))
                                            .foregroundStyle(.primary).lineLimit(2)
                                        Text([record.author, record.extractor].compactMap { $0 }.joined(separator: " · "))
                                            .font(.caption).foregroundStyle(AppPalette.muted)
                                    }
                                    Spacer(minLength: 4)
                                    Image(systemName: "ellipsis.circle").foregroundStyle(AppPalette.accent)
                                }.padding(.vertical, 4)
                            }.buttonStyle(.borderless)
                        }
                        .onDelete(perform: history.remove)
                    } header: { Text("解析记录") }
                    footer: { Text("点记录选择操作。过期媒体链接会先自动重新解析；左滑可移除记录。") }
                    .listRowBackground(AppPalette.surface)
                }
            }
            .listStyle(.insetGrouped)
            .scrollContentBackground(.hidden)
            .background(AppPalette.canvas)
            .navigationTitle("LibreGet · 解析")
            .toolbar {
                if isSheet {
                    ToolbarItem(placement: .navigationBarLeading) { Button("关闭") { dismiss() } }
                }
            }
            .alert("下载队列", isPresented: $showNotice) { Button("好", role: .cancel) {} }
                message: { Text(notice) }
            .confirmationDialog("选择操作", isPresented: $showActions,
                                titleVisibility: .visible, presenting: selection) { request in
                Button("下载 · \(request.format.quality)") { enqueue(request.media, request.format) }
                if MediaPreviewRequest.canPreview(request.format) {
                    Button("小窗播放") {
                        preview = MediaPreviewRequest(media: request.media, format: request.format, startFloating: true)
                    }
                }
                Button("取消", role: .cancel) {}
            } message: { request in
                Text(request.media.title + "\n" + request.format.detail)
            }
            .sheet(item: $preview) { request in MediaPreviewSheet(request: request) }
            .onDisappear { parseTask?.cancel(); resolver.cancel() }
        }
    }

    private func parse(_ text: String, presentActions: Bool = false) {
        inputFocused = false
        parseTask?.cancel()
        parseTask = Task {
            await resolver.resolve(text)
            guard !Task.isCancelled, presentActions, let media = resolver.result else { return }
            choose(media)
        }
    }

    private func choose(_ media: ResolvedMedia, format: MediaFormat? = nil) {
        guard let selected = format ?? media.formats.first(where: { $0.kind == .video }) ?? media.formats.first else { return }
        selection = MediaPreviewRequest(media: media, format: selected)
        showActions = true
    }

    private func enqueue(_ media: ResolvedMedia, _ format: MediaFormat) {
        notice = store.enqueue(media: media, format: format) ?? "已加入下载队列，可在“下载”中查看进度。"
        showNotice = true
    }

    private func symbol(_ kind: MediaKind) -> String {
        switch kind {
        case .video: return "film"
        case .audio: return "waveform"
        case .image: return "photo"
        case .file: return "doc"
        }
    }
}
