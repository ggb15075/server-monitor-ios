import Foundation

// Shared by the app and the command-line network smoke test, so a whole
// platform share message follows the same URL extraction path in both.
enum ShareLinkParser {
    static func extractURL(_ text: String) throws -> URL {
        let trimmed = text.trimmingCharacters(in: .whitespacesAndNewlines)
        let detector = try NSDataDetector(types: NSTextCheckingResult.CheckingType.link.rawValue)
        let matches = detector.matches(in: trimmed, range: NSRange(trimmed.startIndex..., in: trimmed))
        let direct = URL(string: trimmed)
        let url = matches.compactMap(\.url).first(where: { ["http", "https"].contains($0.scheme?.lowercased() ?? "") }) ?? direct
        guard let url, ["http", "https"].contains(url.scheme?.lowercased() ?? ""),
              let host = url.host, !host.isEmpty, url.user == nil, url.password == nil else {
            throw MediaResolveError.invalidURL
        }
        return url
    }
}
