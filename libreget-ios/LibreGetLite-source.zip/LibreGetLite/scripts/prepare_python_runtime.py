#!/usr/bin/env python3
"""Fetch and verify the fixed iOS Python runtime and pure-Python extractors.

Run once on the macOS build runner before xcodebuild. Network content is never
executed before SHA-256 verification. The optional cache avoids re-downloading.
"""
import argparse
import hashlib
import json
import shutil
import tarfile
import urllib.request
import zipfile
from pathlib import Path

PROJECT = Path(__file__).resolve().parents[1]
RUNTIME = {
    "filename": "Python-3.13-iOS-support.b18.tar.gz",
    "url": "https://github.com/beeware/Python-Apple-support/releases/download/3.13-b18/Python-3.13-iOS-support.b18.tar.gz",
    "sha256": "d06acf2a9c7964a8689566353a0e707402eff822037de5e29ba0e16040f7047d",
}
WHEELS = [
    {"filename": "yt_dlp-2026.10.26-py3-none-any.whl",
     "url": "https://files.pythonhosted.org/packages/7f/3d/16ea7d5638cf585991f2c5705e8083688dde633d32d0871f2404e0f4d827/yt_dlp-2026.10.26-py3-none-any.whl",
     "sha256": "a05c5b5d8562f7e8a62f5334348b406af4930d56d3a65f8021d14af0e22339ae"},
    {"filename": "certifi-2026.11.20-py3-none-any.whl",
     "url": "https://files.pythonhosted.org/packages/6d/39/5eec3296860b94ac20bb8ed807725b88f6adfab3f343df592afd975f5f86/certifi-2026.11.20-py3-none-any.whl",
     "sha256": "7422df25243767b9877031a2248cb14d09ddac9beee846f4cef3d5c9191d488f"},
    {"filename": "yt_dlp_ejs-0.8.0-py3-none-any.whl",
     "url": "https://files.pythonhosted.org/packages/e3/bd/520769863744b669440a924271a6159ddd82ad5ae26b4ac4d4b69e9f8d44/yt_dlp_ejs-0.8.0-py3-none-any.whl",
     "sha256": "79300e5fca7f937a1eeede11f0456862c1b41107ce1d726871e0207424f4bdb4"},
]


def verified_download(item, cache):
    path = cache / item["filename"]
    if not path.is_file() or hashlib.sha256(path.read_bytes()).hexdigest() != item["sha256"]:
        temporary = path.with_suffix(path.suffix + ".partial")
        request = urllib.request.Request(item["url"], headers={"User-Agent": "LibreGet-iOS-build/0.2"})
        with urllib.request.urlopen(request, timeout=90) as response, temporary.open("wb") as output:
            shutil.copyfileobj(response, output)
        if hashlib.sha256(temporary.read_bytes()).hexdigest() != item["sha256"]:
            temporary.unlink()
            raise RuntimeError("Download checksum mismatch: " + item["filename"])
        temporary.replace(path)
    print("Verified", item["filename"], item["sha256"], flush=True)
    return path


def prepare(cache, packages_only=False):
    cache.mkdir(parents=True, exist_ok=True)
    if not packages_only:
        archive = verified_download(RUNTIME, cache)
        with tarfile.open(archive) as source:
            # data filter permits the runtime's relative internal symlinks and
            # rejects links or paths escaping the extraction directory.
            source.extractall(PROJECT, filter="data")
        version = (PROJECT / "VERSIONS").read_text()
        if "Min iOS version: 13.0" not in version or "Build: b18" not in version:
            raise RuntimeError("Unexpected Python runtime build")
    packages = PROJECT / "PythonPackages"
    packages.mkdir(exist_ok=True)
    for wheel in WHEELS:
        with zipfile.ZipFile(verified_download(wheel, cache)) as source:
            for name in source.namelist():
                path = Path(name)
                if path.is_absolute() or ".." in path.parts or "\\" in name:
                    raise RuntimeError("Unsafe wheel path")
                if name.endswith("/"): continue
                destination = packages / path
                destination.parent.mkdir(parents=True, exist_ok=True)
                destination.write_bytes(source.read(name))
    manifest = {"python": {"version": "3.13.18", "build": "b18", **RUNTIME}, "packages": WHEELS}
    (packages / "LibreGet-engine-manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
    print("Python packages ready:", packages)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--cache", type=Path, default=PROJECT / ".runtime-cache")
    parser.add_argument("--packages-only", action="store_true", help="Host fixture testing without extracting the iOS binary")
    args = parser.parse_args()
    prepare(args.cache.resolve(), args.packages_only)
