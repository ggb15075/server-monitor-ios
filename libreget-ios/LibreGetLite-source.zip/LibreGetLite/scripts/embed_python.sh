#!/bin/bash
# Run after Copy Bundle Resources. Preparation/downloads happen before Xcode.
set -euo pipefail

framework_root="$PROJECT_DIR/Python.xcframework"
if [[ "$EFFECTIVE_PLATFORM_NAME" == "-iphonesimulator" ]]; then
  runtime_slice="$framework_root/ios-arm64_x86_64-simulator"
else
  runtime_slice="$framework_root/ios-arm64"
fi
test -f "$runtime_slice/Python.framework/Python"
test -f "$PROJECT_DIR/PythonPackages/yt_dlp/__init__.py"
mkdir -p "$CODESIGNING_FOLDER_PATH/Frameworks"
rsync -a --delete "$runtime_slice/Python.framework/" "$CODESIGNING_FOLDER_PATH/Frameworks/Python.framework/"
rsync -a --delete "$PROJECT_DIR/PythonPackages/" "$CODESIGNING_FOLDER_PATH/PythonPackages/"

# Use the verified runtime's own PEP 730 conversion code, including .fwork and
# .origin markers. Unsigned TrollStore builds use ad-hoc signatures for modules.
export EXPANDED_CODE_SIGN_IDENTITY="${EXPANDED_CODE_SIGN_IDENTITY:--}"
if [[ -z "$EXPANDED_CODE_SIGN_IDENTITY" ]]; then export EXPANDED_CODE_SIGN_IDENTITY="-"; fi
export EXPANDED_CODE_SIGN_IDENTITY_NAME="${EXPANDED_CODE_SIGN_IDENTITY_NAME:-Ad Hoc}"
export PLATFORM_FAMILY_NAME="iOS"
source "$framework_root/build/utils.sh"
install_stdlib Python.xcframework
# Use the fixed Python version here rather than the upstream convenience
# wrapper's grep expression, which differs across BSD/GNU grep versions.
process_dylibs Python.xcframework python/lib/python3.13/lib-dynload

# Keep importlib metadata and all dependency licenses available in the IPA.
test -f "$CODESIGNING_FOLDER_PATH/python/lib/python3.13/LICENSE.txt"
test -f "$CODESIGNING_FOLDER_PATH/python/lib/python3.13/lib-dynload/_ssl.cpython-313-iphoneos.fwork" || \
  test "$EFFECTIVE_PLATFORM_NAME" = "-iphonesimulator"
/usr/bin/codesign --force --sign "$EXPANDED_CODE_SIGN_IDENTITY" --timestamp=none \
  "$CODESIGNING_FOLDER_PATH/Frameworks/Python.framework"
