"""Extract video from Xiaohongshu's public mobile share pages."""
import re
from urllib.parse import parse_qs, urlsplit, urlunsplit

from yt_dlp.extractor.common import InfoExtractor
from yt_dlp.utils import ExtractorError, float_or_none, int_or_none, js_to_json, url_or_none
from yt_dlp.utils.traversal import traverse_obj


MOBILE_UA = (
    "Mozilla/5.0 (iPhone; CPU iPhone OS 16_6_1 like Mac OS X) "
    "AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.6 Mobile/15E148 Safari/604.1"
)
NOTE_HOST = "www.xiaohongshu.com"
NOTE_PATH = r"/(?:explore|discovery/item)/([0-9a-f]{24})/?"
UNAVAILABLE = "小红书未返回可用的笔记。请在小红书 App 中确认作品仍可查看，再重新复制分享链接。"
LOGIN_REQUIRED = "小红书仍要求登录才能查看这篇笔记。请在小红书 App 中打开笔记并重新复制分享链接。"


def _note_target(url):
    try:
        parts = urlsplit(url)
    except ValueError:
        return None
    match = re.fullmatch(NOTE_PATH, parts.path)
    if not match:
        return None
    if parts.netloc:
        if parts.scheme not in ("http", "https") or parts.netloc.lower() not in (NOTE_HOST, "xiaohongshu.com"):
            return None
    elif parts.scheme:
        return None
    return urlunsplit(("https", NOTE_HOST, parts.path, parts.query, "")), match[1]


def _is_login(url):
    parts = urlsplit(url)
    return parts.netloc.lower() in (NOTE_HOST, "xiaohongshu.com") and parts.path.rstrip("/") == "/login"


class LibreGetXiaohongshuIE(InfoExtractor):
    IE_NAME = "Xiaohongshu"
    _VALID_URL = (
        r"https?://(?:www\.)?(?:xhslink\.(?:cn|com)/[^/?#]+"
        r"|xiaohongshu\.com/(?:(?:explore|discovery/item)/[0-9a-f]{24}/?|login/?)(?=[?#]|$))"
    )

    def _real_extract(self, url):
        target = _note_target(url)
        if _is_login(url):
            target = self._login_target(url)
        page, response = self._fetch(target[0] if target else url, target[1] if target else "share")

        if _is_login(response.url):
            if target:
                raise ExtractorError(LOGIN_REQUIRED, expected=True)
            target = self._login_target(response.url)
            page, response = self._fetch(*target)
            if _is_login(response.url):
                raise ExtractorError(LOGIN_REQUIRED, expected=True)

        final = _note_target(response.url)
        if response.status != 200 or not final or (target and final[1] != target[1]):
            raise ExtractorError(UNAVAILABLE, expected=True)
        note_id = final[1]
        state = self._search_json(
            r"window\.__INITIAL_STATE__\s*=", page, "initial state", note_id,
            transform_source=js_to_json, default={},
        )
        note = traverse_obj(state, ("noteData", "data", "noteData", {dict}))
        if not note:
            note = traverse_obj(state, ("note", "noteDetailMap", note_id, "note", {dict}))
        if not note or note.get("noteId", note_id) != note_id:
            raise ExtractorError(UNAVAILABLE, expected=True)

        streams = traverse_obj(note, ("video", "media", "stream", ..., ..., {dict}))
        formats = []
        for stream in streams:
            media_url = traverse_obj(stream, (("masterUrl", ("backupUrls", ...)), {url_or_none}), get_all=False)
            if not media_url:
                continue
            formats.append({
                "url": media_url,
                "format_id": stream.get("videoCodec"),
                "width": int_or_none(stream.get("width")),
                "height": int_or_none(stream.get("height")),
                "filesize": int_or_none(stream.get("size")),
                "fps": int_or_none(stream.get("fps")),
                "vcodec": stream.get("videoCodec"),
                "acodec": stream.get("audioCodec"),
                "duration": float_or_none(stream.get("duration"), scale=1000),
                "http_headers": {"Referer": f"https://{NOTE_HOST}/"},
            })
        if not formats:
            raise ExtractorError("这篇小红书笔记没有可解析的视频。", expected=True)
        durations = [fmt["duration"] for fmt in formats if fmt["duration"] is not None]

        return {
            "id": note_id,
            "title": note.get("title") or self._og_search_title(page, default=None) or note_id,
            "uploader": traverse_obj(note, ("user", "nickname", {str})),
            "thumbnail": traverse_obj(note, ("imageList", 0, ("urlDefault", "urlPre"), {url_or_none}), get_all=False),
            "duration": max(durations, default=None),
            "formats": formats,
        }

    def _fetch(self, url, note_id):
        return self._download_webpage_handle(url, note_id, expected_status=(401, 403, 404))

    @staticmethod
    def _login_target(url):
        redirect = parse_qs(urlsplit(url).query).get("redirectPath", [""])[0]
        target = _note_target(redirect)
        if not target:
            raise ExtractorError(LOGIN_REQUIRED, expected=True)
        return target
