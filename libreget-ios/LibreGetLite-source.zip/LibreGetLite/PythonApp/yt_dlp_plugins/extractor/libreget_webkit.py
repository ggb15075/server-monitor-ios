"""yt-dlp EJS provider using the app's bounded native WebKit bridge.

The EJS provider interface is private and is pinned with yt-dlp in the build
manifest. No remote components, subprocesses or ctypes callbacks are used.
"""
from yt_dlp.extractor.youtube.jsc._builtin.ejs import EJSBaseJCP
from yt_dlp.extractor.youtube.jsc.provider import (
    JsChallengeProviderError, register_preference, register_provider,
)

try:
    from _libreget_native import evaluate_javascript
except ImportError:
    evaluate_javascript = None  # Host fixture tests have no iOS bridge.


@register_provider
class LibreGetWebKitJCP(EJSBaseJCP):
    JS_RUNTIME_NAME = "libreget-webkit"
    PROVIDER_VERSION = "1"
    BUG_REPORT_LOCATION = "https://github.com/ggb15075/server-monitor-ios/issues"

    def is_available(self):
        return evaluate_javascript is not None and self._available

    def _run_js_runtime(self, stdin, /):
        try:
            return evaluate_javascript(stdin)
        except Exception as error:
            raise JsChallengeProviderError(str(error)) from error


@register_preference(LibreGetWebKitJCP)
def libreget_webkit_preference(provider, requests):
    return 600
