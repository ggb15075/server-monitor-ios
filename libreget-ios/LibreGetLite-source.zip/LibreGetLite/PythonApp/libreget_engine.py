"""Resolve webpage URLs locally; downloads remain in the native iOS queue.

Keep this output contract in sync with MediaModels.swift. DASH segment lists,
DRM, live streams and formats that need FFmpeg are intentionally excluded.
"""
import json
import math
import re
from urllib.parse import urlparse


class ResolveError(Exception):
    pass


def _url(value):
    if not isinstance(value, str) or any(ord(c) < 32 for c in value):
        return None
    try:
        parsed = urlparse(value)
        if parsed.scheme not in ("http", "https") or not parsed.hostname or parsed.username or parsed.password:
            return None
        return value
    except ValueError:
        return None


def _number(value):
    return value if isinstance(value, (int, float)) and not isinstance(value, bool) and math.isfinite(value) else None


def _integer(value):
    number = _number(value)
    return int(number) if number is not None and number > 0 else None


def _headers(info, fmt):
    # Keep per-format referer/user-agent and session cookies required by CDNs.
    # Never propagate transport-specific headers such as Host or Range.
    output = {}
    for source in (info.get("http_headers") or {}, fmt.get("http_headers") or {}):
        for key, value in source.items():
            if not isinstance(key, str) or not isinstance(value, str):
                continue
            if key.lower() in {"host", "content-length", "range", "connection", "transfer-encoding", "accept-encoding"}:
                continue
            if re.fullmatch(r"[!#$%&'*+.^_`|~0-9A-Za-z-]+", key) and "\r" not in value and "\n" not in value:
                output[key] = value
    return output


def _protocol(fmt):
    protocol = str(fmt.get("protocol") or urlparse(fmt.get("url") or "").scheme).lower()
    if protocol in {"m3u8", "m3u8_native"}:
        return "hls"
    # A DASH manifest and its fragments cannot be downloaded as a single file.
    # Native Bilibili-style direct mp4/m4a tracks use protocol=https and work.
    if protocol in {"http", "https"} and not fmt.get("fragments"):
        return "direct"
    return None


def _audio_compatible(fmt):
    codec = str(fmt.get("acodec") or "").lower()
    return fmt.get("ext") in {"m4a", "mp4", "aac"} and codec.startswith(("mp4a", "aac", "alac"))


def _video_compatible(fmt):
    codec = str(fmt.get("vcodec") or "").lower()
    return fmt.get("ext") in {"mp4", "m4v", "mov"} and codec.startswith(("avc", "h264", "hvc", "hev", "hevc"))


def _format(info, fmt, index, audio=None):
    url = _url(fmt.get("url"))
    if not url or fmt.get("has_drm") or not _protocol(fmt):
        return None
    protocol = _protocol(fmt)
    ext = str(fmt.get("ext") or "mp4").lower()
    if not re.fullmatch(r"[a-z0-9]{1,8}", ext):
        ext = "mp4"
    vcodec, acodec = fmt.get("vcodec"), fmt.get("acodec")
    image = ext in {"jpg", "jpeg", "png", "webp", "gif", "avif", "heic"}
    audio_only = vcodec == "none" or (not vcodec and ext in {"mp3", "m4a", "aac", "flac", "wav", "ogg", "opus"})
    kind = "image" if image else "audio" if audio_only else "video"
    # A video-only HLS media playlist loses its separate audio rendition if
    # downloaded alone. Only offer HLS formats carrying audio themselves.
    if kind == "video" and acodec == "none":
        if protocol != "direct" or audio is None or not _video_compatible(fmt):
            return None
    width, height = _integer(fmt.get("width")), _integer(fmt.get("height"))
    if image:
        quality = f"图片 {index + 1}"
    elif audio_only:
        quality = "音频" + (f" · {int(fmt['abr'])} kbps" if _number(fmt.get("abr")) else "")
    else:
        quality = f"{height}p" if height else str(fmt.get("format_note") or "原始画质")
        if _number(fmt.get("fps")) and fmt["fps"] > 30:
            quality += f" · {int(fmt['fps'])}fps"
    output = {
        "id": f"ytdlp-{index}-{fmt.get('format_id') or 'direct'}", "url": url,
        "fileExtension": "mp4" if audio is not None else ext,
        "quality": quality, "kind": kind, "headers": _headers(info, fmt),
        "protocolHint": "m3u8" if protocol == "hls" else "https",
    }
    if width: output["width"] = width
    if height: output["height"] = height
    size = _integer(fmt.get("filesize")) or _integer(fmt.get("filesize_approx"))
    if audio:
        output["audioURL"] = audio["url"]
        output["audioHeaders"] = _headers(info, audio)
        audio_size = _integer(audio.get("filesize")) or _integer(audio.get("filesize_approx"))
        size = size + audio_size if size and audio_size else None
    if size: output["approximateBytes"] = size
    return output


def normalize_info(info, original_url):
    if not isinstance(info, dict):
        raise ResolveError("网站没有返回可用的媒体信息。")
    if info.get("_type") in {"playlist", "multi_video"}:
        entries = [item for item in (info.get("entries") or []) if item]
        if len(entries) != 1:
            raise ResolveError("当前请使用单条视频的分享链接；播放列表和频道批量下载尚未提供。")
        return normalize_info(entries[0], original_url)
    if info.get("is_live") or info.get("live_status") == "is_live":
        raise ResolveError("正在直播的内容暂不支持离线下载，请使用已发布的视频。")
    raw = list(info.get("formats") or [])
    if not raw and info.get("url"):
        raw = [info]
    usable = [fmt for fmt in raw if isinstance(fmt, dict) and _url(fmt.get("url")) and not fmt.get("has_drm") and _protocol(fmt)]
    audios = [fmt for fmt in usable if fmt.get("vcodec") == "none" and _protocol(fmt) == "direct" and _audio_compatible(fmt)]
    audio = max(audios, key=lambda f: (_number(f.get("abr")) or 0, _integer(f.get("filesize")) or 0), default=None)
    formats, seen = [], set()
    for index, fmt in enumerate(usable):
        paired = audio if fmt.get("vcodec") != "none" and fmt.get("acodec") == "none" else None
        value = _format(info, fmt, index, paired)
        if value is None: continue
        identity = (value["url"], value.get("audioURL"))
        if identity in seen: continue
        seen.add(identity)
        formats.append(value)
    formats.sort(key=lambda f: (f["kind"] != "video", -(f.get("height") or 0), -(f.get("approximateBytes") or 0)))
    if not formats:
        raise ResolveError("已解析网页，但没有适合 iOS 下载的媒体格式。内容可能受保护，或只提供需要额外转码的分片流。")
    title = str(info.get("title") or info.get("id") or "媒体文件")[:240]
    result = {"originalURL": original_url, "title": title,
              "extractor": "yt-dlp · " + str(info.get("extractor_key") or info.get("extractor") or "网页解析"),
              "formats": formats}
    author = info.get("uploader") or info.get("creator") or info.get("channel")
    if author: result["author"] = str(author)[:240]
    if _url(info.get("thumbnail")): result["thumbnail"] = info["thumbnail"]
    if _number(info.get("duration")) is not None: result["duration"] = info["duration"]
    return result


class _Logger:
    def __init__(self): self.warnings = []
    def debug(self, message): pass
    def warning(self, message): self.warnings.append(str(message))
    def error(self, message): pass


def resolve_json(url):
    if not _url(url):
        raise ResolveError("请使用有效的 HTTP 或 HTTPS 网页分享链接。")
    import certifi
    import yt_dlp
    logger = _Logger()
    options = {
        "quiet": True, "no_warnings": True, "logger": logger,
        "skip_download": True, "noplaylist": True,
        "socket_timeout": 20, "retries": 0, "extractor_retries": 0,
        "cachedir": False, "nocheckcertificate": False, "ca_certs": certifi.where(),
        "format": "best/bestvideo+bestaudio", "ignore_no_formats_error": True,
        "extract_flat": False, "js_runtimes": {}, "remote_components": [],
    }
    with yt_dlp.YoutubeDL(options) as ydl:
        info = ydl.extract_info(url, download=False)
        # export cookies only for the exact CDN format URL. The cookie jar
        # enforces domain/path/security rules; no browser credentials are read.
        for fmt in (info.get("formats") or [info]) if isinstance(info, dict) else []:
            if not isinstance(fmt, dict) or not _url(fmt.get("url")): continue
            cookie = ydl.cookiejar.get_cookie_header(fmt["url"])
            if cookie:
                fmt.setdefault("http_headers", {})["Cookie"] = cookie
        result = normalize_info(info, url)
    return json.dumps(result, ensure_ascii=False, allow_nan=False)
