# LibreGet local extraction engine

This app embeds CPython 3.13.18 (BeeWare iOS support build b18), yt-dlp
2026.10.26, yt-dlp-ejs 0.8.0, and certifi 2026.11.20. Downloads are fixed by
version and SHA-256 in `scripts/prepare_python_runtime.py`; the complete build
manifest is included at `PythonPackages/LibreGet-engine-manifest.json`.

The native bridge and format adapter are part of LibreGet and are distributed
under the repository's GPL-3.0 license. The WebKit JavaScript provider invokes
the app's own Objective-C bridge; it does not include PythonKit, FFmpeg,
yt-dlp-apple-webkit-jsi, or an external JavaScript executable.

Third-party code and licenses:

- CPython: Python Software Foundation License; full license is in
  `python/lib/python3.13/LICENSE.txt`.
  Source: https://github.com/python/cpython/tree/v3.13.18
- BeeWare Python Apple Support: BSD-3-Clause build tooling.
  Source: https://github.com/beeware/Python-Apple-support/tree/3.13-b18
- yt-dlp: Unlicense, with third-party notices in its bundled LICENSE.
  Source: https://github.com/yt-dlp/yt-dlp/tree/2026.10.26
  Full license: `PythonPackages/yt_dlp-2026.10.26.dist-info/licenses/LICENSE`.
- yt-dlp-ejs: Unlicense, with source component notices in its bundled LICENSE.
  Source: https://github.com/yt-dlp/ejs/tree/0.8.0
  Full license: `PythonPackages/yt_dlp_ejs-0.8.0.dist-info/licenses/LICENSE`.
- certifi: Mozilla Public License 2.0.
  Source: https://github.com/certifi/python-certifi
  Full license: `PythonPackages/certifi-2026.11.20.dist-info/licenses/LICENSE`.

The BeeWare runtime also contains BZip2 1.0.8-2, libFFI 3.4.7-2,
mpdecimal 4.0.0-2, OpenSSL 3.5.9-1, and XZ 5.6.4-2 as listed in the runtime's
`VERSIONS` file. Their source, build recipes and license references are
available from the fixed BeeWare source tag above.

No login credentials are collected from other apps. The parser may receive
anonymous session cookies from the requested website and passes applicable
cookies and headers to the native downloader for the exact resolved CDN URL.
