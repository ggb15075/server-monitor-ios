import SwiftUI
import UIKit

private enum AppPalette {
    static let canvas = Color(red: 0.08, green: 0.08, blue: 0.09)
    static let surface = Color(red: 0.14, green: 0.14, blue: 0.15)
    static let accent = Color(red: 1.0, green: 0.62, blue: 0.04)
    static let muted = Color(red: 0.62, green: 0.62, blue: 0.64)
}

struct ContentView: View {
    var body: some View {
        TabView {
            DownloadsView()
                .tabItem { Label("下载", systemImage: "arrow.down.circle") }
            SavedFilesView()
                .tabItem { Label("文件", systemImage: "folder") }
        }
        .tint(AppPalette.accent)
        .background(AppPalette.canvas)
    }
}

private struct DownloadsView: View {
    @ObservedObject private var store = DownloadStore.shared
    @State private var showingAdd = false

    var body: some View {
        NavigationStack {
            Group {
                if store.items.isEmpty {
                    emptyState
                } else {
                    List {
                        Section {
                            Label {
                                Text("iOS 版支持 HTTPS 直链下载。网站解析、课程和桌面工具箱仍由桌面版提供。")
                                    .font(.footnote)
                                    .foregroundStyle(AppPalette.muted)
                                    .fixedSize(horizontal: false, vertical: true)
                            } icon: {
                                Image(systemName: "info.circle")
                                    .foregroundStyle(AppPalette.accent)
                            }
                            .listRowBackground(AppPalette.surface)
                        }

                        if !store.activeItems.isEmpty {
                            Section("进行中 · \(store.activeItems.count)") {
                                ForEach(store.activeItems) { item in
                                    DownloadRow(item: item, store: store)
                                }
                            }
                        }

                        let finished = store.items.filter { $0.status == .completed || $0.status == .failed }
                        if !finished.isEmpty {
                            Section("最近任务 · \(finished.count)") {
                                ForEach(finished.sorted { $0.createdAt > $1.createdAt }) { item in
                                    DownloadRow(item: item, store: store)
                                }
                                .onDelete { offsets in
                                    let list = finished.sorted { $0.createdAt > $1.createdAt }
                                    offsets.map { list[$0].id }.forEach(store.remove)
                                }
                            }
                        }
                    }
                    .listStyle(.insetGrouped)
                    .scrollContentBackground(.hidden)
                }
            }
            .background(AppPalette.canvas)
            .navigationTitle("LibreGet")
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button { showingAdd = true } label: {
                        Image(systemName: "plus")
                            .font(.system(size: 17, weight: .semibold))
                    }
                    .accessibilityLabel("添加下载链接")
                }
            }
            .sheet(isPresented: $showingAdd) {
                AddDownloadSheet(store: store)
                    .presentationDetents([.medium])
                    .presentationDragIndicator(.visible)
            }
        }
    }

    private var emptyState: some View {
        VStack(spacing: 16) {
            Image(systemName: "arrow.down.to.line")
                .font(.system(size: 36, weight: .regular))
                .foregroundStyle(AppPalette.accent)
                .frame(width: 76, height: 76)
                .background(AppPalette.surface, in: RoundedRectangle(cornerRadius: 22))

            VStack(spacing: 6) {
                Text("下载队列为空")
                    .font(.title3.weight(.semibold))
                Text("添加一个 HTTPS 文件链接开始下载。")
                    .font(.subheadline)
                    .foregroundStyle(AppPalette.muted)
            }

            Button { showingAdd = true } label: {
                Label("添加链接", systemImage: "plus")
                    .font(.subheadline.weight(.semibold))
                    .padding(.horizontal, 18)
                    .padding(.vertical, 11)
                    .background(AppPalette.accent, in: RoundedRectangle(cornerRadius: 8))
                    .foregroundStyle(.black)
            }
            .buttonStyle(.plain)
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .padding(24)
    }
}

private struct DownloadRow: View {
    let item: DownloadItem
    @ObservedObject var store: DownloadStore

    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack(alignment: .top, spacing: 12) {
                Image(systemName: symbol)
                    .font(.system(size: 17, weight: .medium))
                    .foregroundStyle(iconColor)
                    .frame(width: 28, height: 28)
                    .background(iconColor.opacity(0.13), in: RoundedRectangle(cornerRadius: 7))

                VStack(alignment: .leading, spacing: 4) {
                    Text(item.title)
                        .font(.subheadline.weight(.medium))
                        .lineLimit(2)
                        .textSelection(.enabled)
                    Text(statusText)
                        .font(.caption)
                        .foregroundStyle(statusColor)
                }

                Spacer(minLength: 8)

                Menu {
                    switch item.status {
                    case .downloading, .queued:
                        Button { store.cancel(item.id) } label: {
                            Label("取消下载", systemImage: "xmark.circle")
                        }
                    case .failed:
                        Button { store.retry(item.id) } label: {
                            Label("重试", systemImage: "arrow.clockwise")
                        }
                    case .completed:
                        if let url = store.fileURL(for: item) {
                            ShareLink(item: url) {
                                Label("分享或存储文件", systemImage: "square.and.arrow.up")
                            }
                        }
                    }
                    Button(role: .destructive) { store.remove(item.id) } label: {
                        Label("移除", systemImage: "trash")
                    }
                } label: {
                    Image(systemName: "ellipsis")
                        .font(.system(size: 16, weight: .semibold))
                        .foregroundStyle(AppPalette.muted)
                        .frame(width: 32, height: 32)
                        .contentShape(Rectangle())
                }
                .accessibilityLabel("更多下载操作")
            }

            if item.status == .downloading {
                ProgressView(value: item.progress)
                    .tint(AppPalette.accent)
                HStack {
                    Text(item.expectedBytes > 0 ? "\(Int(item.progress * 100))%" : "正在接收")
                    Spacer()
                    Text(store.fileSizeDescription(for: item))
                }
                .font(.caption2.monospacedDigit())
                .foregroundStyle(AppPalette.muted)
            } else if let error = item.errorMessage, item.status == .failed {
                Text(error)
                    .font(.caption)
                    .foregroundStyle(.red.opacity(0.9))
                    .lineLimit(2)
            } else if item.status == .completed {
                Text(store.fileSizeDescription(for: item))
                    .font(.caption)
                    .foregroundStyle(AppPalette.muted)
            }
        }
        .padding(.vertical, 5)
        .listRowBackground(AppPalette.surface)
    }

    private var symbol: String {
        switch item.status {
        case .queued: "clock"
        case .downloading: "arrow.down.circle.fill"
        case .completed: "checkmark.circle.fill"
        case .failed: "exclamationmark.circle.fill"
        }
    }

    private var iconColor: Color {
        switch item.status {
        case .queued: AppPalette.muted
        case .downloading: AppPalette.accent
        case .completed: .green
        case .failed: .red
        }
    }

    private var statusColor: Color {
        item.status == .failed ? .red : AppPalette.muted
    }

    private var statusText: String {
        switch item.status {
        case .queued: "等待下载"
        case .downloading: "正在下载"
        case .completed: "已完成"
        case .failed: "下载失败"
        }
    }
}

private struct SavedFilesView: View {
    @ObservedObject private var store = DownloadStore.shared

    var body: some View {
        NavigationStack {
            Group {
                if store.completedItems.isEmpty {
                    VStack(spacing: 12) {
                        Image(systemName: "folder")
                            .font(.system(size: 34))
                            .foregroundStyle(AppPalette.muted)
                        Text("还没有已完成的文件")
                            .font(.headline)
                        Text("完成的下载会保存在本机，并可通过分享菜单存入“文件”。")
                            .font(.subheadline)
                            .foregroundStyle(AppPalette.muted)
                            .multilineTextAlignment(.center)
                    }
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
                    .padding(28)
                } else {
                    List {
                        Section {
                            ForEach(store.completedItems) { item in
                                HStack(spacing: 12) {
                                    Image(systemName: "doc.fill")
                                        .foregroundStyle(AppPalette.accent)
                                        .frame(width: 28)
                                    VStack(alignment: .leading, spacing: 4) {
                                        Text(item.title).font(.subheadline.weight(.medium)).lineLimit(2)
                                        Text(store.fileSizeDescription(for: item))
                                            .font(.caption)
                                            .foregroundStyle(AppPalette.muted)
                                    }
                                    Spacer(minLength: 8)
                                    if let url = store.fileURL(for: item) {
                                        ShareLink(item: url) {
                                            Image(systemName: "square.and.arrow.up")
                                                .frame(width: 36, height: 36)
                                        }
                                        .accessibilityLabel("分享或存储 \(item.title)")
                                    }
                                }
                                .padding(.vertical, 4)
                                .listRowBackground(AppPalette.surface)
                                .swipeActions {
                                    Button(role: .destructive) { store.remove(item.id) } label: {
                                        Label("删除", systemImage: "trash")
                                    }
                                }
                            }
                        }
                    }
                    .listStyle(.insetGrouped)
                    .scrollContentBackground(.hidden)
                }
            }
            .background(AppPalette.canvas)
            .navigationTitle("已保存")
        }
    }
}

private struct AddDownloadSheet: View {
    @Environment(\.dismiss) private var dismiss
    @ObservedObject var store: DownloadStore
    @State private var urlText = ""
    @State private var errorText: String?
    @FocusState private var focused: Bool

    var body: some View {
        NavigationStack {
            VStack(alignment: .leading, spacing: 18) {
                VStack(alignment: .leading, spacing: 7) {
                    Text("下载链接")
                        .font(.headline)
                    HStack(spacing: 8) {
                        TextField("https://example.com/file.mp4", text: $urlText, axis: .vertical)
                            .font(.subheadline.monospaced())
                            .textInputAutocapitalization(.never)
                            .autocorrectionDisabled()
                            .keyboardType(.URL)
                            .focused($focused)
                            .lineLimit(1...3)
                        Button {
                            urlText = UIPasteboard.general.string ?? ""
                        } label: {
                            Image(systemName: "doc.on.clipboard")
                                .font(.system(size: 18))
                                .frame(width: 40, height: 40)
                        }
                        .accessibilityLabel("粘贴链接")
                    }
                    .padding(.horizontal, 12)
                    .padding(.vertical, 6)
                    .background(AppPalette.surface, in: RoundedRectangle(cornerRadius: 8))
                }

                if let errorText {
                    Label(errorText, systemImage: "exclamationmark.circle")
                        .font(.footnote)
                        .foregroundStyle(.red)
                }

                Text("仅支持 HTTPS 文件直链。需要网站解析或登录态的内容，请使用桌面版。")
                    .font(.footnote)
                    .foregroundStyle(AppPalette.muted)
                    .fixedSize(horizontal: false, vertical: true)

                Button {
                    if let error = store.enqueue(urlText) {
                        errorText = error
                    } else {
                        dismiss()
                    }
                } label: {
                    Text("开始下载")
                        .font(.subheadline.weight(.semibold))
                        .frame(maxWidth: .infinity)
                        .frame(height: 48)
                        .background(AppPalette.accent, in: RoundedRectangle(cornerRadius: 8))
                        .foregroundStyle(.black)
                }
                .buttonStyle(.plain)

                Spacer(minLength: 0)
            }
            .padding(20)
            .background(AppPalette.canvas)
            .navigationTitle("添加下载")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button("取消") { dismiss() }
                }
            }
        }
        .onAppear { focused = true }
    }
}
