import Foundation
#if canImport(Darwin)
import Darwin
#elseif canImport(Glibc)
import Glibc
#endif

// Run independently of UIKit on a macOS runner:
// swiftc DownloadFileStager.swift DownloadFileStagerFixtures.swift -o stage-tests
// ./stage-tests
@main
struct DownloadFileStagerFixtures {
    struct FixtureFailure: LocalizedError {
        let message: String
        var errorDescription: String? { message }
    }

    static func require(_ condition: @autoclosure () -> Bool, _ message: String) throws {
        if !condition() { throw FixtureFailure(message: message) }
    }

    static func expectFailure(_ message: String, operation: () throws -> Void) throws {
        var failed = false
        do { try operation() } catch { failed = true }
        try require(failed, message)
    }

    static func main() throws {
        let manager = FileManager.default
        let root = manager.temporaryDirectory.appendingPathComponent("LibreGetStagerFixtures-\(UUID().uuidString)", isDirectory: true)
        let sourceDirectory = root.appendingPathComponent("daemon-owned", isDirectory: true)
        let stagingDirectory = root.appendingPathComponent("app-owned", isDirectory: true)
        try manager.createDirectory(at: sourceDirectory, withIntermediateDirectories: true)
        try manager.createDirectory(at: stagingDirectory, withIntermediateDirectories: true)
        defer {
            try? manager.setAttributes([.posixPermissions: NSNumber(value: 0o700)], ofItemAtPath: sourceDirectory.path)
            try? manager.removeItem(at: root)
        }
        // Span several copy buffers and retain non-text bytes, including zero.
        let payload = Data((0..<(3 * 1024 * 1024 + 17)).map { UInt8(truncatingIfNeeded: $0 * 31) })
        let source = sourceDirectory.appendingPathComponent("CFNetworkDownload_fixture.tmp")
        try payload.write(to: source)
        try manager.setAttributes([.posixPermissions: NSNumber(value: 0o444)], ofItemAtPath: source.path)
        try manager.setAttributes([.posixPermissions: NSNumber(value: 0o555)], ofItemAtPath: sourceDirectory.path)
        // The regression depends on real POSIX permission enforcement. Do not
        // silently pass under root, which can delete from a non-writable folder.
        try require(geteuid() != 0, "Run these fixtures as an unprivileged user so source-directory permissions are enforced.")
        try expectFailure("Original move unexpectedly deleted a file from the read-only source directory") {
            try manager.moveItem(at: source, to: stagingDirectory.appendingPathComponent("original-move.tmp"))
        }
        try require(manager.fileExists(atPath: source.path), "Failed move must preserve the URLSession-owned source")
        print("PASS: original move fails when source parent denies deletion")

        let destination = stagingDirectory.appendingPathComponent("item-attempt1-main.mp4")
        let size = try DownloadFileStager.copyDownload(from: source, to: destination)
        try require(size == Int64(payload.count), "Streamed copy reports an incorrect byte count")
        let copied = try Data(contentsOf: destination)
        try require(copied == payload, "Streamed copy changed the payload")
        let original = try Data(contentsOf: source)
        try require(original == payload, "Staging modified or removed the daemon-owned source")
        let sourceMode = try manager.attributesOfItem(atPath: source.path)[.posixPermissions] as? NSNumber
        let parentMode = try manager.attributesOfItem(atPath: sourceDirectory.path)[.posixPermissions] as? NSNumber
        let destinationMode = try manager.attributesOfItem(atPath: destination.path)[.posixPermissions] as? NSNumber
        try require(sourceMode?.intValue == 0o444 && parentMode?.intValue == 0o555, "Staging changed source permissions")
        try require(destinationMode?.intValue == 0o600, "Staging inherited read-only source permissions")
        print("PASS: read-only daemon source is copied byte-for-byte into app-owned writable storage")

        try expectFailure("Existing destination was overwritten") {
            try DownloadFileStager.copyDownload(from: source, to: destination)
        }
        let afterConflict = try Data(contentsOf: destination)
        try require(afterConflict == payload, "Destination conflict changed the completed file")
        print("PASS: target conflict preserves the completed file and source")

        let retryDestination = stagingDirectory.appendingPathComponent("item-attempt2-main.mp4")
        try DownloadFileStager.copyDownload(from: source, to: retryDestination)
        let final = root.appendingPathComponent("Downloads/final.mp4")
        try manager.createDirectory(at: final.deletingLastPathComponent(), withIntermediateDirectories: true)
        try manager.moveItem(at: retryDestination, to: final)
        let finalData = try Data(contentsOf: final)
        try require(finalData == payload, "App-owned staged file cannot be promoted to Downloads")
        print("PASS: retry uses a distinct file and final app-owned promotion succeeds")

        try manager.setAttributes([.posixPermissions: NSNumber(value: 0o000)], ofItemAtPath: source.path)
        defer { try? manager.setAttributes([.posixPermissions: NSNumber(value: 0o444)], ofItemAtPath: source.path) }
        let failedDestination = stagingDirectory.appendingPathComponent("failed-main.mp4")
        try expectFailure("Unreadable source unexpectedly succeeded") {
            try DownloadFileStager.copyDownload(from: source, to: failedDestination)
        }
        try require(!manager.fileExists(atPath: failedDestination.path), "Read failure exposed a partial destination")
        let remaining = try manager.contentsOfDirectory(atPath: stagingDirectory.path)
        try require(!remaining.contains(where: { $0.hasSuffix(".partial") }), "Read failure leaked an app-owned partial file")
        try require(manager.fileExists(atPath: source.path), "Read failure deleted the source")
        print("PASS: read failure removes only the app-owned partial file")

        let missing = sourceDirectory.appendingPathComponent("missing.tmp")
        try expectFailure("Missing source unexpectedly succeeded") {
            try DownloadFileStager.copyDownload(from: missing, to: stagingDirectory.appendingPathComponent("missing-output.mp4"))
        }
        try expectFailure("Non-file URL unexpectedly succeeded") {
            try DownloadFileStager.copyDownload(from: URL(string: "https://example.com/file")!, to: stagingDirectory.appendingPathComponent("remote-output.mp4"))
        }
        print("PASS: missing source and non-file URL fail safely")
        print("All DownloadFileStager fixtures passed.")
    }
}
