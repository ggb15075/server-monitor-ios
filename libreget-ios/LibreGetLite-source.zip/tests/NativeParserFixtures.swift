import Foundation

// Synthetic site responses exercise the production Swift parser without
// network availability, expiring media links, or credentials.
@main
struct NativeParserFixtures {
    static var checks = 0

    static func expect(_ value: @autoclosure () -> Bool, _ message: String) {
        checks += 1
        guard value() else { fatalError("Fixture failed: " + message) }
    }

    static func encoded(_ value: Any) throws -> Data {
        try JSONSerialization.data(withJSONObject: value, options: [.sortedKeys])
    }

    static func script(id: String, _ value: Any) throws -> Data {
        let body = String(decoding: try encoded(value), as: UTF8.self)
        return Data(("<script type='application/json' id='" + id + "'>" + body + "</script>").utf8)
    }

    static func rejects(_ message: String, _ body: () throws -> Void) {
        do { try body(); fatalError("Fixture did not reject: " + message) }
        catch { checks += 1 }
    }

    static func main() throws {
        let parser = NativeMediaParser()
        expect(parser.supports(URL(string: "https://v.douyin.com/example/")!), "Douyin short URL dispatch")
        expect(parser.supports(URL(string: "https://b23.tv/example")!), "Bilibili short URL dispatch")
        expect(!parser.supports(URL(string: "https://bilibili.com.attacker.invalid/video/BV1xx411c7mD")!), "domain suffix boundary")
        expect(!parser.supports(URL(string: "file:///tiktok.com/video/123")!), "non-HTTP scheme rejection")

        let douyinItem: [String: Any] = [
            "aweme_id": "123", "desc": "抖音测试\n第二行", "author": ["nickname": "作者"],
            "video": ["width": 1080, "height": 1920, "duration": 3000,
                      "bit_rate": [["bit_rate": 2000000, "play_addr": ["width": 1080, "height": 1920, "url_list": ["javascript:invalid", "https://media.invalid/video.mp4?a=1&amp;b=2"]]]],
                      "play_addr": ["url_list": ["https://media.invalid/video.mp4?a=1&b=2"]]]
        ]
        func douyinHTML(_ item: [String: Any]) throws -> Data {
            let object: [String: Any] = ["loaderData": ["video_(id)/page": ["videoInfoRes": ["item_list": [item]]]]]
            return Data(("<script>window._ROUTER_DATA = " + String(decoding: try encoded(object), as: UTF8.self) + ";</script>").utf8)
        }
        let douyin = try NativeMediaParser.fixture(platform: "douyin", payload: douyinHTML(douyinItem), originalURL: "https://www.douyin.com/video/123")
        expect(douyin.title == "抖音测试" && douyin.duration == 3, "Douyin title and millisecond duration")
        expect(douyin.formats.count == 1 && douyin.formats[0].quality == "1080p", "Douyin actual format deduplication")
        expect(douyin.formats[0].url.hasSuffix("a=1&b=2") && douyin.formats[0].headers["Referer"] != nil, "Douyin URL entities and headers")
        rejects("Douyin wrong post") {
            _ = try NativeMediaParser.fixture(platform: "douyin", payload: douyinHTML(douyinItem), originalURL: "https://www.douyin.com/video/456")
        }
        let images: [String: Any] = ["aweme_id": "123", "images": [["width": 400, "height": 600, "url_list": ["https://media.invalid/image.webp"]]]]
        let douyinImages = try NativeMediaParser.fixture(platform: "douyin", payload: douyinHTML(images), originalURL: "https://www.douyin.com/note/123")
        expect(douyinImages.formats[0].kind == .image && douyinImages.formats[0].fileExtension == "webp", "Douyin image kind and extension")

        let tiktokItem: [String: Any] = ["id": "123", "desc": "TikTok test", "video": ["width": 720, "height": 1280, "playAddr": "https://media.invalid/tiktok.mp4", "downloadAddr": "https://media.invalid/tiktok.mp4"]]
        let universal: [String: Any] = ["__DEFAULT_SCOPE__": ["webapp.video-detail": ["statusCode": 0, "itemInfo": ["itemStruct": tiktokItem]]]]
        let tiktok = try NativeMediaParser.fixture(platform: "tiktok", payload: script(id: "__UNIVERSAL_DATA_FOR_REHYDRATION__", universal), originalURL: "https://www.tiktok.com/@test/video/123")
        expect(tiktok.formats.count == 1 && tiktok.formats[0].width == 720, "TikTok modern hydration and deduplication")
        let sigi: [String: Any] = ["ItemModule": ["123": tiktokItem]]
        let legacy = try NativeMediaParser.fixture(platform: "tiktok", payload: script(id: "SIGI_STATE", sigi), originalURL: "https://www.tiktok.com/@test/video/123")
        expect(legacy.formats[0].url == tiktok.formats[0].url, "TikTok SIGI_STATE fallback")
        rejects("TikTok wrong post") {
            _ = try NativeMediaParser.fixture(platform: "tiktok", payload: script(id: "__UNIVERSAL_DATA_FOR_REHYDRATION__", universal), originalURL: "https://www.tiktok.com/@test/video/456")
        }
        let unsafe: [String: Any] = ["ItemModule": ["123": ["id": "123", "video": ["playAddr": "https://user:password@media.invalid/private.mp4"]]]]
        rejects("media URL containing credentials") {
            _ = try NativeMediaParser.fixture(platform: "tiktok", payload: script(id: "SIGI_STATE", unsafe), originalURL: "https://www.tiktok.com/@test/video/123")
        }

        let wbi = try NativeMediaParser.fixtureWBI(["foo": "114", "bar": "514"], imageKey: "7cd084941338484aae1ad9425b84077c", subKey: "4932caff0ff746eab6f01bf08b70ac45", timestamp: 1702204169)
        expect(wbi == "bar=514&foo=114&wts=1702204169&w_rid=ed791ce4979dfe1e2aad3b03b73b13cc", "WBI stable signature vector")
        let view: [String: Any] = ["code": 0, "data": ["title": "Bilibili test", "owner": ["name": "作者"], "pages": [["page": 1, "part": "第一部分"], ["page": 2, "part": "第二部分"]]]]
        let dash: [String: Any] = [
            "video": [["baseUrl": "https://media.invalid/av1.m4s", "codecid": 13, "width": 3840, "height": 2160],
                      ["base_url": "https://media.invalid/avc.m4s", "codecid": 7, "width": 1920, "height": 1080, "size": 1000]],
            "audio": [["baseUrl": "https://media.invalid/audio-low.m4s", "codecs": "mp4a.40.2", "bandwidth": 64000, "size": 200],
                      ["baseUrl": "https://media.invalid/audio.m4s", "codecs": "mp4a.40.2", "bandwidth": 128000, "size": 300]]
        ]
        func bilibili(_ playData: [String: Any]) throws -> ResolvedMedia {
            try NativeMediaParser.fixture(platform: "bilibili", payload: encoded(view), auxiliary: encoded(["code": 0, "data": playData]), originalURL: "https://www.bilibili.com/video/BV1xx411c7mD")
        }
        let bili = try bilibili(["dash": dash, "timelength": 10000])
        expect(bili.formats.count == 2 && bili.formats[0].height == 1080, "Bilibili unsupported AV1 excluded")
        expect(bili.formats[0].audioURL == "https://media.invalid/audio.m4s" && bili.formats[0].audioHeaders == bili.formats[0].headers, "Bilibili best AAC paired with request headers")
        expect(bili.formats[0].approximateBytes == 1300 && bili.duration == 10, "Bilibili combined size and duration")
        expect(bili.title == "Bilibili test P1 · 第一部分", "Bilibili part title")
        rejects("Bilibili FLV") { _ = try bilibili(["format": "flv720", "durl": [["url": "https://media.invalid/file.flv"]]]) }
        rejects("Bilibili multiple segments") { _ = try bilibili(["durl": [["url": "https://media.invalid/one.mp4"], ["url": "https://media.invalid/two.mp4"]]]) }
        var unsupportedAudio = dash
        unsupportedAudio["audio"] = [["baseUrl": "https://media.invalid/flac.m4s", "codecs": "fLaC"]]
        rejects("Bilibili incompatible audio cannot yield silently incomplete video") { _ = try bilibili(["dash": unsupportedAudio]) }

        let xResponse: [String: Any] = ["text": "X media", "mediaDetails": [
            ["type": "video", "video_info": ["variants": [
                ["content_type": "application/x-mpegURL", "url": "https://media.invalid/video.m3u8"],
                ["content_type": "video/mp4", "url": "https://media.invalid/vid/720x1280/video.mp4", "bitrate": 1000000]]]],
            ["type": "photo", "media_url_https": "https://pbs.twimg.com/media/example.jpg?name=small"]]]
        let x = try NativeMediaParser.fixture(platform: "twitter", payload: encoded(xResponse), originalURL: "https://x.com/test/status/123")
        expect(x.formats.count == 2 && x.formats[0].height == 1280, "X direct MP4 preferred over HLS and dimensions parsed")
        expect(x.formats[1].kind == .image && x.formats[1].url.hasSuffix("name=orig"), "X original photo")
        let hlsOnly: [String: Any] = ["video": ["variants": [["type": "application/x-mpegURL", "src": "https://media.invalid/video.m3u8"]]]]
        let xHLS = try NativeMediaParser.fixture(platform: "twitter", payload: encoded(hlsOnly), originalURL: "https://x.com/test/status/123")
        expect(xHLS.formats[0].protocolHint == "hls", "X HLS-only protocol preserved")
        rejects("X deleted tweet") { _ = try NativeMediaParser.fixture(platform: "twitter", payload: encoded(["__typename": "TweetTombstone"]), originalURL: "https://x.com/test/status/123") }
        print("Native parser fixtures passed: \(checks) checks")
    }
}
