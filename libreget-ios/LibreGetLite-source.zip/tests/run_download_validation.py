"""Exercise real production transports on macOS and DownloadStore on iOS Simulator."""
from pathlib import Path
import json
import os
import platform
import plistlib
import subprocess
import sys
import time
import urllib.request

IOS = Path(__file__).resolve().parents[1]
SOURCES = IOS / "LibreGetLite" / "LibreGetLite"
TESTS = IOS / "tests"
OUTPUT = Path(os.environ.get("RUNNER_TEMP", "/tmp")) / "libreget-download-validation"
OUTPUT.mkdir(parents=True, exist_ok=True)


def run(*args, timeout=180, capture=False):
    print("RUN:", " ".join(map(str, args)), flush=True)
    result = subprocess.run(list(map(str, args)), check=True, timeout=timeout,
                            text=True, capture_output=capture)
    return result.stdout.strip() if capture else None


def main():
    server_log = (OUTPUT / "http-server.log").open("w")
    server = subprocess.Popen([sys.executable, str(TESTS / "download_fixture_server.py"), "--port", "18765"],
                              stdout=server_log, stderr=subprocess.STDOUT)
    try:
        deadline = time.monotonic() + 15
        while True:
            try:
                with urllib.request.urlopen("http://127.0.0.1:18765/health", timeout=1) as response:
                    assert response.read() == b"ready"
                break
            except OSError:
                if server.poll() is not None or time.monotonic() > deadline:
                    raise RuntimeError("Local HTTP fixture server did not start")
                time.sleep(0.1)

        fixture = OUTPUT / "stream-fixtures"
        run("swiftc", "-target", platform.machine() + "-apple-macosx13.0",
            SOURCES / "AppOwnedStreamDownloader.swift", TESTS / "AppOwnedStreamFixtures.swift", "-o", fixture)
        with (OUTPUT / "macos-stream-fixtures.log").open("w") as log:
            result = subprocess.run([str(fixture), "http://127.0.0.1:18765"], timeout=90, stdout=log, stderr=subprocess.STDOUT)
        print((OUTPUT / "macos-stream-fixtures.log").read_text(), flush=True)
        result.check_returncode()

        sdk = run("xcrun", "--sdk", "iphonesimulator", "--show-sdk-path", capture=True)
        app = OUTPUT / "DownloadStoreFixtures.app"
        app.mkdir(exist_ok=True)
        app_id = "com.openselena.libreget.downloadfixtures"
        info = {
            "CFBundleExecutable": "DownloadStoreFixtures", "CFBundleIdentifier": app_id,
            "CFBundleName": "DownloadStoreFixtures", "CFBundlePackageType": "APPL",
            "CFBundleShortVersionString": "1.0", "CFBundleVersion": "1",
            "MinimumOSVersion": "16.0", "LSRequiresIPhoneOS": True,
            "UIDeviceFamily": [1, 2], "UILaunchScreen": {},
            "NSAppTransportSecurity": {"NSAllowsArbitraryLoads": True},
        }
        (app / "Info.plist").write_bytes(plistlib.dumps(info))
        run("xcrun", "swiftc", "-sdk", sdk, "-target", platform.machine() + "-apple-ios16.0-simulator",
            "-D", "DOWNLOAD_STORE_FIXTURES", "-parse-as-library",
            SOURCES / "MediaModels.swift", SOURCES / "DownloadFileStager.swift",
            SOURCES / "AppOwnedStreamDownloader.swift", SOURCES / "DownloadStore.swift",
            TESTS / "SimulatorDownloadStoreSmoke.swift", "-o", app / "DownloadStoreFixtures")
        fixture_entitlements = OUTPUT / "simulator-entitlements.plist"
        fixture_entitlements.write_bytes(plistlib.dumps({
            "application-identifier": "TROLLTROLL." + app_id,
            "com.apple.developer.team-identifier": "TROLLTROLL",
        }))
        run("codesign", "--force", "--sign", "-", "--entitlements", fixture_entitlements, str(app))
        devices = json.loads(run("xcrun", "simctl", "list", "devices", "available", "--json", capture=True))
        choices = [d for group in devices["devices"].values() for d in group
                   if d.get("isAvailable") and "iPhone" in d.get("name", "")]
        assert choices, "No installed iPhone simulator runtime"
        selected = next((d for d in choices if d["state"] == "Booted"), choices[0])
        udid = selected["udid"]
        if selected["state"] != "Booted":
            run("xcrun", "simctl", "boot", udid)
        run("xcrun", "simctl", "bootstatus", udid, "-b", timeout=240)
        run("xcrun", "simctl", "install", udid, app)
        container = Path(run("xcrun", "simctl", "get_app_container", udid, app_id, "data", capture=True))
        report_path = container / "Documents" / "download-store-simulator-report.json"
        if report_path.exists():
            report_path.unlink()
        run("xcrun", "simctl", "launch", "--terminate-running-process", udid, app_id)
        deadline = time.monotonic() + 150
        while not report_path.exists():
            if time.monotonic() > deadline:
                raise RuntimeError("Simulator fixture did not write a report within 150 seconds")
            time.sleep(0.5)
        report_bytes = report_path.read_bytes()
        (OUTPUT / report_path.name).write_bytes(report_bytes)
        report = json.loads(report_bytes)
        print(json.dumps(report, ensure_ascii=False, indent=2), flush=True)
        assert report.get("passed") is True, "Production DownloadStore simulator regression failed"
        assert report.get("check_count", 0) >= 13, "Simulator checks were skipped"
    finally:
        server.terminate()
        try:
            server.wait(timeout=5)
        except subprocess.TimeoutExpired:
            server.kill()
            server.wait(timeout=5)
        server_log.close()


if __name__ == "__main__":
    main()
