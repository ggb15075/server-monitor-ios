"""Exercise real production transports on macOS and DownloadStore on iOS Simulator."""
from pathlib import Path
import json
import os
import platform
import plistlib
import shutil
import subprocess
import sys
import time
import urllib.request

IOS = Path(__file__).resolve().parents[1]
SOURCES = IOS / "LibreGetLite" / "LibreGetLite"
TESTS = IOS / "tests"
OUTPUT = Path(os.environ.get("RUNNER_TEMP", "/tmp")) / "libreget-download-validation"
OUTPUT.mkdir(parents=True, exist_ok=True)


def run(*args, timeout=180, capture=False):
    print("RUN:", " ".join(map(str, args)), flush=True)
    with (OUTPUT / "commands.log").open("a") as log:
        log.write("RUN: " + " ".join(map(str, args)) + "\n")
        log.flush()
    result = subprocess.run(list(map(str, args)), timeout=timeout,
                            text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    with (OUTPUT / "commands.log").open("a") as log:
        log.write(result.stdout + result.stderr + "\n")
    if not capture or result.returncode:
        print(result.stdout + result.stderr, flush=True)
    result.check_returncode()
    return result.stdout.strip() if capture else None


def build_simulator_app(info, entitlements):
    """Let Xcode generate simulator-only entitlements and platform metadata."""
    project = OUTPUT / "DownloadStoreFixtures.xcodeproj"
    project.mkdir(exist_ok=True)
    info_path = OUTPUT / "SimulatorInfo.plist"
    info_path.write_bytes(plistlib.dumps(info))
    source_paths = [SOURCES / "MediaModels.swift", SOURCES / "DownloadFileStager.swift",
                    SOURCES / "AppOwnedStreamDownloader.swift", SOURCES / "DownloadStore.swift",
                    TESTS / "SimulatorDownloadStoreSmoke.swift"]
    objects = []
    refs, builds = [], []
    for index, path in enumerate(source_paths, 1):
        ref, build = f"B{index:023X}", f"A{index:023X}"
        refs.append(ref)
        builds.append(build)
        objects.append(f'{ref} = {{isa = PBXFileReference; lastKnownFileType = sourcecode.swift; path = {json.dumps(str(path))}; sourceTree = "<absolute>"; }};')
        objects.append(f'{build} = {{isa = PBXBuildFile; fileRef = {ref}; }};')
    objects.extend([
        'B00000000000000000000010 = {isa = PBXFileReference; explicitFileType = wrapper.application; path = DownloadStoreFixtures.app; sourceTree = BUILT_PRODUCTS_DIR; };',
        'D00000000000000000000001 = {isa = PBXGroup; children = (' + ','.join(refs) + ',D00000000000000000000002,); sourceTree = "<group>"; };',
        'D00000000000000000000002 = {isa = PBXGroup; name = Products; children = (B00000000000000000000010,); sourceTree = "<group>"; };',
        'C00000000000000000000001 = {isa = PBXSourcesBuildPhase; buildActionMask = 2147483647; files = (' + ','.join(builds) + ',); runOnlyForDeploymentPostprocessing = 0; };',
        'E00000000000000000000001 = {isa = PBXNativeTarget; buildConfigurationList = F00000000000000000000002; buildPhases = (C00000000000000000000001,); buildRules = (); dependencies = (); name = DownloadStoreFixtures; productName = DownloadStoreFixtures; productReference = B00000000000000000000010; productType = "com.apple.product-type.application"; };',
        'E00000000000000000000002 = {isa = PBXProject; attributes = {LastUpgradeCheck = 1600; }; buildConfigurationList = F00000000000000000000001; compatibilityVersion = "Xcode 14.0"; developmentRegion = en; hasScannedForEncodings = 0; knownRegions = (en,); mainGroup = D00000000000000000000001; productRefGroup = D00000000000000000000002; projectDirPath = ""; projectRoot = ""; targets = (E00000000000000000000001,); };',
        'F00000000000000000000001 = {isa = XCConfigurationList; buildConfigurations = (F20000000000000000000001,); defaultConfigurationIsVisible = 0; defaultConfigurationName = Debug; };',
        'F00000000000000000000002 = {isa = XCConfigurationList; buildConfigurations = (F20000000000000000000002,); defaultConfigurationIsVisible = 0; defaultConfigurationName = Debug; };',
        'F20000000000000000000001 = {isa = XCBuildConfiguration; name = Debug; buildSettings = {SDKROOT = iphonesimulator; CLANG_ENABLE_MODULES = YES; }; };',
        'F20000000000000000000002 = {isa = XCBuildConfiguration; name = Debug; buildSettings = {'
        ' PRODUCT_BUNDLE_IDENTIFIER = com.openselena.libreget.downloadfixtures; PRODUCT_NAME = "$(TARGET_NAME)";'
        ' SWIFT_VERSION = 5.0; SWIFT_ACTIVE_COMPILATION_CONDITIONS = DOWNLOAD_STORE_FIXTURES;'
        ' IPHONEOS_DEPLOYMENT_TARGET = 16.0; TARGETED_DEVICE_FAMILY = "1,2";'
        ' GENERATE_INFOPLIST_FILE = NO; INFOPLIST_FILE = ' + json.dumps(str(info_path)) + ';'
        ' CODE_SIGN_STYLE = Manual; CODE_SIGN_IDENTITY = "-"; CODE_SIGN_ENTITLEMENTS = ' + json.dumps(str(entitlements)) + ';'
        ' LD_RUNPATH_SEARCH_PATHS = ("$(inherited)", "@executable_path/Frameworks", "/usr/lib/swift",);'
        ' }; };',
    ])
    (project / "project.pbxproj").write_text('// !$*UTF8*$!\n{archiveVersion = 1; classes = {}; objectVersion = 56; objects = {\n' + '\n'.join(objects) + '\n}; rootObject = E00000000000000000000002; }\n')
    products = OUTPUT / "SimulatorProducts"
    run("xcodebuild", "-project", project, "-target", "DownloadStoreFixtures", "-configuration", "Debug",
        "-sdk", "iphonesimulator", "ARCHS=" + platform.machine(), "ONLY_ACTIVE_ARCH=YES",
        "CODE_SIGNING_ALLOWED=YES", "CODE_SIGNING_REQUIRED=YES", "SYMROOT=" + str(products),
        "OBJROOT=" + str(OUTPUT / "SimulatorIntermediates"), "build", timeout=240)
    return products / "Debug-iphonesimulator" / "DownloadStoreFixtures.app"


def main():
    server_log = (OUTPUT / "http-server.log").open("w")
    server = subprocess.Popen([sys.executable, str(TESTS / "download_fixture_server.py"), "--port", "18765"],
                              stdout=server_log, stderr=subprocess.STDOUT)
    try:
        deadline = time.monotonic() + 15
        while True:
            try:
                with urllib.request.urlopen("http://127.0.0.1:18765/health", timeout=1) as response:
                    assert response.read() == b"ready"
                break
            except OSError:
                if server.poll() is not None or time.monotonic() > deadline:
                    raise RuntimeError("Local HTTP fixture server did not start")
                time.sleep(0.1)

        fixture = OUTPUT / "stream-fixtures"
        run("swiftc", "-target", platform.machine() + "-apple-macosx13.0",
            SOURCES / "AppOwnedStreamDownloader.swift", TESTS / "AppOwnedStreamFixtures.swift", "-o", fixture)
        with (OUTPUT / "macos-stream-fixtures.log").open("w") as log:
            result = subprocess.run([str(fixture), "http://127.0.0.1:18765"], timeout=90, stdout=log, stderr=subprocess.STDOUT)
        print((OUTPUT / "macos-stream-fixtures.log").read_text(), flush=True)
        result.check_returncode()

        app_id = "com.openselena.libreget.downloadfixtures"
        info = {
            "CFBundleExecutable": "DownloadStoreFixtures", "CFBundleIdentifier": app_id,
            "CFBundleName": "DownloadStoreFixtures", "CFBundlePackageType": "APPL",
            "CFBundleInfoDictionaryVersion": "6.0",
            "CFBundleSupportedPlatforms": ["iPhoneSimulator"],
            "DTPlatformName": "iphonesimulator",
            "DTSDKName": "iphonesimulator" + run("xcrun", "--sdk", "iphonesimulator", "--show-sdk-version", capture=True),
            "CFBundleShortVersionString": "1.0", "CFBundleVersion": "1",
            "MinimumOSVersion": "16.0", "LSRequiresIPhoneOS": True,
            "UIDeviceFamily": [1, 2], "UILaunchScreen": {},
            "NSAppTransportSecurity": {"NSAllowsArbitraryLoads": True},
        }
        fixture_entitlements = OUTPUT / "simulator-entitlements.plist"
        fixture_entitlements.write_bytes(plistlib.dumps({
            "application-identifier": "TROLLTROLL." + app_id,
            "com.apple.developer.team-identifier": "TROLLTROLL",
        }))
        app = build_simulator_app(info, fixture_entitlements)
        devices = json.loads(run("xcrun", "simctl", "list", "devices", "available", "--json", capture=True))
        choices = [d for group in devices["devices"].values() for d in group
                   if d.get("isAvailable") and "iPhone" in d.get("name", "")]
        assert choices, "No installed iPhone simulator runtime"
        selected = next((d for d in choices if d["state"] == "Booted"), choices[0])
        udid = selected["udid"]
        if selected["state"] != "Booted":
            run("xcrun", "simctl", "boot", udid)
        run("xcrun", "simctl", "bootstatus", udid, "-b", timeout=240)
        run("xcrun", "simctl", "install", udid, app)
        container = Path(run("xcrun", "simctl", "get_app_container", udid, app_id, "data", capture=True))
        report_path = container / "Documents" / "download-store-simulator-report.json"
        if report_path.exists():
            report_path.unlink()
        console_path = OUTPUT / "simulator-console.log"
        command = ["xcrun", "simctl", "launch", "--console", "--terminate-running-process", udid, app_id]
        print("RUN:", " ".join(command), flush=True)
        with console_path.open("w") as console:
            # A console session stays attached until app exit. Use a regular
            # file so inherited output handles cannot block a PIPE reader.
            launch = subprocess.Popen(command, stdout=console, stderr=subprocess.STDOUT)
            try:
                deadline = time.monotonic() + 150
                while not report_path.exists():
                    if launch.poll() is not None:
                        raise RuntimeError("Simulator app exited without report, status " + str(launch.returncode))
                    if time.monotonic() > deadline:
                        raise RuntimeError("Simulator fixture did not write a report within 150 seconds")
                    time.sleep(0.5)
            except Exception:
                print(console_path.read_text(errors="replace"), flush=True)
                with (OUTPUT / "simulator-system.log").open("w") as system_log:
                    try:
                        subprocess.run(["xcrun", "simctl", "spawn", udid, "log", "show", "--last", "4m", "--style", "compact",
                                        "--predicate", 'eventMessage CONTAINS "downloadfixtures" OR process == "DownloadStoreFixtures"'],
                                       stdout=system_log, stderr=subprocess.STDOUT, timeout=45)
                    except subprocess.TimeoutExpired:
                        system_log.write("System log capture timed out\n")
                crash_dir = Path.home() / "Library" / "Logs" / "DiagnosticReports"
                for crash in crash_dir.glob("DownloadStoreFixtures*"):
                    if crash.is_file():
                        shutil.copyfile(crash, OUTPUT / (crash.name + ".log"))
                raise
            finally:
                try:
                    launch.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    launch.terminate()
                    try:
                        launch.wait(timeout=5)
                    except subprocess.TimeoutExpired:
                        launch.kill()
                        launch.wait(timeout=5)
        print(console_path.read_text(errors="replace"), flush=True)
        report_bytes = report_path.read_bytes()
        (OUTPUT / report_path.name).write_bytes(report_bytes)
        report = json.loads(report_bytes)
        print(json.dumps(report, ensure_ascii=False, indent=2), flush=True)
        assert report.get("passed") is True, "Production DownloadStore simulator regression failed"
        assert report.get("check_count", 0) >= 13, "Simulator checks were skipped"
    finally:
        server.terminate()
        try:
            server.wait(timeout=5)
        except subprocess.TimeoutExpired:
            server.kill()
            server.wait(timeout=5)
        server_log.close()


if __name__ == "__main__":
    main()
