import Foundation
import AVFoundation
import CryptoKit
import Darwin

// Compile alongside the production MediaModels, ShareLinkParser,
// NativeMediaParser and AppOwnedStreamDownloader sources. Checks streaming metadata,
// downloads the user-provided public sample and
// verifies its actual AVFoundation tracks, rather than trusting web metadata.
@main
struct LiveDouyinSmoke {
    static let shareText = "6.94 复制打开抖音，看看【酷酷鸽子的作品】人是环境的产物：） # 2026APEC见证深圳开... https://v.douyin.com/T4GQRgwdReI/ kpd:/ D@U.YZ :2pm 01/07"

    struct SmokeFailure: LocalizedError {
        let message: String
        var errorDescription: String? { message }
    }

    static func require(_ value: Bool, _ message: String) throws {
        guard value else { throw SmokeFailure(message: message) }
    }

    static func sha256(_ url: URL) throws -> String {
        let handle = try FileHandle(forReadingFrom: url)
        defer { try? handle.close() }
        var hash = SHA256()
        while let chunk = try handle.read(upToCount: 1024 * 1024), !chunk.isEmpty { hash.update(data: chunk) }
        return hash.finalize().map { String(format: "%02x", $0) }.joined()
    }

    @MainActor
    final class StreamOperation {
        private var downloader: AppOwnedStreamDownloader?
        private(set) var receivedProgress = false

        func download(_ request: URLRequest, to destination: URL) async throws -> AppOwnedStreamDownloader.CompletedFile {
            // Completion resumes the suspended task on the main queue; there
            // is no semaphore or blocking wait that could stop that queue.
            try await withCheckedThrowingContinuation { continuation in
                downloader = AppOwnedStreamDownloader(request: request, destination: destination, callbackQueue: .main,
                    progress: { [weak self] received, _ in self?.receivedProgress = received > 0 },
                    completion: { continuation.resume(with: $0) })
                downloader?.start()
            }
        }
    }

    @MainActor
    static func main() async {
        let output = URL(fileURLWithPath: CommandLine.arguments.dropFirst().first ?? "live-douyin-smoke", isDirectory: true)
        var report: [String: Any] = [
            "test": "User Douyin share text, production Swift parser and real download",
            "started_utc": ISO8601DateFormatter().string(from: Date()),
            "platform": "macOS command line; not an iPhone test", "passed": false
        ]
        var success = false
        do {
            try FileManager.default.createDirectory(at: output, withIntermediateDirectories: true)
            let url = try ShareLinkParser.extractURL(shareText)
            try require(url.absoluteString == "https://v.douyin.com/T4GQRgwdReI/", "Full share text extracted a different URL")
            report["share_text_extraction_matches"] = true
            report["requested_short_url"] = url.absoluteString
            try require(try ShareLinkParser.extractURL(url.absoluteString) == url, "Direct URL extraction differs")
            do {
                _ = try ShareLinkParser.extractURL("这里没有下载链接 kpd:/ D@U.YZ")
                throw SmokeFailure(message: "Text without HTTP link was accepted")
            } catch MediaResolveError.invalidURL { report["invalid_share_text_rejected"] = true }
            let parser = NativeMediaParser()
            try require(parser.supports(url), "Short URL was not dispatched to native parser")
            let media = try await parser.resolve(url)
            report["title"] = media.title
            report["author"] = media.author ?? ""
            report["extractor"] = media.extractor
            report["reported_duration_seconds"] = media.duration
            report["format_count"] = media.formats.count
            guard let selected = media.formats.first(where: { $0.kind == .video }), let mediaURL = URL(string: selected.url) else {
                throw SmokeFailure(message: "Native parser returned no video format")
            }
            try require(selected.audioURL == nil, "Douyin sample unexpectedly requires a separate audio merge")
            report["selected_format"] = ["id": selected.id, "quality": selected.quality,
                                         "reported_width": selected.width ?? 0, "reported_height": selected.height ?? 0]
            // Match the production preview asset's public UA/cookie options
            // and context-only compatibility headers. Never pass arbitrary
            // credentials as headers AVFoundation could forward to subhosts.
            // The production preview resolves CDN redirects with HEAD before
            // handing the final URL to AVFoundation. This sample needs only
            // public context, so the probe excludes account or custom headers.
            let probeConfiguration = URLSessionConfiguration.ephemeral
            probeConfiguration.timeoutIntervalForRequest = 15
            probeConfiguration.timeoutIntervalForResource = 20
            let probeSession = URLSession(configuration: probeConfiguration)
            defer { probeSession.finishTasksAndInvalidate() }
            var probeRequest = URLRequest(url: mediaURL)
            probeRequest.httpMethod = "HEAD"
            let publicHeaders = selected.headers.filter {
                ["user-agent", "referer", "origin", "accept", "accept-language"].contains($0.key.lowercased())
            }
            for (name, value) in publicHeaders { probeRequest.setValue(value, forHTTPHeaderField: name) }
            let (_, probeResponse) = try await probeSession.data(for: probeRequest)
            guard let streamURL = probeResponse.url, ["http", "https"].contains(streamURL.scheme?.lowercased() ?? "") else {
                throw SmokeFailure(message: "Streaming preflight returned no valid media URL")
            }
            let streamCookies = probeConfiguration.httpCookieStorage?.cookies(for: streamURL) ?? []
            report["remote_stream_asset_host"] = streamURL.host ?? ""
            var streamOptions: [String: Any] = [AVURLAssetHTTPCookiesKey: streamCookies]
            if let agent = selected.headers.first(where: { $0.key.lowercased() == "user-agent" })?.value {
                streamOptions[AVURLAssetHTTPUserAgentKey] = agent
            }
            let streamContext = selected.headers.filter {
                ["referer", "origin", "accept", "accept-language"].contains($0.key.lowercased())
            }
            if !streamContext.isEmpty { streamOptions["AVURLAssetHTTPHeaderFieldsKey"] = streamContext }
            let remoteAsset = AVURLAsset(url: streamURL, options: streamOptions)
            report["remote_stream_playable"] = false
            let remotePlayable = try await remoteAsset.load(.isPlayable)
            report["remote_stream_playable"] = remotePlayable
            try require(remotePlayable, "AVFoundation could not play the resolved remote media URL")
            let remoteVideos = try await remoteAsset.loadTracks(withMediaType: .video)
            let remoteAudios = try await remoteAsset.loadTracks(withMediaType: .audio)
            let remoteDuration = try await remoteAsset.load(.duration).seconds
            report["remote_video_track_count"] = remoteVideos.count
            report["remote_audio_track_count"] = remoteAudios.count
            report["remote_duration_seconds"] = remoteDuration
            try require(!remoteVideos.isEmpty && !remoteAudios.isEmpty, "Remote media URL was missing video or audio tracks")
            try require(remoteDuration.isFinite && remoteDuration > 0, "Remote media URL had invalid duration")
            var request = URLRequest(url: mediaURL)
            request.timeoutInterval = 60
            for (name, value) in selected.headers { request.setValue(value, forHTTPHeaderField: name) }
            let destination = output.appendingPathComponent("douyin-swift-video.mp4")
            try? FileManager.default.removeItem(at: destination)
            let operation = StreamOperation()
            let completed = try await operation.download(request, to: destination)
            let http = completed.response
            report["download_transporter"] = "Production AppOwnedStreamDownloader URLSessionDataTask"
            report["download_background_daemon_exercised"] = false
            report["stream_progress_received"] = operation.receivedProgress
            report["download_http_status"] = http.statusCode
            report["download_content_type"] = http.mimeType ?? ""
            report["download_final_host"] = http.url?.host ?? ""
            try require((200..<300).contains(http.statusCode), "Media download returned a non-success HTTP status")
            let attributes = try destination.resourceValues(forKeys: [.fileSizeKey])
            report["download_bytes"] = attributes.fileSize ?? 0
            try require((attributes.fileSize ?? 0) > 0, "Downloaded file was empty")
            try require(Int64(attributes.fileSize ?? 0) == completed.bytes, "Production stream wrote an unexpected byte count")
            report["sha256"] = try sha256(destination)
            let asset = AVURLAsset(url: destination)
            let videos = try await asset.loadTracks(withMediaType: .video)
            let audios = try await asset.loadTracks(withMediaType: .audio)
            let duration = try await asset.load(.duration).seconds
            report["video_track_count"] = videos.count
            report["audio_track_count"] = audios.count
            report["actual_duration_seconds"] = duration
            try require(!videos.isEmpty && !audios.isEmpty, "Downloaded sample was missing video or audio tracks")
            try require(duration.isFinite && duration > 0, "Downloaded sample had invalid duration")
            if let track = videos.first {
                let size = try await track.load(.naturalSize)
                report["actual_width"] = abs(size.width)
                report["actual_height"] = abs(size.height)
            }
            success = true
            report["passed"] = true
        } catch {
            // Do not emit NSError descriptions for network errors: they can
            // contain the full temporary signed media URL and its query token.
            if let failure = error as? SmokeFailure { report["failure"] = failure.message }
            else {
                let failure = error as NSError
                report["failure_domain"] = failure.domain
                report["failure_code"] = failure.code
                if failure.domain != NSURLErrorDomain {
                    report["failure"] = failure.localizedDescription.replacingOccurrences(
                        of: #"https?://[^\s\"<>]+"#, with: "[redacted URL]", options: .regularExpression)
                }
            }
        }
        report["finished_utc"] = ISO8601DateFormatter().string(from: Date())
        if let data = try? JSONSerialization.data(withJSONObject: report, options: [.prettyPrinted, .sortedKeys]) {
            try? data.write(to: output.appendingPathComponent("douyin-swift-report.json"))
            print(String(decoding: data, as: UTF8.self))
        }
        exit(success ? 0 : 1)
    }
}
