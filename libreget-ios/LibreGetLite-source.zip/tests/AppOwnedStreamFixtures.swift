import Foundation
import CryptoKit
import Darwin

// Compile with production AppOwnedStreamDownloader.swift. These tests use real
// HTTP sockets, response validation, disk writes and cancellation callbacks.
@main
struct AppOwnedStreamFixtures {
    struct FixtureFailure: LocalizedError {
        let message: String
        var errorDescription: String? { message }
    }

    @MainActor
    final class DownloadOperation {
        var worker: AppOwnedStreamDownloader?
        var receivedProgress = false
        var cancellationRequested = false

        func run(_ request: URLRequest, destination: URL, cancelOnProgress: Bool = false) async throws -> AppOwnedStreamDownloader.CompletedFile {
            try await withCheckedThrowingContinuation { continuation in
                worker = AppOwnedStreamDownloader(request: request, destination: destination, callbackQueue: .main, progress: { [weak self] received, _ in
                    guard let self else { return }
                    self.receivedProgress = self.receivedProgress || received > 0
                    if cancelOnProgress && received > 0 && !self.cancellationRequested {
                        self.cancellationRequested = true
                        self.worker?.cancel()
                    }
                }, completion: { result in
                    continuation.resume(with: result)
                })
                worker?.start()
            }
        }
    }

    static func require(_ condition: Bool, _ message: String) throws {
        guard condition else { throw FixtureFailure(message: message) }
    }

    @MainActor
    static func main() async {
        let manager = FileManager.default
        let root = manager.temporaryDirectory.appendingPathComponent("LibreGetStreamFixtures-\(UUID().uuidString)", isDirectory: true)
        var passed = false
        var checks = 0
        do {
            guard let baseArgument = CommandLine.arguments.dropFirst().first, let base = URL(string: baseArgument) else {
                throw FixtureFailure(message: "Provide local fixture server base URL")
            }
            try manager.createDirectory(at: root, withIntermediateDirectories: true)
            let payload = Data((0..<(2 * 1024 * 1024 + 17)).map { UInt8(truncatingIfNeeded: $0 * 31) })
            let expectedHash = SHA256.hash(data: payload).map { String(format: "%02x", $0) }.joined()

            func checked(_ condition: Bool, _ message: String) throws {
                try require(condition, message)
                checks += 1
                print("PASS: " + message)
            }

            let cocoa = NSError(domain: NSCocoaErrorDomain, code: 513, userInfo: [NSFilePathErrorKey: "/private/var/mobile/Containers/Data/Application/fixture/tmp/CFNetworkDownload.tmp"])
            let nested = NSError(domain: NSURLErrorDomain, code: NSURLErrorUnknown, userInfo: [NSUnderlyingErrorKey: cocoa])
            try checked(DownloadTransportPolicy.shouldFallback(from: cocoa), "Cocoa 513 background file permission failure permits fallback")
            try checked(DownloadTransportPolicy.shouldFallback(from: nested), "Nested Cocoa 513 underlying error permits fallback")
            try checked(DownloadTransportPolicy.shouldFallback(from: NSError(domain: NSURLErrorDomain, code: -3001)), "URL download temporary file write failure permits fallback")
            try checked(!DownloadTransportPolicy.shouldFallback(from: NSError(domain: NSURLErrorDomain, code: NSURLErrorCancelled)), "Cancellation does not permit fallback")
            try checked(!DownloadTransportPolicy.shouldFallback(from: NSError(domain: NSURLErrorDomain, code: NSURLErrorTimedOut)), "Ordinary timeout does not permit fallback")

            for endpoint in ["payload", "redirect", "headers"] {
                var request = URLRequest(url: base.appendingPathComponent(endpoint))
                request.setValue("LibreGetFixture/1", forHTTPHeaderField: "User-Agent")
                request.setValue("https://fixture.invalid/", forHTTPHeaderField: "Referer")
                request.setValue("present", forHTTPHeaderField: "X-LibreGet-Fixture")
                let destination = root.appendingPathComponent(endpoint + ".bin")
                let operation = DownloadOperation()
                let result = try await operation.run(request, destination: destination)
                try checked(result.bytes == Int64(payload.count), endpoint + " production helper returns full byte count")
                let data = try Data(contentsOf: result.url)
                let actualHash = SHA256.hash(data: data).map { String(format: "%02x", $0) }.joined()
                try checked(actualHash == expectedHash, endpoint + " HTTP content reaches app-owned file unchanged")
                try checked(operation.receivedProgress, endpoint + " reports streamed progress")
                let mode = try manager.attributesOfItem(atPath: destination.path)[.posixPermissions] as? NSNumber
                try checked(mode?.intValue == 0o600, endpoint + " produces app-owned 0600 file")
            }

            for endpoint in ["status/403", "truncated", "empty"] {
                let destination = root.appendingPathComponent(endpoint.replacingOccurrences(of: "/", with: "-") + ".bin")
                let operation = DownloadOperation()
                var failed = false
                do { _ = try await operation.run(URLRequest(url: base.appendingPathComponent(endpoint)), destination: destination) }
                catch { failed = true }
                try checked(failed, endpoint + " fails instead of promoting incomplete or HTTP-error response")
                try checked(!manager.fileExists(atPath: destination.path), endpoint + " exposes no final file")
                let files = try manager.contentsOfDirectory(atPath: root.path)
                try checked(!files.contains(where: { $0.hasSuffix(".partial") }), endpoint + " cleans partial file")
            }

            let cancelDestination = root.appendingPathComponent("cancelled.bin")
            let cancelOperation = DownloadOperation()
            var cancelled = false
            do {
                _ = try await cancelOperation.run(URLRequest(url: base.appendingPathComponent("slow")), destination: cancelDestination, cancelOnProgress: true)
            } catch { cancelled = true }
            try checked(cancelled && cancelOperation.cancellationRequested, "Cancel after real progress ends with failure")
            try checked(!manager.fileExists(atPath: cancelDestination.path), "Cancelled stream exposes no final file")
            let remaining = try manager.contentsOfDirectory(atPath: root.path)
            try checked(!remaining.contains(where: { $0.hasSuffix(".partial") }), "Cancelled stream cleans partial file")

            let conflict = root.appendingPathComponent("conflict.bin")
            try Data("existing completed file".utf8).write(to: conflict)
            let conflictOperation = DownloadOperation()
            var conflictFailed = false
            do { _ = try await conflictOperation.run(URLRequest(url: base.appendingPathComponent("payload")), destination: conflict) }
            catch { conflictFailed = true }
            try checked(conflictFailed, "Destination conflict fails")
            let preserved = try Data(contentsOf: conflict)
            try checked(preserved == Data("existing completed file".utf8), "Destination conflict preserves completed file")

            passed = true
            print("App-owned production stream fixtures passed: \(checks) checks")
        } catch {
            print("FAIL: \(error.localizedDescription)")
        }
        try? manager.removeItem(at: root)
        exit(passed ? 0 : 1)
    }
}
