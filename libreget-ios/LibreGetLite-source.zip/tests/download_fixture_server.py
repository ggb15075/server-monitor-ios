"""Local real-HTTP fixtures for production app-owned streaming downloads.

No external credentials or services. Start with --port-file PATH and terminate
the process after Swift/macOS or iOS Simulator fixtures finish.
"""
from __future__ import annotations

import argparse
import hashlib
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
from pathlib import Path
import socket
import time
from urllib.parse import urlparse

PAYLOAD = bytes((index * 31) & 255 for index in range(2 * 1024 * 1024 + 17))
PAYLOAD_SHA256 = hashlib.sha256(PAYLOAD).hexdigest()


class Handler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"

    def log_message(self, *_):
        pass

    def do_HEAD(self):
        self.reply(head=True)

    def do_GET(self):
        self.reply()

    def reply(self, head=False):
        path = urlparse(self.path).path
        if path == "/health":
            self.send(200, b"ready", head=head)
        elif path == "/metadata":
            self.send(200, json.dumps({"bytes": len(PAYLOAD), "sha256": PAYLOAD_SHA256}).encode(), "application/json", head=head)
        elif path == "/redirect":
            self.send_response(302)
            self.send_header("Location", "/payload")
            self.send_header("Content-Length", "0")
            self.end_headers()
        elif path == "/status/403":
            self.send(403, b"forbidden", head=head)
        elif path == "/json-error":
            self.send(200, b'{"error":"expired"}', "application/octet-stream", head=head)
        elif path == "/empty":
            self.send(200, b"", head=head)
        elif path == "/headers":
            expected = {"User-Agent": "LibreGetFixture/1", "Referer": "https://fixture.invalid/", "X-LibreGet-Fixture": "present"}
            if not all(self.headers.get(key) == value for key, value in expected.items()):
                self.send(403, b"required headers missing", head=head)
            else:
                self.send(200, PAYLOAD, head=head)
        elif path == "/truncated":
            self.send_response(200)
            self.send_header("Content-Type", "application/octet-stream")
            self.send_header("Content-Length", str(len(PAYLOAD)))
            self.send_header("Connection", "close")
            self.end_headers()
            if not head:
                self.wfile.write(PAYLOAD[:32768])
                self.wfile.flush()
            self.close_connection = True
            try:
                self.connection.shutdown(socket.SHUT_RDWR)
            except OSError:
                pass
        elif path in ["/payload", "/slow"]:
            if path == "/slow" and not head:
                self.send_response(200)
                self.send_header("Content-Type", "application/octet-stream")
                self.send_header("Content-Length", str(len(PAYLOAD)))
                self.end_headers()
                try:
                    for offset in range(0, len(PAYLOAD), 8192):
                        self.wfile.write(PAYLOAD[offset:offset + 8192])
                        self.wfile.flush()
                        time.sleep(0.025)
                except (BrokenPipeError, ConnectionResetError):
                    pass
            else:
                self.send(200, PAYLOAD, head=head)
        else:
            self.send(404, b"not found", head=head)

    def send(self, status, payload, content_type="application/octet-stream", head=False):
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(payload)))
        self.end_headers()
        if not head:
            self.wfile.write(payload)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--port", type=int, default=0)
    parser.add_argument("--port-file", type=Path)
    arguments = parser.parse_args()
    server = ThreadingHTTPServer(("127.0.0.1", arguments.port), Handler)
    if arguments.port_file:
        arguments.port_file.parent.mkdir(parents=True, exist_ok=True)
        arguments.port_file.write_text(str(server.server_port), encoding="ascii")
    print(json.dumps({"host": "127.0.0.1", "port": server.server_port, "bytes": len(PAYLOAD), "sha256": PAYLOAD_SHA256}), flush=True)
    server.serve_forever()
