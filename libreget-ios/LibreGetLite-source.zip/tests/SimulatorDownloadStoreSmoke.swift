import UIKit
import Foundation
import CryptoKit

// Minimal simulator app linking the real DownloadStore and transport classes.
// Compile with -D DOWNLOAD_STORE_FIXTURES; never include in the shipping app.
@main
struct SimulatorDownloadStoreMain {
    static func main() {
        UIApplicationMain(CommandLine.argc, CommandLine.unsafeArgv, nil, NSStringFromClass(AppDelegate.self))
    }
}

@objc(AppDelegate)
final class AppDelegate: UIResponder, UIApplicationDelegate {
    var window: UIWindow?

    static func finishBackgroundSession(identifier: String) {}

    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]? = nil) -> Bool {
        let window = UIWindow(frame: UIScreen.main.bounds)
        window.rootViewController = UIViewController()
        window.makeKeyAndVisible()
        self.window = window
        Task { @MainActor in await SimulatorDownloadStoreSmoke.run() }
        return true
    }
}

@MainActor
enum SimulatorDownloadStoreSmoke {
    struct FixtureFailure: LocalizedError {
        let message: String
        var errorDescription: String? { message }
    }

    static var stores: [DownloadStore] = []
    static var suites: [String] = []
    static var checks: [String] = []
    static let base = URL(string: "http://127.0.0.1:18765")!
    static let expectedBytes: Int64 = 2 * 1024 * 1024 + 17
    static let expectedHash = "6e5798c703f93c7f65fcf35eceea247a2e0262a0e4382526b3d4e88b745c6fcb"

    static func require(_ condition: Bool, _ message: String) throws {
        guard condition else { throw FixtureFailure(message: message) }
        checks.append(message)
    }

    static func wait(_ message: String, timeout: TimeInterval = 30, until predicate: () -> Bool) async throws {
        let deadline = Date().addingTimeInterval(timeout)
        while !predicate() {
            guard Date() < deadline else { throw FixtureFailure(message: "Timed out: " + message) }
            try await Task.sleep(nanoseconds: 25_000_000)
        }
    }

    static func makeStore(root: URL, name: String, error: Error? = nil) -> DownloadStore {
        let suite = "libreget.simulator.download-fixture.\(UUID().uuidString)"
        suites.append(suite)
        let defaults = UserDefaults(suiteName: suite)!
        defaults.removePersistentDomain(forName: suite)
        let store = DownloadStore(fixtureRoot: root.appendingPathComponent(name, isDirectory: true), defaults: defaults,
                                  sessionNamespace: "com.openselena.libreget.fixtures.\(UUID().uuidString)", backgroundError: error)
        stores.append(store)
        return store
    }

    static func enqueue(_ store: DownloadStore, endpoint: String, title: String) throws -> String {
        let url = base.appendingPathComponent(endpoint)
        let format = MediaFormat(id: "fixture-" + title, url: url.absoluteString, fileExtension: "bin", quality: "Fixture", kind: .file,
                                 headers: ["User-Agent": "LibreGetFixture/1", "Referer": "https://fixture.invalid/", "X-LibreGet-Fixture": "present"])
        let media = ResolvedMedia(originalURL: url.absoluteString, title: title, extractor: "Simulator fixture", formats: [format])
        if let error = store.enqueue(media: media, format: format) { throw FixtureFailure(message: "Enqueue rejected: " + error) }
        guard let id = store.items.first?.id else { throw FixtureFailure(message: "Enqueue produced no item") }
        return id
    }

    static func fallbackCount(_ store: DownloadStore, id: String) -> Int {
        store.items.first(where: { $0.id == id })?.diagnostics?.filter { $0.stage == "fallback-selected" }.count ?? 0
    }

    static func run() async {
        let manager = FileManager.default
        let documents = manager.urls(for: .documentDirectory, in: .userDomainMask)[0]
        let root = documents.appendingPathComponent("ProductionDownloadStoreFixtures", isDirectory: true)
        let reportURL = documents.appendingPathComponent("download-store-simulator-report.json")
        var report: [String: Any] = ["test": "Production DownloadStore background failure and stream recovery",
                                     "platform": "iOS Simulator", "passed": false,
                                     "started_utc": ISO8601DateFormatter().string(from: Date())]
        var passed = false
        do {
            try? manager.removeItem(at: root)
            try manager.createDirectory(at: root, withIntermediateDirectories: true)
            let cocoa = NSError(domain: NSCocoaErrorDomain, code: 513,
                                userInfo: [NSFilePathErrorKey: "/private/var/mobile/Containers/Data/Application/fixture/tmp/CFNetworkDownload.tmp"])
            let nested = NSError(domain: NSURLErrorDomain, code: NSURLErrorUnknown, userInfo: [NSUnderlyingErrorKey: cocoa])
            let recovered = makeStore(root: root, name: "permission-recovery", error: nested)
            let recoveredID = try enqueue(recovered, endpoint: "headers", title: "permission-recovery")
            try await wait("injected daemon error recovers to completed", timeout: 45) {
                recovered.items.first(where: { $0.id == recoveredID }).map { $0.status == .completed || $0.status == .failed } ?? false
            }
            guard let completed = recovered.items.first(where: { $0.id == recoveredID }) else { throw FixtureFailure(message: "Recovered item disappeared") }
            try require(completed.status == .completed, "Injected nested Cocoa 513 passes through production background failure handler and completes")
            try require(fallbackCount(recovered, id: recoveredID) == 1, "Production state machine selects fallback exactly once")
            try require(completed.receivedBytes == expectedBytes, "Production completed item records full streamed byte count")
            guard let file = recovered.fileURL(for: completed) else { throw FixtureFailure(message: "Completed item has no file URL") }
            let payload = try Data(contentsOf: file)
            let hash = SHA256.hash(data: payload).map { String(format: "%02x", $0) }.joined()
            try require(hash == expectedHash, "Production completed file matches actual HTTP payload SHA-256")
            report["recovered_bytes"] = payload.count
            report["recovered_sha256"] = hash

            let cancelled = makeStore(root: root, name: "cancelled-recovery", error: cocoa)
            let cancelledID = try enqueue(cancelled, endpoint: "slow", title: "cancelled-recovery")
            try await wait("fallback receives initial bytes") {
                guard let item = cancelled.items.first(where: { $0.id == cancelledID }) else { return false }
                return item.receivedBytes > 0 && item.parts?.contains(where: { $0.transport == "app-stream" }) == true
            }
            guard let oldAttempt = cancelled.items.first(where: { $0.id == cancelledID })?.attempt else { throw FixtureFailure(message: "Streaming item has no attempt ID") }
            let selectedBeforeCancellation = fallbackCount(cancelled, id: cancelledID)
            cancelled.cancel(cancelledID)
            cancelled.fixtureInjectBackgroundFailure(id: cancelledID, attempt: oldAttempt, error: cocoa)
            try await Task.sleep(nanoseconds: 300_000_000)
            guard let cancelledItem = cancelled.items.first(where: { $0.id == cancelledID }) else { throw FixtureFailure(message: "Cancelled item disappeared") }
            try require(cancelledItem.status == .failed && cancelledItem.errorMessage == "已取消", "Cancel followed by late background failure remains cancelled")
            try require(cancelledItem.attempt != oldAttempt, "Cancellation invalidates the previous production attempt")
            try require(fallbackCount(cancelled, id: cancelledID) == selectedBeforeCancellation, "Late cancelled-attempt callback cannot select another fallback")
            try require(cancelledItem.parts == nil && cancelledItem.localFilename == nil, "Cancelled fallback does not expose staged or completed file")
            let cancelledFiles = try manager.subpathsOfDirectory(atPath: root.appendingPathComponent("cancelled-recovery").path)
            try require(!cancelledFiles.contains(where: { $0.hasSuffix(".partial") }), "Cancellation cleans app-owned streaming partial file")

            let rejected = makeStore(root: root, name: "http-forbidden")
            let rejectedID = try enqueue(rejected, endpoint: "status/403", title: "http-forbidden")
            try await wait("background HTTP 403 fails", timeout: 45) {
                rejected.items.first(where: { $0.id == rejectedID })?.status == .failed
            }
            guard let rejectedItem = rejected.items.first(where: { $0.id == rejectedID }) else { throw FixtureFailure(message: "HTTP failure item disappeared") }
            try require(rejectedItem.errorMessage?.contains("403") == true, "Production background HTTP 403 reports HTTP failure")
            try require(fallbackCount(rejected, id: rejectedID) == 0, "HTTP 403 does not trigger daemon permission fallback")
            try require(rejectedItem.localFilename == nil, "HTTP error produces no completed file")
            passed = true
            report["passed"] = true
        } catch {
            report["failure"] = error.localizedDescription
            let failure = error as NSError
            report["failure_domain"] = failure.domain
            report["failure_code"] = failure.code
        }
        report["checks"] = checks
        report["check_count"] = checks.count
        report["finished_utc"] = ISO8601DateFormatter().string(from: Date())
        if let data = try? JSONSerialization.data(withJSONObject: report, options: [.prettyPrinted, .sortedKeys]) {
            try? data.write(to: reportURL, options: .atomic)
            print(String(decoding: data, as: UTF8.self))
        }
        for suite in suites { UserDefaults.standard.removePersistentDomain(forName: suite) }
        exit(passed ? 0 : 1)
    }
}
