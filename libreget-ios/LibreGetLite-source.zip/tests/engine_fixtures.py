#!/usr/bin/env python3
"""Offline mapping/integration checks against the exact bundled yt-dlp version.

Run after prepare_python_runtime.py. --network adds optional public-site smoke
checks; no media files are downloaded in either mode.
"""
import argparse
import json
import sys
import threading
import unittest
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
from urllib.parse import quote

ROOT = Path(__file__).resolve().parents[1] / "LibreGetLite"
sys.path[:0] = [str(ROOT / "PythonApp"), str(ROOT / "PythonPackages")]
from libreget_engine import ResolveError, normalize_info, resolve_json
from libreget_xiaohongshu import LibreGetXiaohongshuIE, MOBILE_UA
from yt_dlp.utils import DownloadError


def media(fmt_id, **fields):
    return {"format_id": fmt_id, "url": "https://cdn.example/" + fmt_id,
            "ext": "mp4", "protocol": "https", "vcodec": "avc1.4d401f",
            "acodec": "mp4a.40.2", **fields}


class MappingTests(unittest.TestCase):
    def test_direct_tracks_pair_only_with_compatible_audio(self):
        info = {"title": "Fixture", "formats": [
            media("v", acodec="none", height=1080, filesize=1000),
            media("aac", vcodec="none", ext="m4a", abr=128, filesize=100,
                  http_headers={"Referer": "https://example.org/", "Cookie": "fixture=1"}),
            media("opus", vcodec="none", ext="webm", acodec="opus", abr=256),
        ]}
        formats = normalize_info(info, "https://example.org/page")["formats"]
        video = next(fmt for fmt in formats if fmt["kind"] == "video")
        self.assertEqual(video["audioURL"], "https://cdn.example/aac")
        self.assertEqual(video["audioHeaders"]["Cookie"], "fixture=1")
        self.assertEqual(video["approximateBytes"], 1100)

    def test_fragmented_dash_drm_and_silent_video_are_not_offered(self):
        formats = [media("dash", protocol="http_dash_segments", fragments=[{"url": "part"}]),
                   media("fragment", fragments=[{"url": "part"}]),
                   media("drm", has_drm=True), media("silent", acodec="none")]
        with self.assertRaises(ResolveError):
            normalize_info({"formats": formats}, "https://example.org/video")

    def test_hls_preserves_supported_stream_and_rejects_separate_rendition(self):
        formats = [media("hls", protocol="m3u8_native"),
                   media("video-only-hls", protocol="m3u8_native", acodec="none")]
        values = normalize_info({"formats": formats}, "https://example.org/video")["formats"]
        self.assertEqual(len(values), 1)
        self.assertEqual(values[0]["protocolHint"], "m3u8")

    def test_invalid_urls_headers_nan_and_duplicates(self):
        formats = [media("good", height=float("nan"), http_headers={
            "Referer": "https://example.org/", "Range": "bytes=0-1", "X-Invalid": "a\r\nb"}),
            media("good"), media("bad", url="file:///etc/passwd")]
        result = normalize_info({"duration": float("nan"), "formats": formats}, "https://example.org/video")
        self.assertEqual(len(result["formats"]), 1)
        self.assertNotIn("duration", result)
        self.assertEqual(result["formats"][0]["headers"], {"Referer": "https://example.org/"})
        json.dumps(result, allow_nan=False)

    def test_playlist_and_live_return_actionable_errors(self):
        for info in ({"_type": "playlist", "entries": [{}, {}]}, {"is_live": True}):
            with self.assertRaises(ResolveError):
                normalize_info(info, "https://example.org/video")

    def test_own_provider_is_discovered_by_pinned_ytdlp(self):
        # YoutubeDL's constructor loads plugins once per process. Explicitly
        # loading again would re-register every provider and is unsupported.
        import yt_dlp
        with yt_dlp.YoutubeDL({"quiet": True}): pass
        from yt_dlp_plugins.extractor.libreget_webkit import LibreGetWebKitJCP
        self.assertEqual(LibreGetWebKitJCP.JS_RUNTIME_NAME, "libreget-webkit")
        self.assertIn("2026.10.26", __import__("yt_dlp.version", fromlist=["__version__"]).__version__)


class _VideoPage(BaseHTTPRequestHandler):
    def do_HEAD(self): self.respond(False)
    def do_GET(self): self.respond(True)
    def respond(self, include_body):
        body = b'<html><head><title>LibreGet generic fixture</title></head><body><video controls src="/sample.mp4"></video></body></html>'
        self.send_response(200)
        self.send_header("Content-Type", "video/mp4" if self.path.endswith(".mp4") else "text/html")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        if include_body: self.wfile.write(body)
    def log_message(self, *args): pass


class IntegrationTests(unittest.TestCase):
    def test_xiaohongshu_short_link_recovers_mobile_note_from_login_redirect(self):
        note_id = "6af1307d000000003501dbb3"
        short_url = "https://xhslink.cn/o/sample"
        note_path = f"/discovery/item/{note_id}?xsec_source=app_share&xsec_token=test%2Btoken%3D"
        note_url = f"https://www.xiaohongshu.com{note_path}"
        login_url = "https://www.xiaohongshu.com/login?redirectPath=" + quote("http://www.xiaohongshu.com" + note_path, safe="")
        note = {"noteId": note_id, "title": "小红书测试", "video": {"media": {"stream": {"h264": [{
            "masterUrl": "https://cdn.example/video.mp4", "width": 1280, "height": 720, "size": 1000,
            "videoCodec": "h264", "audioCodec": "aac", "duration": 97222,
        }]}}}}
        state = {"noteData": {"data": {"noteData": note}}}
        page = "<script>window.__INITIAL_STATE__=" + json.dumps(state).replace('"title":', '"unused":undefined,"title":') + "</script>"
        responses = [
            ("login", SimpleNamespace(url=login_url, status=200)),
            (page, SimpleNamespace(url=note_url, status=200)),
        ]
        with patch.object(LibreGetXiaohongshuIE, "_download_webpage_handle", side_effect=responses) as fetch:
            result = json.loads(resolve_json(short_url))
        self.assertEqual([call.args[0] for call in fetch.call_args_list], [short_url, note_url])
        self.assertEqual(result["title"], note["title"])
        self.assertEqual(result["originalURL"], short_url)
        self.assertEqual(result["duration"], 97.222)
        self.assertEqual(result["formats"][0]["width"], 1280)
        self.assertEqual(result["formats"][0]["headers"]["User-Agent"], MOBILE_UA)
        self.assertEqual(result["formats"][0]["headers"]["Referer"], "https://www.xiaohongshu.com/")

    def test_xiaohongshu_login_target_is_bounded_to_known_note(self):
        login_url = "https://www.xiaohongshu.com/login?redirectPath="
        note_path = "/explore/6af1307d000000003501dbb3?xsec_source=app_share&xsec_token=fixture%3D"
        external_login = login_url + quote("https://example.org" + note_path, safe="")
        with patch.object(LibreGetXiaohongshuIE, "_download_webpage_handle") as fetch:
            with self.assertRaisesRegex(DownloadError, "小红书仍要求登录"):
                resolve_json(external_login)
        fetch.assert_not_called()

        valid_login = login_url + quote(note_path, safe="")
        response = ("login", SimpleNamespace(url=valid_login, status=200))
        with patch.object(LibreGetXiaohongshuIE, "_download_webpage_handle", return_value=response) as fetch:
            with self.assertRaisesRegex(DownloadError, "小红书仍要求登录"):
                resolve_json(valid_login)
        fetch.assert_called_once_with("https://www.xiaohongshu.com" + note_path, "6af1307d000000003501dbb3",
                                      expected_status=(401, 403, 404))

    def test_real_generic_extractor_resolves_html_video(self):
        server = ThreadingHTTPServer(("127.0.0.1", 0), _VideoPage)
        thread = threading.Thread(target=server.serve_forever, daemon=True)
        thread.start()
        try:
            result = json.loads(resolve_json(f"http://127.0.0.1:{server.server_port}/watch"))
            self.assertIn("HTML5MediaEmbed", result["extractor"])
            self.assertTrue(result["formats"][0]["url"].endswith("/sample.mp4"))
        finally:
            server.shutdown()
            server.server_close()


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--network", action="store_true")
    options, extra = parser.parse_known_args()
    suite = unittest.defaultTestLoader.loadTestsFromModule(sys.modules[__name__])
    success = unittest.TextTestRunner(verbosity=2).run(suite).wasSuccessful()
    if options.network:
        for url in ["https://www.w3schools.com/html/html5_video.asp",
                    "https://archive.org/details/BigBuckBunny_328"]:
            try:
                result = json.loads(resolve_json(url))
                print("NETWORK OK", url, result["extractor"], len(result["formats"]))
            except Exception as error:
                print("NETWORK UNVERIFIED", url, str(error))
    raise SystemExit(0 if success else 1)
