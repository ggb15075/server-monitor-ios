"""Anonymous HTTP equivalent of NativeMediaParser's Douyin request path.

Reports omit cookies and expiring signed media URLs. This is a cross-check of
the remote response; the Swift smoke test exercises the actual app parser.
"""
from __future__ import annotations

import argparse
import hashlib
import http.cookiejar
import json
from pathlib import Path
import re
import struct
import time
import traceback
import urllib.error
import urllib.parse
import urllib.request

SHARE_TEXT = "6.94 复制打开抖音，看看【酷酷鸽子的作品】人是环境的产物：） # 2026APEC见证深圳开... https://v.douyin.com/T4GQRgwdReI/ kpd:/ D@U.YZ :2pm 01/07"
DESKTOP_UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Safari/537.36"
MOBILE_UA = "Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Mobile/15E148 Safari/604.1"


def first_url(value):
    if isinstance(value, str):
        value = value.replace("&amp;", "&").replace("&#38;", "&").replace("\\u0026", "&").replace("\\/", "/")
        if value.startswith("//"):
            value = "https:" + value
        parsed = urllib.parse.urlparse(value)
        return value if parsed.scheme in ["https", "http"] and parsed.hostname and not parsed.username and not parsed.password else None
    if isinstance(value, list):
        return next((url for entry in value if (url := first_url(entry))), None)
    if isinstance(value, dict):
        return next((url for key in ["urlList", "url_list", "UrlList", "url", "src"] if (url := first_url(value.get(key)))), None)


def boxes(data, start=0, stop=None):
    stop = len(data) if stop is None else stop
    while start + 8 <= stop:
        size, kind = struct.unpack_from(">I4s", data, start)
        header = 8
        if size == 1:
            if start + 16 > stop:
                return
            size, = struct.unpack_from(">Q", data, start + 8)
            header = 16
        if size == 0:
            size = stop - start
        if size < header or start + size > stop:
            return
        yield kind.decode("ascii", errors="replace"), start + header, start + size
        start += size


def inspect_mp4(path):
    data = path.read_bytes()
    top = list(boxes(data))
    tracks = []
    for kind, start, stop in top:
        if kind != "moov":
            continue
        for child, cs, ce in boxes(data, start, stop):
            if child != "trak":
                continue
            track = {}
            for atom, ats, ate in boxes(data, cs, ce):
                if atom == "tkhd" and ate - ats >= 8:
                    w, h = struct.unpack_from(">II", data, ate - 8)
                    track.update(width=w / 65536, height=h / 65536)
                if atom != "mdia":
                    continue
                for meta, ms, me in boxes(data, ats, ate):
                    if meta == "hdlr" and me - ms >= 12:
                        track["handler"] = data[ms + 8:ms + 12].decode("ascii", errors="replace")
                    if meta == "mdhd" and me - ms >= 24:
                        offset = 20 if data[ms] == 1 else 12
                        timescale, = struct.unpack_from(">I", data, ms + offset)
                        duration, = struct.unpack_from(">Q" if data[ms] == 1 else ">I", data, ms + offset + 4)
                        track["duration_seconds"] = round(duration / timescale, 3) if timescale else None
                    if meta == "minf":
                        for table, ts, te in boxes(data, ms, me):
                            if table == "stbl":
                                for sample, ss, se in boxes(data, ts, te):
                                    if sample == "stsd":
                                        track["sample_codecs"] = [name for name, _, _ in boxes(data, ss + 8, se)]
            tracks.append(track)
    return {"top_level_boxes": [kind for kind, _, _ in top], "tracks": tracks,
            "has_video": any(t.get("handler") == "vide" for t in tracks),
            "has_audio": any(t.get("handler") == "soun" for t in tracks),
            "structurally_mp4": len(top) > 0 and top[0][0] == "ftyp" and any(kind == "moov" for kind, _, _ in top)}


def run(output):
    report = {"test": "Douyin user share URL", "requested_short_url": "https://v.douyin.com/T4GQRgwdReI/",
              "started_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
              "implementation": "Python HTTP equivalent; not the Swift app", "passed": False, "steps": []}
    output.mkdir(parents=True, exist_ok=True)
    jar = http.cookiejar.CookieJar()
    opener = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(jar))

    def request(url, headers=None, body=None, limit=12 * 1024 * 1024):
        merged = {"User-Agent": DESKTOP_UA, "Accept-Language": "zh-CN,zh;q=0.9,en;q=0.7"}
        merged.update(headers or {})
        req = urllib.request.Request(url, headers=merged, data=body)
        with opener.open(req, timeout=25) as response:
            data = response.read(limit + 1)
            if len(data) > limit:
                raise RuntimeError("Response exceeded size limit")
            return data, response.status, response.url, response.headers

    try:
        match = re.search(r"https?://[^\s]+", SHARE_TEXT)
        if not match:
            raise RuntimeError("No URL found in complete share text")
        short = match.group()
        report["share_text_extraction_matches"] = short == report["requested_short_url"]
        _, status, canonical, _ = request(short)
        parsed = urllib.parse.urlparse(canonical)
        post = re.search(r"/(?:video|note|slides)/(\d+)", parsed.path)
        post_id = post.group(1) if post else urllib.parse.parse_qs(parsed.query).get("modal_id", [None])[0]
        report["steps"].append({"name": "resolve short URL", "status": status, "host": parsed.hostname, "post_id": post_id})
        if not post_id or not (parsed.hostname == "douyin.com" or (parsed.hostname or "").endswith(".douyin.com") or (parsed.hostname or "").endswith(".iesdouyin.com")):
            raise RuntimeError("Short link did not resolve to a known Douyin post")
        registration = {"region": "cn", "aid": 1768, "needFid": False, "service": "www.ixigua.com", "migrate_info": {"ticket": "", "source": "node"}, "cbUrlProtocol": "https", "union": True}
        _, status, _, headers = request("https://ttwid.bytedance.com/ttwid/union/register/", {"User-Agent": MOBILE_UA, "Content-Type": "application/json"}, json.dumps(registration, separators=(",", ":")).encode())
        cookie = re.search(r"(?:^|[,;]\s*)ttwid=([^;,\s]+)", headers.get("Set-Cookie", ""))
        report["steps"].append({"name": "anonymous ttwid registration", "status": status, "received_cookie": bool(cookie)})
        if not cookie:
            raise RuntimeError("Anonymous registration returned no ttwid cookie")
        share_url = "https://www.iesdouyin.com/share/video/" + post_id + "/"
        body, status, _, headers = request(share_url, {"User-Agent": MOBILE_UA, "Cookie": "ttwid=" + cookie.group(1)})
        html = body.decode("utf-8", errors="replace")
        assignment = re.search(r"(?:window\s*\.\s*)?_ROUTER_DATA\s*=\s*", html)
        report["steps"].append({"name": "share page", "status": status, "bytes": len(body), "router_data_present": bool(assignment)})
        if not assignment:
            raise RuntimeError("Share page contains no public _ROUTER_DATA")
        tail = html[assignment.end():]
        router, _ = json.JSONDecoder().raw_decode(tail[tail.index("{"):])
        report["router_loader_schema"] = {
            str(key): {"type": type(loader).__name__, "keys": list(loader.keys()) if isinstance(loader, dict) else []}
            for key, loader in router.get("loaderData", {}).items()
        }
        items = [item for loader in router.get("loaderData", {}).values() if isinstance(loader, dict)
                 for item in ((loader.get("videoInfoRes") or {}).get("item_list") or [])]
        item = next((item for item in items if str(item.get("aweme_id")) == post_id), None)
        if not item:
            raise RuntimeError("Share page returned no matching post data")
        video = item.get("video") or {}
        formats = []
        for index, rate in enumerate(video.get("bit_rate") or []):
            address = rate.get("play_addr") or {}
            media_url = first_url(address.get("url_list"))
            if media_url:
                formats.append({"id": f"douyin-rate-{index}", "url": media_url, "width": address.get("width"), "height": address.get("height")})
        original = first_url((video.get("play_addr") or {}).get("url_list"))
        if original and not any(fmt["url"] == original for fmt in formats):
            formats.append({"id": "douyin-original", "url": original, "width": video.get("width"), "height": video.get("height")})
        report.update(title=item.get("desc"), author=(item.get("author") or {}).get("nickname"), expected_duration_seconds=(video.get("duration") or 0) / 1000,
                      formats=[{k: v for k, v in fmt.items() if k != "url"} for fmt in formats])
        if not formats:
            raise RuntimeError("No playable video URL returned")
        chosen = formats[0]
        media_headers = {"User-Agent": MOBILE_UA, "Referer": "https://www.iesdouyin.com/"}
        # CookieJar adds only cookies matching the media URL, just as the native
        # parser's addingSessionCookies() does for non-TikTok domains.
        path = output / "douyin-user-video.mp4"
        req = urllib.request.Request(chosen["url"], headers=media_headers)
        with opener.open(req, timeout=30) as response, path.open("wb") as destination:
            report["download_http_status"] = response.status
            report["download_content_type"] = response.headers.get("Content-Type")
            report["download_final_host"] = urllib.parse.urlparse(response.url).hostname
            total = 0
            while block := response.read(1024 * 1024):
                total += len(block)
                if total > 256 * 1024 * 1024:
                    raise RuntimeError("Video exceeds 256 MiB test limit")
                destination.write(block)
        report["download_bytes"] = path.stat().st_size
        report["sha256"] = hashlib.sha256(path.read_bytes()).hexdigest()
        report["mp4"] = inspect_mp4(path)
        report["passed"] = report["download_http_status"] == 200 and report["mp4"]["structurally_mp4"] and report["mp4"]["has_video"] and report["mp4"]["has_audio"]
        if not report["passed"]:
            raise RuntimeError("Downloaded file did not contain a complete MP4 video and audio structure")
    except Exception as error:
        # urllib exceptions may contain the signed media URL; output only the
        # HTTP status or a controlled error category rather than raw repr.
        if isinstance(error, urllib.error.HTTPError):
            report["failure"] = f"HTTP {error.code}"
        elif isinstance(error, urllib.error.URLError):
            report["failure"] = f"Network error: {type(error.reason).__name__}"
        elif isinstance(error, (RuntimeError, ValueError, KeyError)):
            report["failure"] = str(error)[:180]
        else:
            report["failure"] = type(error).__name__
        report["failure_location"] = [{"function": frame.name, "line": frame.lineno} for frame in traceback.extract_tb(error.__traceback__)][-3:]
    report["finished_utc"] = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
    (output / "douyin-python-report.json").write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(report, ensure_ascii=False, indent=2))
    return 0 if report["passed"] else 1


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", required=True, type=Path)
    raise SystemExit(run(parser.parse_args().output))
