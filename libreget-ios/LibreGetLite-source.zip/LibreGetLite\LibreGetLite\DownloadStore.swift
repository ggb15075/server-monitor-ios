import Foundation
import Combine

enum DownloadStatus: String, Codable {
    case queued
    case downloading
    case completed
    case failed
}

private struct DownloadResponseError: LocalizedError {
    let statusCode: Int

    var errorDescription: String? {
        "服务器返回 HTTP \(statusCode)"
    }
}

struct DownloadItem: Identifiable, Codable, Equatable {
    var id: String
    var sourceURL: String
    var title: String
    var status: DownloadStatus
    var receivedBytes: Int64
    var expectedBytes: Int64
    var localFilename: String?
    var errorMessage: String?
    var createdAt: Date

    var progress: Double {
        guard expectedBytes > 0 else { return 0 }
        return min(1, Double(receivedBytes) / Double(expectedBytes))
    }
}

final class DownloadStore: NSObject, ObservableObject, URLSessionDownloadDelegate {
    static let shared = DownloadStore()

    @Published private(set) var items: [DownloadItem] = []

    private let storageKey = "libreget.ios.downloads.v1"
    private let sessionIdentifier = "com.openselena.libreget.ioslite.downloads"
    private var session: URLSession!
    private var tasksByID: [String: URLSessionDownloadTask] = [:]

    var completedItems: [DownloadItem] {
        items.filter { $0.status == .completed }.sorted { $0.createdAt > $1.createdAt }
    }

    var activeItems: [DownloadItem] {
        items.filter { $0.status == .queued || $0.status == .downloading }.sorted { $0.createdAt > $1.createdAt }
    }

    override init() {
        super.init()
        restoreItems()

        let configuration = URLSessionConfiguration.background(withIdentifier: sessionIdentifier)
        configuration.isDiscretionary = false
        configuration.sessionSendsLaunchEvents = true
        configuration.httpMaximumConnectionsPerHost = 3
        session = URLSession(configuration: configuration, delegate: self, delegateQueue: nil)
        reconcileTasks()
    }

    @discardableResult
    func enqueue(_ rawURL: String) -> String? {
        let trimmed = rawURL.trimmingCharacters(in: .whitespacesAndNewlines)
        guard let url = URL(string: trimmed),
              url.scheme?.lowercased() == "https",
              let host = url.host, !host.isEmpty else {
            return "请输入有效的 HTTPS 下载链接。"
        }

        if items.contains(where: { $0.sourceURL == url.absoluteString && $0.status != .failed }) {
            return "这个链接已经在下载列表里。"
        }

        let fallback = url.deletingPathExtension().lastPathComponent
        let item = DownloadItem(
            id: UUID().uuidString,
            sourceURL: url.absoluteString,
            title: fallback.isEmpty ? host : fallback,
            status: .queued,
            receivedBytes: 0,
            expectedBytes: 0,
            localFilename: nil,
            errorMessage: nil,
            createdAt: Date()
        )
        items.insert(item, at: 0)
        persistItems()
        start(item)
        return nil
    }

    func retry(_ id: String) {
        guard let index = items.firstIndex(where: { $0.id == id }) else { return }
        items[index].status = .queued
        items[index].receivedBytes = 0
        items[index].expectedBytes = 0
        items[index].errorMessage = nil
        persistItems()
        start(items[index])
    }

    func cancel(_ id: String) {
        tasksByID[id]?.cancel()
        tasksByID[id] = nil
        update(id) {
            $0.status = .failed
            $0.errorMessage = "已取消"
        }
    }

    func remove(_ id: String) {
        tasksByID[id]?.cancel()
        tasksByID[id] = nil
        if let item = items.first(where: { $0.id == id }),
           let fileURL = fileURL(for: item) {
            try? FileManager.default.removeItem(at: fileURL)
        }
        items.removeAll { $0.id == id }
        persistItems()
    }

    func fileURL(for item: DownloadItem) -> URL? {
        guard let filename = item.localFilename else { return nil }
        return downloadsDirectory.appendingPathComponent(filename)
    }

    func fileSizeDescription(for item: DownloadItem) -> String {
        let bytes = item.expectedBytes > 0 ? item.expectedBytes : item.receivedBytes
        return ByteCountFormatter.string(fromByteCount: bytes, countStyle: .file)
    }

    func urlSession(
        _ session: URLSession,
        downloadTask: URLSessionDownloadTask,
        didWriteData bytesWritten: Int64,
        totalBytesWritten: Int64,
        totalBytesExpectedToWrite: Int64
    ) {
        guard let id = downloadTask.taskDescription else { return }
        DispatchQueue.main.async {
            self.update(id, persist: false) {
                $0.status = .downloading
                $0.receivedBytes = totalBytesWritten
                $0.expectedBytes = totalBytesExpectedToWrite
            }
        }
    }

    func urlSession(
        _ session: URLSession,
        downloadTask: URLSessionDownloadTask,
        didFinishDownloadingTo location: URL
    ) {
        guard let id = downloadTask.taskDescription else { return }

        do {
            if let response = downloadTask.response as? HTTPURLResponse,
               !(200..<300).contains(response.statusCode) {
                throw DownloadResponseError(statusCode: response.statusCode)
            }

            let directory = downloadsDirectory
            try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
            let suggested = downloadTask.response?.suggestedFilename
            let fallback = URL(string: downloadTask.originalRequest?.url?.absoluteString ?? "")?.lastPathComponent
            let filename = safeFilename(suggested ?? fallback ?? "download")
            var destination = directory.appendingPathComponent(filename)
            if FileManager.default.fileExists(atPath: destination.path) {
                let base = destination.deletingPathExtension().lastPathComponent
                let suffix = destination.pathExtension
                let unique = suffix.isEmpty ? "\(base)-\(id.prefix(6))" : "\(base)-\(id.prefix(6)).\(suffix)"
                destination = directory.appendingPathComponent(unique)
            }
            try FileManager.default.moveItem(at: location, to: destination)

            DispatchQueue.main.async {
                self.tasksByID[id] = nil
                self.update(id) {
                    $0.status = .completed
                    $0.receivedBytes = downloadTask.countOfBytesReceived
                    $0.expectedBytes = downloadTask.countOfBytesExpectedToReceive
                    $0.title = destination.lastPathComponent
                    $0.localFilename = destination.lastPathComponent
                    $0.errorMessage = nil
                }
            }
        } catch {
            DispatchQueue.main.async {
                self.tasksByID[id] = nil
                self.update(id) {
                    $0.status = .failed
                    $0.errorMessage = "无法保存文件：\(error.localizedDescription)"
                }
            }
        }
    }

    func urlSession(_ session: URLSession, task: URLSessionTask, didCompleteWithError error: Error?) {
        guard let id = task.taskDescription else { return }
        DispatchQueue.main.async {
            self.tasksByID[id] = nil
            guard let error, (error as NSError).code != NSURLErrorCancelled else { return }
            self.update(id) {
                $0.status = .failed
                $0.errorMessage = error.localizedDescription
            }
        }
    }

    func urlSessionDidFinishEvents(forBackgroundURLSession session: URLSession) {
        DispatchQueue.main.async {
            AppDelegate.backgroundSessionCompletionHandler?()
            AppDelegate.backgroundSessionCompletionHandler = nil
        }
    }

    private var downloadsDirectory: URL {
        FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
            .appendingPathComponent("Downloads", isDirectory: true)
    }

    private func start(_ item: DownloadItem) {
        guard let url = URL(string: item.sourceURL) else { return }
        let task = session.downloadTask(with: url)
        task.taskDescription = item.id
        tasksByID[item.id] = task
        update(item.id) {
            $0.status = .downloading
            $0.errorMessage = nil
        }
        task.resume()
    }

    private func reconcileTasks() {
        session.getAllTasks { tasks in
            DispatchQueue.main.async {
                for task in tasks {
                    guard let id = task.taskDescription else { continue }
                    self.tasksByID[id] = task as? URLSessionDownloadTask
                }

                let activeIDs = Set(tasks.compactMap(\.taskDescription))
                for index in self.items.indices where self.items[index].status == .downloading {
                    if !activeIDs.contains(self.items[index].id) {
                        self.items[index].status = .queued
                    }
                }
                self.persistItems()
                let pending = self.items.filter { $0.status == .queued }
                pending.forEach(self.start)
            }
        }
    }

    private func update(
        _ id: String,
        persist: Bool = true,
        change: (inout DownloadItem) -> Void
    ) {
        guard let index = items.firstIndex(where: { $0.id == id }) else { return }
        change(&items[index])
        if persist {
            persistItems()
        }
    }

    private func safeFilename(_ value: String) -> String {
        let name = URL(fileURLWithPath: value).lastPathComponent
            .replacingOccurrences(of: ":", with: "-")
            .trimmingCharacters(in: .whitespacesAndNewlines)
        return name.isEmpty || name == "." || name == ".." ? "download" : name
    }

    private func restoreItems() {
        guard let data = UserDefaults.standard.data(forKey: storageKey),
              let restored = try? JSONDecoder().decode([DownloadItem].self, from: data) else { return }
        items = restored
    }

    private func persistItems() {
        guard let data = try? JSONEncoder().encode(items) else { return }
        UserDefaults.standard.set(data, forKey: storageKey)
    }
}
